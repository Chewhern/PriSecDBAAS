﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;

namespace PriSecDBAPI_CDemoApp.Helper
{
    public static class CredentialsSetter
    {
        private static String AdminDBCredentialsAppRootFolder = "";
        private static String AdminSealedDBCredentialsAppRootFolder = "";

        public static String PaymentID = "";
        public static String SealedETLSID = "";
        public static String SealedDBUserName = "";
        public static String SealedDBUserPassword = "";
        public static String SealedDBName = "";
        public static String SealedDBUserNameHMAC = "";
        public static String SealedDBUserPasswordHMAC = "";
        public static String SealedDBNameHMAC = "";

        public static Byte[] X25519SESK = new Byte[] { };
        public static Byte[] X25519MACSK = new Byte[] { };
        public static Byte[] X25519SEPK = new Byte[] { };
        public static Byte[] X25519MACPK = new Byte[] { };

        private static void SetCredentialsPath() 
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\DBCredentials\\";
                AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\SealedDBCredentials\\";
            }
            else
            {
                AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/DBCredentials/";
                AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/SealedDBCredentials/";
            }
        }

        public static Boolean DoesCredentialsExist() 
        {
            SetCredentialsPath();

            return (File.Exists(AdminDBCredentialsAppRootFolder + "PaymentID.txt") == true
                && File.Exists(AdminDBCredentialsAppRootFolder + "X25519SESK.txt") == true
                && File.Exists(AdminDBCredentialsAppRootFolder + "X25519MACSK.txt") == true
                && File.Exists(AdminDBCredentialsAppRootFolder + "X25519SEPK.txt") == true
                && File.Exists(AdminDBCredentialsAppRootFolder + "X25519MACPK.txt") == true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt")==true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt") == true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPassword.txt") == true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBName.txt") == true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserNameHMAC.txt") == true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPasswordHMAC.txt") == true
                && File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBNameHMAC.txt") == true);
        }

        public static void SetCredentials() 
        {
            if (DoesCredentialsExist() == true) 
            {
                X25519SESK = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "X25519SESK.txt");
                X25519MACSK = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "X25519MACSK.txt");
                X25519SEPK = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "X25519SEPK.txt");
                X25519MACPK = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "X25519MACPK.txt");
                PaymentID = File.ReadAllText(AdminDBCredentialsAppRootFolder + "PaymentID.txt");
                SealedETLSID = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt");
                SealedDBUserName = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt");
                SealedDBUserPassword = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPassword.txt");
                SealedDBName = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBName.txt");
                SealedDBUserNameHMAC = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserNameHMAC.txt");
                SealedDBUserPasswordHMAC = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPasswordHMAC.txt");
                SealedDBNameHMAC = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBNameHMAC.txt");
            }
            else 
            {
                throw new Exception("Error: The credentials don't exist..");
            }
        }
    }
}
