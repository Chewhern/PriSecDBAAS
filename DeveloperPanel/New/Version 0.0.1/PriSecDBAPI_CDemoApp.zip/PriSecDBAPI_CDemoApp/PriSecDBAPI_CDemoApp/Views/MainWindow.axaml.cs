﻿using Avalonia.Controls;

namespace PriSecDBAPI_CDemoApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
