﻿using System;
using System.IO;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.InteropServices;
using ASodium;
using System.Text;
using Avalonia.Controls;
using Avalonia.Media;
using Newtonsoft.Json;
using PriSecDBAPI_CDemoApp.Helper;
using PriSecDBAPI_CDemoApp.APIMethodHelper;
using PriSecDBAPI_CDemoApp.Model;
using BCASodium;
using System.Linq;
using Org.BouncyCastle.Crypto.Digests;

namespace PriSecDBAPI_CDemoApp.Views;

public partial class MainView : UserControl
{
    private static int AppUIChooser;
    private static TextBlock[] FirstmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] SecondmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] ThirdmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] FourthmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] FifthmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] SixthmyTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstmyTBArray = new TextBox[] { };
    private static TextBox[] SecondmyTBArray = new TextBox[] { };
    private static TextBox[] ThirdmyTBArray = new TextBox[] { };
    private static TextBox[] FourthmyTBArray = new TextBox[] { };
    private static TextBox[] FifthmyTBArray = new TextBox[] { };
    private static TextBox[] SixthmyTBArray = new TextBox[] { };
    private static Button[] FirstmyButtonArray = new Button[] { };
    private static Button[] SecondmyButtonArray = new Button[] { };
    private static Button[] ThirdmyButtonArray = new Button[] { };
    private static Button[] FourthmyButtonArray = new Button[] { };
    private static Button[] FifthmyButtonArray = new Button[] { };
    private static Button[] SixthmyButtonArray = new Button[] { };
    private static RadioButton[] FirstmyRBArray = new RadioButton[] { };
    private static RadioButton[] SecondmyRBArray = new RadioButton[] { };
    private static RadioButton[] ThirdmyRBArray = new RadioButton[] { };
    private static RadioButton[] FourthmyRBArray = new RadioButton[] { };
    private static CheckBox[] FirstmyCBArray = new CheckBox[] { };
    private static String AdminServerIPAppRootFolder = "";
    private static String AdminDBCredentialsAppRootFolder = "";
    private static String AdminSealedDBCredentialsAppRootFolder = "";
    private static String SystemResponseAppRootFolder = "";
    private static Boolean HasUIRendered = false;

    public MainView()
    {
        InitializeComponent();
        AppInitialization();

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
        {
            AdminServerIPAppRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
            AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\DBCredentials\\";
            AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\SealedDBCredentials\\";
            SystemResponseAppRootFolder = AppContext.BaseDirectory + "\\SystemResponse\\";
        }
        else
        {
            AdminServerIPAppRootFolder = AppContext.BaseDirectory + "/ServerIP/";
            AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/DBCredentials/";
            AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/SealedDBCredentials/";
            SystemResponseAppRootFolder = AppContext.BaseDirectory + "/SystemResponse/";
        }
        if (Directory.Exists(AdminServerIPAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminServerIPAppRootFolder);
        }
        if (Directory.Exists(AdminDBCredentialsAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminDBCredentialsAppRootFolder);
        }
        if (Directory.Exists(AdminSealedDBCredentialsAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminSealedDBCredentialsAppRootFolder);
        }
        if (Directory.Exists(SystemResponseAppRootFolder) == false)
        {
            Directory.CreateDirectory(SystemResponseAppRootFolder);
        }

        StartUpFunction();
    }

    private void StartUpFunction()
    {
        if (Directory.Exists(AdminServerIPAppRootFolder) == true)
        {
            if (File.Exists(AdminServerIPAppRootFolder + "IP.txt") == true)
            {
                EstablishConnection.SetSystemServerIPAddress();
                ServerIPTB.Text = APIIPAddressHelper.IPAddress;
            }
        }
    }

    private void AppInitialization()
    {
        AppUIChooser = 0;
        ToggleBTN1.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN2.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN3.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN4.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN5.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN6.IsCheckedChanged += AppToggleBTNSFunction;
    }

    private void AppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (ToggleBTN1.IsChecked == true)
        {
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            AppUIChooser = 1;
        }
        else if (ToggleBTN2.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            AppUIChooser = 2;
        }
        else if (ToggleBTN3.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            AppUIChooser = 3;
        }
        else if (ToggleBTN4.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            AppUIChooser = 4;
        }
        else if (ToggleBTN5.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            AppUIChooser = 5;
        }
        else if (ToggleBTN6.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            AppUIChooser = 6;
        }
        else
        {
            ResetAppUI();
        }
        AppDrawUI();
    }

    private void AppDrawUI()
    {
        if (AppUIChooser == 1)
        {
            if (HasUIRendered == false)
            {
                FirstmyTextBlockArray = new TextBlock[2];
                FirstmyTextBlockArray[0] = new TextBlock();
                FirstmyTextBlockArray[1] = new TextBlock();
                FirstmyTextBlockArray[0].Text = "The Server IP Address of PriSecDBAPI Provider";
                FirstmyTextBlockArray[1].Text = "Server IP Address Status (Read Only)";
                FirstmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstmyTBArray = new TextBox[2];
                FirstmyTBArray[0] = new TextBox();
                FirstmyTBArray[1] = new TextBox();
                FirstmyTBArray[1].IsReadOnly = true;
                FirstmyTBArray[0].AcceptsReturn = true;
                FirstmyTBArray[1].AcceptsReturn = true;
                FirstmyTBArray[0].Height = 100;
                FirstmyTBArray[1].Height = 100;
                FirstmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FirstmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FirstmyButtonArray = new Button[1];
                FirstmyButtonArray[0] = new Button();
                FirstmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FirstmyButtonArray[0].Content = "Set Provider Server IP";
                FirstmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(FirstmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FirstmyTBArray[0]);
                MiddleStackPanel.Children.Add(FirstmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FirstmyTBArray[1]);
                MiddleStackPanel.Children.Add(FirstmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 2)
        {
            if (HasUIRendered == false)
            {
                SecondmyTextBlockArray = new TextBlock[7];
                SecondmyTextBlockArray[0] = new TextBlock();
                SecondmyTextBlockArray[1] = new TextBlock();
                SecondmyTextBlockArray[2] = new TextBlock();
                SecondmyTextBlockArray[3] = new TextBlock();
                SecondmyTextBlockArray[4] = new TextBlock();
                SecondmyTextBlockArray[5] = new TextBlock();
                SecondmyTextBlockArray[6] = new TextBlock();
                SecondmyTextBlockArray[0].Text = "SQL Query String";
                SecondmyTextBlockArray[1].Text = "SQL Parameter Names";
                SecondmyTextBlockArray[2].Text = "SQL Parameter Values";
                SecondmyTextBlockArray[3].Text = "Stream Cipher Algorithms";
                SecondmyTextBlockArray[4].Text = "MAC Algorithms";
                SecondmyTextBlockArray[5].Text = "Is this a lookup table?";
                SecondmyTextBlockArray[6].Text = "Foreign Key Value";
                SecondmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTBArray = new TextBox[4];
                SecondmyTBArray[0] = new TextBox();
                SecondmyTBArray[1] = new TextBox();
                SecondmyTBArray[2] = new TextBox();
                SecondmyTBArray[3] = new TextBox();
                SecondmyTBArray[0].AcceptsReturn = true;
                SecondmyTBArray[1].AcceptsReturn = true;
                SecondmyTBArray[2].AcceptsReturn = true;
                SecondmyTBArray[3].AcceptsReturn = true;
                SecondmyTBArray[0].Height = 75;
                SecondmyTBArray[1].Height = 75;
                SecondmyTBArray[2].Height = 75;
                SecondmyTBArray[3].Height = 75;
                SecondmyTBArray[0].Width = 350;
                SecondmyTBArray[1].Width = 350;
                SecondmyTBArray[2].Width = 350;
                SecondmyTBArray[3].Width = 350;
                SecondmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                SecondmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                SecondmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                SecondmyTBArray[3].TextWrapping = TextWrapping.Wrap;
                FirstmyRBArray = new RadioButton[11];
                FirstmyRBArray[0] = new RadioButton();
                FirstmyRBArray[0].GroupName = "SCA";
                FirstmyRBArray[0].Content = "XChaCha20";
                FirstmyRBArray[0].IsChecked = true;
                FirstmyRBArray[1] = new RadioButton();
                FirstmyRBArray[1].GroupName = "SCA";
                FirstmyRBArray[1].Content = "XSalsa20";
                FirstmyRBArray[2] = new RadioButton();
                FirstmyRBArray[2].GroupName = "SCA";
                FirstmyRBArray[2].Content = "AES256GCM";
                FirstmyRBArray[3] = new RadioButton();
                FirstmyRBArray[3].GroupName = "SCA";
                FirstmyRBArray[3].Content = "SM4-CTR";
                FirstmyRBArray[4] = new RadioButton();
                FirstmyRBArray[4].GroupName = "MACA";
                FirstmyRBArray[4].Content = "HMAC-SHA512";
                FirstmyRBArray[4].IsChecked = true;
                FirstmyRBArray[5] = new RadioButton();
                FirstmyRBArray[5].GroupName = "MACA";
                FirstmyRBArray[5].Content = "Keyed-Blake2B";
                FirstmyRBArray[6] = new RadioButton();
                FirstmyRBArray[6].GroupName = "MACA";
                FirstmyRBArray[6].Content = "Poly1305";
                FirstmyRBArray[7] = new RadioButton();
                FirstmyRBArray[7].GroupName = "MACA";
                FirstmyRBArray[7].Content = "KMAC";
                FirstmyRBArray[8] = new RadioButton();
                FirstmyRBArray[8].GroupName = "MACA";
                FirstmyRBArray[8].Content = "Keccak(M|K)";
                FirstmyRBArray[9] = new RadioButton();
                FirstmyRBArray[9].GroupName = "MACA";
                FirstmyRBArray[9].Content = "SHAKE(M|K)";
                FirstmyRBArray[10] = new RadioButton();
                FirstmyRBArray[10].GroupName = "MACA";
                FirstmyRBArray[10].Content = "HMAC-SM3";
                FirstmyCBArray = new CheckBox[1];
                FirstmyCBArray[0] = new CheckBox();
                FirstmyCBArray[0].Content = "Yes";
                FirstmyCBArray[0].IsChecked = true;
                SecondmyButtonArray = new Button[1];
                SecondmyButtonArray[0] = new Button();
                SecondmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                SecondmyButtonArray[0].Content = "Insert DB Table Record";
                SecondmyButtonArray[0].Click += AppBTN_Click;
                StackPanel SubStackPanelLeft = new StackPanel();
                SubStackPanelLeft.Orientation = Avalonia.Layout.Orientation.Vertical;
                StackPanel SubStackPanelRight = new StackPanel();
                SubStackPanelRight.Orientation = Avalonia.Layout.Orientation.Vertical;
                SubStackPanelRight.Margin = Avalonia.Thickness.Parse("10,0,0,0");
                StackPanel SubStackPanel = new StackPanel();
                SubStackPanel.Orientation = Avalonia.Layout.Orientation.Horizontal;
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[1]);
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[2]);
                SubStackPanelLeft.Children.Add(SecondmyTextBlockArray[3]);
                SubStackPanelLeft.Children.Add(FirstmyRBArray[0]);
                SubStackPanelLeft.Children.Add(FirstmyRBArray[1]);
                SubStackPanelLeft.Children.Add(FirstmyRBArray[2]);
                SubStackPanelLeft.Children.Add(FirstmyRBArray[3]);
                SubStackPanelRight.Children.Add(SecondmyTextBlockArray[4]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[4]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[5]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[6]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[7]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[8]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[9]);
                SubStackPanelRight.Children.Add(FirstmyRBArray[10]);
                SubStackPanel.Children.Add(SubStackPanelLeft);
                SubStackPanel.Children.Add(SubStackPanelRight);
                MiddleStackPanel.Children.Add(SubStackPanel);
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[5]);
                MiddleStackPanel.Children.Add(FirstmyCBArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[6]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[3]);
                MiddleStackPanel.Children.Add(SecondmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 3)
        {
            if (HasUIRendered == false)
            {
                ThirdmyTextBlockArray = new TextBlock[6];
                ThirdmyTextBlockArray[0] = new TextBlock();
                ThirdmyTextBlockArray[1] = new TextBlock();
                ThirdmyTextBlockArray[2] = new TextBlock();
                ThirdmyTextBlockArray[3] = new TextBlock();
                ThirdmyTextBlockArray[4] = new TextBlock();
                ThirdmyTextBlockArray[5] = new TextBlock();
                ThirdmyTextBlockArray[0].Text = "SQL Query String";
                ThirdmyTextBlockArray[1].Text = "SQL Parameter Names";
                ThirdmyTextBlockArray[2].Text = "SQL Parameter Values";
                ThirdmyTextBlockArray[3].Text = "Stream Cipher Algorithms";
                ThirdmyTextBlockArray[4].Text = "MAC Algorithms";
                ThirdmyTextBlockArray[5].Text = "SQL Key Values";
                ThirdmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTBArray = new TextBox[4];
                ThirdmyTBArray[0] = new TextBox();
                ThirdmyTBArray[1] = new TextBox();
                ThirdmyTBArray[2] = new TextBox();
                ThirdmyTBArray[3] = new TextBox();
                ThirdmyTBArray[0].AcceptsReturn = true;
                ThirdmyTBArray[1].AcceptsReturn = true;
                ThirdmyTBArray[2].AcceptsReturn = true;
                ThirdmyTBArray[3].AcceptsReturn = true;
                ThirdmyTBArray[0].Height = 75;
                ThirdmyTBArray[1].Height = 75;
                ThirdmyTBArray[2].Height = 75;
                ThirdmyTBArray[3].Height = 75;
                ThirdmyTBArray[0].Width = 350;
                ThirdmyTBArray[1].Width = 350;
                ThirdmyTBArray[2].Width = 350;
                ThirdmyTBArray[3].Width = 350;
                ThirdmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdmyTBArray[3].TextWrapping = TextWrapping.Wrap;
                SecondmyRBArray = new RadioButton[11];
                SecondmyRBArray[0] = new RadioButton();
                SecondmyRBArray[0].GroupName = "SCA";
                SecondmyRBArray[0].Content = "XChaCha20";
                SecondmyRBArray[0].IsChecked = true;
                SecondmyRBArray[1] = new RadioButton();
                SecondmyRBArray[1].GroupName = "SCA";
                SecondmyRBArray[1].Content = "XSalsa20";
                SecondmyRBArray[2] = new RadioButton();
                SecondmyRBArray[2].GroupName = "SCA";
                SecondmyRBArray[2].Content = "AES256GCM";
                SecondmyRBArray[3] = new RadioButton();
                SecondmyRBArray[3].GroupName = "SCA";
                SecondmyRBArray[3].Content = "SM4-CTR";
                SecondmyRBArray[4] = new RadioButton();
                SecondmyRBArray[4].GroupName = "MACA";
                SecondmyRBArray[4].Content = "HMAC-SHA512";
                SecondmyRBArray[4].IsChecked = true;
                SecondmyRBArray[5] = new RadioButton();
                SecondmyRBArray[5].GroupName = "MACA";
                SecondmyRBArray[5].Content = "Keyed-Blake2B";
                SecondmyRBArray[6] = new RadioButton();
                SecondmyRBArray[6].GroupName = "MACA";
                SecondmyRBArray[6].Content = "Poly1305";
                SecondmyRBArray[7] = new RadioButton();
                SecondmyRBArray[7].GroupName = "MACA";
                SecondmyRBArray[7].Content = "KMAC";
                SecondmyRBArray[8] = new RadioButton();
                SecondmyRBArray[8].GroupName = "MACA";
                SecondmyRBArray[8].Content = "Keccak(M|K)";
                SecondmyRBArray[9] = new RadioButton();
                SecondmyRBArray[9].GroupName = "MACA";
                SecondmyRBArray[9].Content = "SHAKE(M|K)";
                SecondmyRBArray[10] = new RadioButton();
                SecondmyRBArray[10].GroupName = "MACA";
                SecondmyRBArray[10].Content = "HMAC-SM3";
                ThirdmyButtonArray = new Button[1];
                ThirdmyButtonArray[0] = new Button();
                ThirdmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                ThirdmyButtonArray[0].Content = "Insert DB Table Record";
                ThirdmyButtonArray[0].Click += AppBTN_Click;
                StackPanel SubStackPanelLeft = new StackPanel();
                SubStackPanelLeft.Orientation = Avalonia.Layout.Orientation.Vertical;
                StackPanel SubStackPanelRight = new StackPanel();
                SubStackPanelRight.Orientation = Avalonia.Layout.Orientation.Vertical;
                SubStackPanelRight.Margin = Avalonia.Thickness.Parse("10,0,0,0");
                StackPanel SubStackPanel = new StackPanel();
                SubStackPanel.Orientation = Avalonia.Layout.Orientation.Horizontal;
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[0]);
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[1]);
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[2]);
                SubStackPanelLeft.Children.Add(ThirdmyTextBlockArray[3]);
                SubStackPanelLeft.Children.Add(SecondmyRBArray[0]);
                SubStackPanelLeft.Children.Add(SecondmyRBArray[1]);
                SubStackPanelLeft.Children.Add(SecondmyRBArray[2]);
                SubStackPanelLeft.Children.Add(SecondmyRBArray[3]);
                SubStackPanelRight.Children.Add(ThirdmyTextBlockArray[4]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[4]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[5]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[6]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[7]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[8]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[9]);
                SubStackPanelRight.Children.Add(SecondmyRBArray[10]);
                SubStackPanel.Children.Add(SubStackPanelLeft);
                SubStackPanel.Children.Add(SubStackPanelRight);
                MiddleStackPanel.Children.Add(SubStackPanel);
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[5]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[3]);
                MiddleStackPanel.Children.Add(ThirdmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 4)
        {
            if (HasUIRendered == false)
            {
                FourthmyTextBlockArray = new TextBlock[7];
                FourthmyTextBlockArray[0] = new TextBlock();
                FourthmyTextBlockArray[1] = new TextBlock();
                FourthmyTextBlockArray[2] = new TextBlock();
                FourthmyTextBlockArray[3] = new TextBlock();
                FourthmyTextBlockArray[4] = new TextBlock();
                FourthmyTextBlockArray[5] = new TextBlock();
                FourthmyTextBlockArray[6] = new TextBlock();
                FourthmyTextBlockArray[0].Text = "SQL Query String";
                FourthmyTextBlockArray[1].Text = "SQL Parameter Names";
                FourthmyTextBlockArray[2].Text = "SQL Parameter Values";
                FourthmyTextBlockArray[3].Text = "Stream Cipher Algorithms";
                FourthmyTextBlockArray[4].Text = "MAC Algorithms";
                FourthmyTextBlockArray[5].Text = "SQL Key Values";
                FourthmyTextBlockArray[6].Text = "New SQL Key Values";
                FourthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTBArray = new TextBox[5];
                FourthmyTBArray[0] = new TextBox();
                FourthmyTBArray[1] = new TextBox();
                FourthmyTBArray[2] = new TextBox();
                FourthmyTBArray[3] = new TextBox();
                FourthmyTBArray[4] = new TextBox();
                FourthmyTBArray[0].AcceptsReturn = true;
                FourthmyTBArray[1].AcceptsReturn = true;
                FourthmyTBArray[2].AcceptsReturn = true;
                FourthmyTBArray[3].AcceptsReturn = true;
                FourthmyTBArray[4].AcceptsReturn = true;
                FourthmyTBArray[0].Height = 50;
                FourthmyTBArray[1].Height = 50;
                FourthmyTBArray[2].Height = 50;
                FourthmyTBArray[3].Height = 50;
                FourthmyTBArray[4].Height = 50;
                FourthmyTBArray[0].Width = 350;
                FourthmyTBArray[1].Width = 350;
                FourthmyTBArray[2].Width = 350;
                FourthmyTBArray[3].Width = 350;
                FourthmyTBArray[4].Width = 350;
                FourthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FourthmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FourthmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                FourthmyTBArray[3].TextWrapping = TextWrapping.Wrap;
                FourthmyTBArray[4].TextWrapping = TextWrapping.Wrap;
                ThirdmyRBArray = new RadioButton[11];
                ThirdmyRBArray[0] = new RadioButton();
                ThirdmyRBArray[0].GroupName = "SCA";
                ThirdmyRBArray[0].Content = "XChaCha20";
                ThirdmyRBArray[0].IsChecked = true;
                ThirdmyRBArray[1] = new RadioButton();
                ThirdmyRBArray[1].GroupName = "SCA";
                ThirdmyRBArray[1].Content = "XSalsa20";
                ThirdmyRBArray[2] = new RadioButton();
                ThirdmyRBArray[2].GroupName = "SCA";
                ThirdmyRBArray[2].Content = "AES256GCM";
                ThirdmyRBArray[3] = new RadioButton();
                ThirdmyRBArray[3].GroupName = "SCA";
                ThirdmyRBArray[3].Content = "SM4-CTR";
                ThirdmyRBArray[4] = new RadioButton();
                ThirdmyRBArray[4].GroupName = "MACA";
                ThirdmyRBArray[4].Content = "HMAC-SHA512";
                ThirdmyRBArray[4].IsChecked = true;
                ThirdmyRBArray[5] = new RadioButton();
                ThirdmyRBArray[5].GroupName = "MACA";
                ThirdmyRBArray[5].Content = "Keyed-Blake2B";
                ThirdmyRBArray[6] = new RadioButton();
                ThirdmyRBArray[6].GroupName = "MACA";
                ThirdmyRBArray[6].Content = "Poly1305";
                ThirdmyRBArray[7] = new RadioButton();
                ThirdmyRBArray[7].GroupName = "MACA";
                ThirdmyRBArray[7].Content = "KMAC";
                ThirdmyRBArray[8] = new RadioButton();
                ThirdmyRBArray[8].GroupName = "MACA";
                ThirdmyRBArray[8].Content = "Keccak(M|K)";
                ThirdmyRBArray[9] = new RadioButton();
                ThirdmyRBArray[9].GroupName = "MACA";
                ThirdmyRBArray[9].Content = "SHAKE(M|K)";
                ThirdmyRBArray[10] = new RadioButton();
                ThirdmyRBArray[10].GroupName = "MACA";
                ThirdmyRBArray[10].Content = "HMAC-SM3";
                FourthmyButtonArray = new Button[1];
                FourthmyButtonArray[0] = new Button();
                FourthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FourthmyButtonArray[0].Content = "Update DB Table Record";
                FourthmyButtonArray[0].Click += AppBTN_Click;
                StackPanel SubStackPanelLeft = new StackPanel();
                SubStackPanelLeft.Orientation = Avalonia.Layout.Orientation.Vertical;
                StackPanel SubStackPanelRight = new StackPanel();
                SubStackPanelRight.Orientation = Avalonia.Layout.Orientation.Vertical;
                SubStackPanelRight.Margin = Avalonia.Thickness.Parse("10,0,0,0");
                StackPanel SubStackPanel = new StackPanel();
                SubStackPanel.Orientation = Avalonia.Layout.Orientation.Horizontal;
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[0]);
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[1]);
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[2]);
                SubStackPanelLeft.Children.Add(FourthmyTextBlockArray[3]);
                SubStackPanelLeft.Children.Add(ThirdmyRBArray[0]);
                SubStackPanelLeft.Children.Add(ThirdmyRBArray[1]);
                SubStackPanelLeft.Children.Add(ThirdmyRBArray[2]);
                SubStackPanelLeft.Children.Add(ThirdmyRBArray[3]);
                SubStackPanelRight.Children.Add(FourthmyTextBlockArray[4]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[4]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[5]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[6]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[7]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[8]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[9]);
                SubStackPanelRight.Children.Add(ThirdmyRBArray[10]);
                SubStackPanel.Children.Add(SubStackPanelLeft);
                SubStackPanel.Children.Add(SubStackPanelRight);
                MiddleStackPanel.Children.Add(SubStackPanel);
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[5]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[3]);
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[6]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[4]);
                MiddleStackPanel.Children.Add(FourthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 5)
        {
            if (HasUIRendered == false)
            {
                FifthmyTextBlockArray = new TextBlock[5];
                FifthmyTextBlockArray[0] = new TextBlock();
                FifthmyTextBlockArray[1] = new TextBlock();
                FifthmyTextBlockArray[2] = new TextBlock();
                FifthmyTextBlockArray[3] = new TextBlock();
                FifthmyTextBlockArray[4] = new TextBlock();
                FifthmyTextBlockArray[0].Text = "SQL Query String";
                FifthmyTextBlockArray[1].Text = "SQL Parameter Names";
                FifthmyTextBlockArray[2].Text = "SQL Parameter Values";
                FifthmyTextBlockArray[3].Text = "Stream Cipher Algorithms";
                FifthmyTextBlockArray[4].Text = "MAC Algorithms";
                FifthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTBArray = new TextBox[3];
                FifthmyTBArray[0] = new TextBox();
                FifthmyTBArray[1] = new TextBox();
                FifthmyTBArray[2] = new TextBox();
                FifthmyTBArray[0].AcceptsReturn = true;
                FifthmyTBArray[1].AcceptsReturn = true;
                FifthmyTBArray[2].AcceptsReturn = true;
                FifthmyTBArray[0].Height = 75;
                FifthmyTBArray[1].Height = 75;
                FifthmyTBArray[2].Height = 75;
                FifthmyTBArray[0].Width = 350;
                FifthmyTBArray[1].Width = 350;
                FifthmyTBArray[2].Width = 350;
                FifthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FifthmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FifthmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                FourthmyRBArray = new RadioButton[11];
                FourthmyRBArray[0] = new RadioButton();
                FourthmyRBArray[0].GroupName = "SCA";
                FourthmyRBArray[0].Content = "XChaCha20";
                FourthmyRBArray[0].IsChecked = true;
                FourthmyRBArray[1] = new RadioButton();
                FourthmyRBArray[1].GroupName = "SCA";
                FourthmyRBArray[1].Content = "XSalsa20";
                FourthmyRBArray[2] = new RadioButton();
                FourthmyRBArray[2].GroupName = "SCA";
                FourthmyRBArray[2].Content = "AES256GCM";
                FourthmyRBArray[3] = new RadioButton();
                FourthmyRBArray[3].GroupName = "SCA";
                FourthmyRBArray[3].Content = "SM4-CTR";
                FourthmyRBArray[4] = new RadioButton();
                FourthmyRBArray[4].GroupName = "MACA";
                FourthmyRBArray[4].Content = "HMAC-SHA512";
                FourthmyRBArray[4].IsChecked = true;
                FourthmyRBArray[5] = new RadioButton();
                FourthmyRBArray[5].GroupName = "MACA";
                FourthmyRBArray[5].Content = "Keyed-Blake2B";
                FourthmyRBArray[6] = new RadioButton();
                FourthmyRBArray[6].GroupName = "MACA";
                FourthmyRBArray[6].Content = "Poly1305";
                FourthmyRBArray[7] = new RadioButton();
                FourthmyRBArray[7].GroupName = "MACA";
                FourthmyRBArray[7].Content = "KMAC";
                FourthmyRBArray[8] = new RadioButton();
                FourthmyRBArray[8].GroupName = "MACA";
                FourthmyRBArray[8].Content = "Keccak(M|K)";
                FourthmyRBArray[9] = new RadioButton();
                FourthmyRBArray[9].GroupName = "MACA";
                FourthmyRBArray[9].Content = "SHAKE(M|K)";
                FourthmyRBArray[10] = new RadioButton();
                FourthmyRBArray[10].GroupName = "MACA";
                FourthmyRBArray[10].Content = "HMAC-SM3";
                FifthmyButtonArray = new Button[1];
                FifthmyButtonArray[0] = new Button();
                FifthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FifthmyButtonArray[0].Content = "Select DB Table Record";
                FifthmyButtonArray[0].Click += AppBTN_Click;
                StackPanel SubStackPanelLeft = new StackPanel();
                SubStackPanelLeft.Orientation = Avalonia.Layout.Orientation.Vertical;
                StackPanel SubStackPanelRight = new StackPanel();
                SubStackPanelRight.Orientation = Avalonia.Layout.Orientation.Vertical;
                SubStackPanelRight.Margin = Avalonia.Thickness.Parse("10,0,0,0");
                StackPanel SubStackPanel = new StackPanel();
                SubStackPanel.Orientation = Avalonia.Layout.Orientation.Horizontal;
                MiddleStackPanel.Children.Add(FifthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FifthmyTBArray[0]);
                MiddleStackPanel.Children.Add(FifthmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FifthmyTBArray[1]);
                MiddleStackPanel.Children.Add(FifthmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(FifthmyTBArray[2]);
                SubStackPanelLeft.Children.Add(FifthmyTextBlockArray[3]);
                SubStackPanelLeft.Children.Add(FourthmyRBArray[0]);
                SubStackPanelLeft.Children.Add(FourthmyRBArray[1]);
                SubStackPanelLeft.Children.Add(FourthmyRBArray[2]);
                SubStackPanelLeft.Children.Add(FourthmyRBArray[3]);
                SubStackPanelRight.Children.Add(FifthmyTextBlockArray[4]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[4]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[5]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[6]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[7]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[8]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[9]);
                SubStackPanelRight.Children.Add(FourthmyRBArray[10]);
                SubStackPanel.Children.Add(SubStackPanelLeft);
                SubStackPanel.Children.Add(SubStackPanelRight);
                MiddleStackPanel.Children.Add(SubStackPanel);
                MiddleStackPanel.Children.Add(FifthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 6)
        {
            if (HasUIRendered == false)
            {
                SixthmyTextBlockArray = new TextBlock[3];
                SixthmyTextBlockArray[0] = new TextBlock();
                SixthmyTextBlockArray[1] = new TextBlock();
                SixthmyTextBlockArray[2] = new TextBlock();
                SixthmyTextBlockArray[0].Text = "SQL Query String";
                SixthmyTextBlockArray[1].Text = "SQL Parameter Names";
                SixthmyTextBlockArray[2].Text = "SQL Parameter Values";
                SixthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthmyTBArray = new TextBox[3];
                SixthmyTBArray[0] = new TextBox();
                SixthmyTBArray[1] = new TextBox();
                SixthmyTBArray[2] = new TextBox();
                SixthmyTBArray[0].AcceptsReturn = true;
                SixthmyTBArray[1].AcceptsReturn = true;
                SixthmyTBArray[2].AcceptsReturn = true;
                SixthmyTBArray[0].Height = 75;
                SixthmyTBArray[1].Height = 75;
                SixthmyTBArray[2].Height = 75;
                SixthmyTBArray[0].Width = 350;
                SixthmyTBArray[1].Width = 350;
                SixthmyTBArray[2].Width = 350;
                SixthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                SixthmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                SixthmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                SixthmyButtonArray = new Button[1];
                SixthmyButtonArray[0] = new Button();
                SixthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                SixthmyButtonArray[0].Content = "Delete DB Table Record";
                SixthmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(SixthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(SixthmyTBArray[0]);
                MiddleStackPanel.Children.Add(SixthmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(SixthmyTBArray[1]);
                MiddleStackPanel.Children.Add(SixthmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(SixthmyTBArray[2]);
                MiddleStackPanel.Children.Add(SixthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else
        {
            ResetAppUI();
        }
    }

    private void ResetAppUI()
    {
        ToggleBTN1.IsChecked = false;
        ToggleBTN2.IsChecked = false;
        ToggleBTN3.IsChecked = false;
        ToggleBTN4.IsChecked = false;
        ToggleBTN5.IsChecked = false;
        ToggleBTN6.IsChecked = false;
        AppUIChooser = 0;
        MiddleStackPanel.Children.Clear();
        HasUIRendered = false;
    }

    private void AppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (AppUIChooser == 1)
        {
            if (FirstmyTBArray[0].Text != null && FirstmyTBArray[0].Text.CompareTo("") != 0)
            {
                File.WriteAllText(AdminServerIPAppRootFolder + "IP.txt", FirstmyTBArray[0].Text);
                FirstmyTBArray[1].Text = "Created Server IP file";
                ServerIPTB.Text = FirstmyTBArray[0].Text;
                APIIPAddressHelper.IPAddress = FirstmyTBArray[0].Text;
                APIIPAddressHelper.HasSet = true;
            }
        }
        else if (AppUIChooser == 2)
        {
            if (CredentialsSetter.DoesCredentialsExist()==true) 
            {
                CredentialsSetter.SetCredentials();
                String SQLQuery = "";
                String[] SQLParameterNames = new String[] { };
                String[] SQLParameterValues = new String[] { };
                String SQLForeignKey = "";
                if (SecondmyTBArray[0].Text != null && SecondmyTBArray[0].Text.CompareTo("") != 0
                        && SecondmyTBArray[1].Text != null && SecondmyTBArray[1].Text.CompareTo("") != 0
                        && SecondmyTBArray[2].Text != null && SecondmyTBArray[2].Text.CompareTo("") != 0)
                {
                    SQLQuery = SecondmyTBArray[0].Text;
                    SQLParameterNames = SecondmyTBArray[1].Text.Split(",");
                    SQLParameterValues = SecondmyTBArray[2].Text.Split(",");
                }
                if (FirstmyCBArray[0].IsChecked == false)
                {
                    if (SecondmyTBArray[3].Text != null && SecondmyTBArray[3].Text.CompareTo("") != 0)
                    {
                        SQLForeignKey = SecondmyTBArray[3].Text;
                    }
                }
                int SCAlgorithm = 0;
                int MACAlgorithm = 0;
                if (FirstmyRBArray[0].IsChecked == true)
                {
                    SCAlgorithm = 1;
                }
                else if (FirstmyRBArray[1].IsChecked == true)
                {
                    SCAlgorithm = 2;
                }
                else if (FirstmyRBArray[2].IsChecked == true)
                {
                    SCAlgorithm = 3;
                }
                else if (FirstmyRBArray[3].IsChecked == true) 
                {
                    SCAlgorithm = 4;
                }
                if (FirstmyRBArray[4].IsChecked == true)
                {
                    MACAlgorithm = 1;
                }
                else if (FirstmyRBArray[5].IsChecked == true)
                {
                    MACAlgorithm = 2;
                }
                else if (FirstmyRBArray[6].IsChecked == true)
                {
                    MACAlgorithm = 3;
                }
                else if (FirstmyRBArray[7].IsChecked == true)
                {
                    MACAlgorithm = 4;
                }
                else if (FirstmyRBArray[8].IsChecked == true)
                {
                    MACAlgorithm = 5;
                }
                else if (FirstmyRBArray[9].IsChecked == true)
                {
                    MACAlgorithm = 6;
                }
                else if (FirstmyRBArray[10].IsChecked == true)
                {
                    MACAlgorithm = 7;
                }
                int loop = 0;
                String[] Base64SQLParameterNames = new String[SQLParameterNames.Length];
                String[] Base64SQLParameterValues = new String[SQLParameterValues.Length];
                while (loop < Base64SQLParameterNames.Length) 
                {
                    Base64SQLParameterNames[loop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterNames[loop]));
                    Base64SQLParameterValues[loop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterValues[loop]));
                    loop += 1;
                }
                NormalDBInsertModel MyDBInsertModel = new NormalDBInsertModel();
                MyDBInsertModel.MyDBCredentialModel = new SealedDBCredentialModel();
                MyDBInsertModel.SECipherAlgorithm = SCAlgorithm;
                MyDBInsertModel.MACAlgorithm = MACAlgorithm;
                MyDBInsertModel.Base64ParameterName = Base64SQLParameterNames;
                MyDBInsertModel.Base64ParameterValue = Base64SQLParameterValues;
                MyDBInsertModel.Base64QueryString = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLQuery));
                MyDBInsertModel.IsPrimaryKeyTable = (FirstmyCBArray[0].IsChecked == true);
                MyDBInsertModel.ForeignKeyID = SQLForeignKey;
                MyDBInsertModel.UniquePaymentID = CredentialsSetter.PaymentID;
                MyDBInsertModel.MyDBCredentialModel.SealedSessionID = CredentialsSetter.SealedETLSID;
                MyDBInsertModel.MyDBCredentialModel.SealedDBUserName = CredentialsSetter.SealedDBUserName;
                MyDBInsertModel.MyDBCredentialModel.SealedDBUserNameHMAC = CredentialsSetter.SealedDBUserNameHMAC;
                MyDBInsertModel.MyDBCredentialModel.SealedDBUserPassword = CredentialsSetter.SealedDBUserPassword;
                MyDBInsertModel.MyDBCredentialModel.SealedDBUserPasswordHMAC = CredentialsSetter.SealedDBUserPasswordHMAC;
                MyDBInsertModel.MyDBCredentialModel.SealedDBName = CredentialsSetter.SealedDBName;
                MyDBInsertModel.MyDBCredentialModel.SealedDBNameHMAC = CredentialsSetter.SealedDBNameHMAC;
                String JSONBodyString = "";
                StringContent PostRequestData = new StringContent("");
                JSONBodyString = JsonConvert.SerializeObject(MyDBInsertModel);
                File.WriteAllText(SystemResponseAppRootFolder + "SampleJSONStringForDeveloper.txt", JSONBodyString);
                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.PostAsync("NormalSealedDHDBInsert", PostRequestData);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;
                        String NewResult = Result.Substring(1, Result.Length - 2);
                        File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", NewResult);
                    }
                    else
                    {
                        File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", "There's something wrong on the server side..");
                    }
                }
            }
        }
        else if (AppUIChooser == 3)
        {
            if (CredentialsSetter.DoesCredentialsExist() == true)
            {
                CredentialsSetter.SetCredentials();
                if (ThirdmyTBArray[0].Text != null && ThirdmyTBArray[0].Text.CompareTo("") != 0
                        && ThirdmyTBArray[3].Text != null && ThirdmyTBArray[3].Text.CompareTo("") != 0)
                {
                    String SQLQuery = "";
                    String[] SQLParameterNames = new String[] { };
                    String[] SQLParameterValues = new String[] { };
                    String[] PrimaryKeyValues = new String[] { };
                    SQLQuery = ThirdmyTBArray[0].Text;
                    if (ThirdmyTBArray[1].Text != null && ThirdmyTBArray[1].Text.CompareTo("") != 0
                        && ThirdmyTBArray[2].Text != null && ThirdmyTBArray[2].Text.CompareTo("") != 0) 
                    {
                        SQLParameterNames = ThirdmyTBArray[1].Text.Split(",");
                        SQLParameterValues = ThirdmyTBArray[2].Text.Split(",");
                    }
                    PrimaryKeyValues = ThirdmyTBArray[3].Text.Split(",");
                    int SCAlgorithm = 0;
                    int MACAlgorithm = 0;
                    if (SecondmyRBArray[0].IsChecked == true)
                    {
                        SCAlgorithm = 1;
                    }
                    else if (SecondmyRBArray[1].IsChecked == true)
                    {
                        SCAlgorithm = 2;
                    }
                    else if (SecondmyRBArray[2].IsChecked == true)
                    {
                        SCAlgorithm = 3;
                    }
                    else if (SecondmyRBArray[3].IsChecked == true)
                    {
                        SCAlgorithm = 4;
                    }
                    if (SecondmyRBArray[4].IsChecked == true)
                    {
                        MACAlgorithm = 1;
                    }
                    else if (SecondmyRBArray[5].IsChecked == true)
                    {
                        MACAlgorithm = 2;
                    }
                    else if (SecondmyRBArray[6].IsChecked == true)
                    {
                        MACAlgorithm = 3;
                    }
                    else if (SecondmyRBArray[7].IsChecked == true)
                    {
                        MACAlgorithm = 4;
                    }
                    else if (SecondmyRBArray[8].IsChecked == true)
                    {
                        MACAlgorithm = 5;
                    }
                    else if (SecondmyRBArray[9].IsChecked == true)
                    {
                        MACAlgorithm = 6;
                    }
                    else if (SecondmyRBArray[10].IsChecked == true)
                    {
                        MACAlgorithm = 7;
                    }
                    int loop = 0;
                    String[] Base64SQLParameterNames = new String[SQLParameterNames.Length];
                    String[] Base64SQLParameterValues = new String[SQLParameterValues.Length];
                    while (loop < Base64SQLParameterNames.Length)
                    {
                        Base64SQLParameterNames[loop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterNames[loop]));
                        Base64SQLParameterValues[loop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterValues[loop]));
                        loop += 1;
                    }
                    SpecialDBModel MySpecialDBModel = new SpecialDBModel();
                    MySpecialDBModel.MyDBCredentialModel = new SealedDBCredentialModel();
                    MySpecialDBModel.SECipherAlgorithm = SCAlgorithm;
                    MySpecialDBModel.MACAlgorithm = MACAlgorithm;
                    if (SQLParameterNames.Length == 0) 
                    {
                        MySpecialDBModel.Base64ParameterName = SQLParameterNames;
                        MySpecialDBModel.Base64ParameterValue = SQLParameterValues;
                    }
                    else 
                    {
                        MySpecialDBModel.Base64ParameterName = Base64SQLParameterNames;
                        MySpecialDBModel.Base64ParameterValue = Base64SQLParameterValues;
                    }
                    MySpecialDBModel.Base64QueryString = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLQuery));
                    MySpecialDBModel.IDValue = PrimaryKeyValues;
                    MySpecialDBModel.NewIDValue = new String[] { };
                    MySpecialDBModel.UniquePaymentID = CredentialsSetter.PaymentID;
                    MySpecialDBModel.MyDBCredentialModel.SealedSessionID = CredentialsSetter.SealedETLSID;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserName = CredentialsSetter.SealedDBUserName;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserNameHMAC = CredentialsSetter.SealedDBUserNameHMAC;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserPassword = CredentialsSetter.SealedDBUserPassword;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserPasswordHMAC = CredentialsSetter.SealedDBUserPasswordHMAC;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBName = CredentialsSetter.SealedDBName;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBNameHMAC = CredentialsSetter.SealedDBNameHMAC;
                    String JSONBodyString = "";
                    StringContent PostRequestData = new StringContent("");
                    JSONBodyString = JsonConvert.SerializeObject(MySpecialDBModel);
                    File.WriteAllText(SystemResponseAppRootFolder + "SampleJSONStringForDeveloper.txt", JSONBodyString);
                    PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.PostAsync("SpecialSealedDHDBInsert", PostRequestData);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            String NewResult = Result.Substring(1, Result.Length - 2);
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", NewResult);
                        }
                        else
                        {
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", "There's something wrong on the server side..");
                        }
                    }
                }
            }
        }
        else if (AppUIChooser == 4)
        {
            if (CredentialsSetter.DoesCredentialsExist() == true)
            {
                CredentialsSetter.SetCredentials();
                if (FourthmyTBArray[0].Text != null && FourthmyTBArray[0].Text.CompareTo("") != 0
                        && FourthmyTBArray[3].Text != null && FourthmyTBArray[3].Text.CompareTo("") != 0)
                {
                    String SQLQuery = "";
                    String[] SQLParameterNames = new String[] { };
                    String[] SQLParameterValues = new String[] { };
                    String[] PrimaryKeyValues = new String[] { };
                    SQLQuery = FourthmyTBArray[0].Text;
                    if (FourthmyTBArray[1].Text != null && FourthmyTBArray[1].Text.CompareTo("") != 0
                        && FourthmyTBArray[2].Text != null && FourthmyTBArray[2].Text.CompareTo("") != 0) 
                    {
                        SQLParameterNames = FourthmyTBArray[1].Text.Split(",");
                        SQLParameterValues = FourthmyTBArray[2].Text.Split(",");
                    }
                    PrimaryKeyValues = FourthmyTBArray[3].Text.Split(",");
                    int SCAlgorithm = 0;
                    int MACAlgorithm = 0;
                    if (ThirdmyRBArray[0].IsChecked == true)
                    {
                        SCAlgorithm = 1;
                    }
                    else if (ThirdmyRBArray[1].IsChecked == true)
                    {
                        SCAlgorithm = 2;
                    }
                    else if (ThirdmyRBArray[2].IsChecked == true)
                    {
                        SCAlgorithm = 3;
                    }
                    else if (ThirdmyRBArray[3].IsChecked == true)
                    {
                        SCAlgorithm = 4;
                    }
                    if (ThirdmyRBArray[4].IsChecked == true)
                    {
                        MACAlgorithm = 1;
                    }
                    else if (ThirdmyRBArray[5].IsChecked == true)
                    {
                        MACAlgorithm = 2;
                    }
                    else if (ThirdmyRBArray[6].IsChecked == true)
                    {
                        MACAlgorithm = 3;
                    }
                    else if (ThirdmyRBArray[7].IsChecked == true)
                    {
                        MACAlgorithm = 4;
                    }
                    else if (ThirdmyRBArray[8].IsChecked == true)
                    {
                        MACAlgorithm = 5;
                    }
                    else if (ThirdmyRBArray[9].IsChecked == true)
                    {
                        MACAlgorithm = 6;
                    }
                    else if (ThirdmyRBArray[10].IsChecked == true)
                    {
                        MACAlgorithm = 7;
                    }
                    int loop = 0;
                    String[] Base64SQLParameterNames = new String[SQLParameterNames.Length];
                    String[] Base64SQLParameterValues = new String[SQLParameterValues.Length];
                    while (loop < Base64SQLParameterNames.Length)
                    {
                        Base64SQLParameterNames[loop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterNames[loop]));
                        Base64SQLParameterValues[loop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterValues[loop]));
                        loop += 1;
                    }
                    SpecialDBModel MySpecialDBModel = new SpecialDBModel();
                    MySpecialDBModel.MyDBCredentialModel = new SealedDBCredentialModel();
                    MySpecialDBModel.SECipherAlgorithm = SCAlgorithm;
                    MySpecialDBModel.MACAlgorithm = MACAlgorithm;
                    if (SQLParameterNames.Length == 0) 
                    {
                        MySpecialDBModel.Base64ParameterName = SQLParameterNames;
                        MySpecialDBModel.Base64ParameterValue = SQLParameterValues;
                    }
                    else 
                    {
                        MySpecialDBModel.Base64ParameterName = Base64SQLParameterNames;
                        MySpecialDBModel.Base64ParameterValue = Base64SQLParameterValues;
                    }
                    MySpecialDBModel.Base64QueryString = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLQuery));
                    MySpecialDBModel.IDValue = PrimaryKeyValues;
                    if (FourthmyTBArray[4].Text!=null && FourthmyTBArray[4].Text.CompareTo("") != 0) 
                    {
                        MySpecialDBModel.NewIDValue = FourthmyTBArray[4].Text.Split(",");
                    }
                    else 
                    {
                        MySpecialDBModel.NewIDValue = new String[] { };
                    }
                    MySpecialDBModel.UniquePaymentID = CredentialsSetter.PaymentID;
                    MySpecialDBModel.MyDBCredentialModel.SealedSessionID = CredentialsSetter.SealedETLSID;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserName = CredentialsSetter.SealedDBUserName;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserNameHMAC = CredentialsSetter.SealedDBUserNameHMAC;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserPassword = CredentialsSetter.SealedDBUserPassword;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBUserPasswordHMAC = CredentialsSetter.SealedDBUserPasswordHMAC;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBName = CredentialsSetter.SealedDBName;
                    MySpecialDBModel.MyDBCredentialModel.SealedDBNameHMAC = CredentialsSetter.SealedDBNameHMAC;
                    String JSONBodyString = "";
                    StringContent PostRequestData = new StringContent("");
                    JSONBodyString = JsonConvert.SerializeObject(MySpecialDBModel);
                    File.WriteAllText(SystemResponseAppRootFolder + "SampleJSONStringForDeveloper.txt", JSONBodyString);
                    PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.PostAsync("SpecialSealedDHDBUpdate", PostRequestData);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            String NewResult = Result.Substring(1, Result.Length - 2);
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", NewResult);
                        }
                        else
                        {
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", "There's something wrong on the server side..");
                        }
                    }
                }
            }
        }
        else if (AppUIChooser == 5)
        {
            if (CredentialsSetter.DoesCredentialsExist() == true)
            {
                CredentialsSetter.SetCredentials();
                if (FifthmyTBArray[0].Text != null && FifthmyTBArray[0].Text.CompareTo("") != 0)
                {
                    String SQLQuery = "";
                    String[] SQLParameterNames = new String[] { };
                    String[] SQLParameterValues = new String[] { };
                    SQLQuery = FifthmyTBArray[0].Text;
                    if (FifthmyTBArray[1].Text != null && FifthmyTBArray[1].Text.CompareTo("") != 0
                        && FifthmyTBArray[2].Text != null && FifthmyTBArray[2].Text.CompareTo("") != 0) 
                    {
                        SQLParameterNames = FifthmyTBArray[1].Text.Split(",");
                        SQLParameterValues = FifthmyTBArray[2].Text.Split(",");
                    }
                    String[] Base64SQLParameterNames = new String[SQLParameterNames.Length];
                    String[] Base64SQLParameterValues = new String[SQLParameterValues.Length];
                    int ploop = 0;
                    while (ploop < SQLParameterNames.Length) 
                    {
                        Base64SQLParameterNames[ploop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterNames[ploop]));
                        Base64SQLParameterValues[ploop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterValues[ploop]));
                        ploop += 1;
                    }
                    SpecialSelectDBModel MySelectDBModel = new SpecialSelectDBModel();
                    MySelectDBModel.MyDBCredentialModel = new SealedDBCredentialModel();
                    if (SQLParameterNames.Length == 0) 
                    {
                        MySelectDBModel.Base64ParameterName = SQLParameterNames;
                        MySelectDBModel.Base64ParameterValue = SQLParameterValues;
                    }
                    else 
                    {
                        MySelectDBModel.Base64ParameterName = Base64SQLParameterNames;
                        MySelectDBModel.Base64ParameterValue = Base64SQLParameterValues;
                    }
                    MySelectDBModel.Base64QueryString = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLQuery));
                    MySelectDBModel.UniquePaymentID = CredentialsSetter.PaymentID;
                    MySelectDBModel.MyDBCredentialModel.SealedSessionID = CredentialsSetter.SealedETLSID;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserName = CredentialsSetter.SealedDBUserName;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserNameHMAC = CredentialsSetter.SealedDBUserNameHMAC;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserPassword = CredentialsSetter.SealedDBUserPassword;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserPasswordHMAC = CredentialsSetter.SealedDBUserPasswordHMAC;
                    MySelectDBModel.MyDBCredentialModel.SealedDBName = CredentialsSetter.SealedDBName;
                    MySelectDBModel.MyDBCredentialModel.SealedDBNameHMAC = CredentialsSetter.SealedDBNameHMAC;
                    String JSONBodyString = "";
                    StringContent PostRequestData = new StringContent("");
                    JSONBodyString = JsonConvert.SerializeObject(MySelectDBModel);
                    File.WriteAllText(SystemResponseAppRootFolder + "SampleJSONStringForDeveloper.txt", JSONBodyString);
                    PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.PostAsync("SpecialSelectDBRecord", PostRequestData);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            DBRecordsModel MyDBRecordsModel = new DBRecordsModel();
                            MyDBRecordsModel = JsonConvert.DeserializeObject<DBRecordsModel>(Result);
                            if (MyDBRecordsModel.Status.Contains("Error") == false)
                            {
                                int loop = 0;
                                String DecryptedResults = "";
                                while (loop < MyDBRecordsModel.ParameterValues.Length)
                                {
                                    Byte[] OriginalEncryptedParameterValueByte = Convert.FromBase64String(MyDBRecordsModel.ParameterValues[loop]);
                                    Byte[] MAC = new Byte[] { };
                                    //These represent MAC algorithms supported.
                                    //For now, KMAC has library issue.
                                    //which will be solved in BCASodium
                                    if (FourthmyRBArray[4].IsChecked == true)
                                    {
                                        MAC = new Byte[SodiumHMACSHA512.GetComputedMACLength()];
                                    }
                                    else if (FourthmyRBArray[5].IsChecked == true)
                                    {
                                        MAC = new Byte[64];
                                    }
                                    else if (FourthmyRBArray[6].IsChecked == true)
                                    {
                                        MAC = new Byte[SodiumOneTimeAuth.GetPoly1305MACLength()];
                                    }
                                    else if (FourthmyRBArray[7].IsChecked == true)
                                    {
                                        MAC = new Byte[64];
                                    }
                                    else if (FourthmyRBArray[8].IsChecked == true)
                                    {
                                        MAC = new Byte[64];
                                    }
                                    else if (FourthmyRBArray[9].IsChecked == true)
                                    {
                                        MAC = new Byte[64];
                                    }
                                    else if (FourthmyRBArray[10].IsChecked == true)
                                    {
                                        MAC = new Byte[32];
                                    }
                                    Array.Copy(OriginalEncryptedParameterValueByte, 0, MAC, 0, MAC.Length);
                                    Byte[] EncryptedParameterValueByte = new Byte[OriginalEncryptedParameterValueByte.Length - MAC.Length];
                                    Array.Copy(OriginalEncryptedParameterValueByte, MAC.Length, EncryptedParameterValueByte, 0, EncryptedParameterValueByte.Length);
                                    Boolean AbleToVerifyMAC = true;
                                    Byte[] EphemeralX25519SEPK = new Byte[32];
                                    Byte[] EphemeralX25519MACPK = new Byte[32];
                                    Byte[] SEKey = new Byte[] { };
                                    Byte[] MACKey = new Byte[] { };
                                    if (FourthmyRBArray[0].IsChecked == true)
                                    {
                                        Array.Copy(EncryptedParameterValueByte, 0, EphemeralX25519SEPK, 0, EphemeralX25519SEPK.Length);
                                        Array.Copy(EncryptedParameterValueByte, EphemeralX25519SEPK.Length, EphemeralX25519MACPK, 0, EphemeralX25519MACPK.Length);
                                    }
                                    else if (FourthmyRBArray[1].IsChecked == true)
                                    {
                                        Array.Copy(EncryptedParameterValueByte, 0, EphemeralX25519SEPK, 0, EphemeralX25519SEPK.Length);
                                        Array.Copy(EncryptedParameterValueByte, EphemeralX25519SEPK.Length, EphemeralX25519MACPK, 0, EphemeralX25519MACPK.Length);
                                    }
                                    else if (FourthmyRBArray[2].IsChecked == true)
                                    {
                                        Array.Copy(EncryptedParameterValueByte, SodiumSecretAeadAES256GCM.GetNoncePublicLength(), EphemeralX25519SEPK, 0, EphemeralX25519SEPK.Length);
                                        Array.Copy(EncryptedParameterValueByte, EphemeralX25519SEPK.Length + SodiumSecretAeadAES256GCM.GetNoncePublicLength(), EphemeralX25519MACPK, 0, EphemeralX25519MACPK.Length);
                                    }
                                    else if (FourthmyRBArray[3].IsChecked == true)
                                    {
                                        Byte[] NonceLengthBytes = new Byte[4];
                                        Array.Copy(EncryptedParameterValueByte, 0, NonceLengthBytes, 0, NonceLengthBytes.Length);
                                        int NonceLength = BitConverter.ToInt32(NonceLengthBytes);
                                        Array.Copy(EncryptedParameterValueByte, 4 + NonceLength, EphemeralX25519SEPK, 0, EphemeralX25519SEPK.Length);
                                        Array.Copy(EncryptedParameterValueByte, 4 + NonceLength + EphemeralX25519MACPK.Length, EphemeralX25519MACPK, 0, EphemeralX25519MACPK.Length);
                                    }
                                    SEKey = SodiumScalarMult.Mult(CredentialsSetter.X25519SESK, EphemeralX25519SEPK);
                                    MACKey = SodiumScalarMult.Mult(CredentialsSetter.X25519MACSK, EphemeralX25519MACPK);
                                    Byte[] Nonce = new Byte[] { };
                                    if (FourthmyRBArray[4].IsChecked == true)
                                    {
                                        AbleToVerifyMAC = SodiumHMACSHA512.VerifyMAC(MAC, EncryptedParameterValueByte, MACKey);
                                    }
                                    else if (FourthmyRBArray[5].IsChecked == true)
                                    {
                                        Byte[] MyMAC = SodiumGenericHash.ComputeHash(64, EncryptedParameterValueByte, MACKey);
                                        try
                                        {
                                            SodiumHelper.Sodium_Memory_Compare(MyMAC, MAC);
                                        }
                                        catch
                                        {
                                            AbleToVerifyMAC = false;
                                        }
                                    }
                                    else if (FourthmyRBArray[6].IsChecked == true)
                                    {
                                        AbleToVerifyMAC = SodiumOneTimeAuth.VerifyPoly1305MAC(MAC, EncryptedParameterValueByte, MACKey);
                                    }
                                    else if (FourthmyRBArray[7].IsChecked == true)
                                    {
                                        AbleToVerifyMAC = KMACHelper.VerifyKMAC(MAC, EncryptedParameterValueByte, MACKey);
                                    }
                                    else if (FourthmyRBArray[8].IsChecked == true)
                                    {
                                        Byte[] MyMAC = KeccakDigestAlgorithm.ComputeHash(MACKey.Concat(EncryptedParameterValueByte).ToArray(), KeccakDigestAlgorithm.Digest_Length.Digest_512bits);
                                        try
                                        {
                                            SodiumHelper.Sodium_Memory_Compare(MyMAC, MAC);
                                        }
                                        catch
                                        {
                                            AbleToVerifyMAC = false;
                                        }
                                    }
                                    else if (FourthmyRBArray[9].IsChecked == true)
                                    {
                                        Byte[] MyMAC = SHAKEDigest.ComputeHash(MACKey.Concat(EncryptedParameterValueByte).ToArray(), SHAKEDigest.Digest_Length.Digest_256bits);
                                        try
                                        {
                                            SodiumHelper.Sodium_Memory_Compare(MyMAC,MAC);
                                        }
                                        catch
                                        {
                                            AbleToVerifyMAC = false;
                                        }
                                    }
                                    else if (FourthmyRBArray[10].IsChecked == true)
                                    {
                                        AbleToVerifyMAC = HMACHelper.VerifyHMAC(new SM3Digest(), EncryptedParameterValueByte, MAC, MACKey, true);
                                    }
                                    if (AbleToVerifyMAC == true)
                                    {
                                        Byte[] PureEncryptedParameterValueByte = new Byte[] { };
                                        Byte[] PlainTextByte = new Byte[] { };
                                        if (FourthmyRBArray[0].IsChecked == true)
                                        {
                                            Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), CredentialsSetter.X25519SEPK.Concat(EphemeralX25519SEPK)
                                                .Concat(CredentialsSetter.X25519MACPK).Concat(EphemeralX25519MACPK).ToArray());
                                            PureEncryptedParameterValueByte = new Byte[EncryptedParameterValueByte.Length - 64];
                                            Array.Copy(EncryptedParameterValueByte, 64, PureEncryptedParameterValueByte, 0, PureEncryptedParameterValueByte.Length);
                                            PlainTextByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(PureEncryptedParameterValueByte, Nonce, SEKey, true);
                                        }
                                        else if (FourthmyRBArray[1].IsChecked == true)
                                        {
                                            Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXSalsa20.GetXSalsa20NonceBytesLength(), CredentialsSetter.X25519SEPK.Concat(EphemeralX25519SEPK)
                                                .Concat(CredentialsSetter.X25519MACPK).Concat(EphemeralX25519MACPK).ToArray());
                                            PureEncryptedParameterValueByte = new Byte[EncryptedParameterValueByte.Length - 64];
                                            Array.Copy(EncryptedParameterValueByte, 64, PureEncryptedParameterValueByte, 0, PureEncryptedParameterValueByte.Length);
                                            PlainTextByte = SodiumStreamCipherXSalsa20.XSalsa20Decrypt(PureEncryptedParameterValueByte, Nonce, SEKey, true);
                                        }
                                        else if (FourthmyRBArray[2].IsChecked == true)
                                        {
                                            Nonce = new Byte[SodiumSecretAeadAES256GCM.GetNoncePublicLength()];
                                            Array.Copy(EncryptedParameterValueByte, 0, Nonce, 0, Nonce.Length);
                                            PureEncryptedParameterValueByte = new Byte[EncryptedParameterValueByte.Length - Nonce.Length - 64];
                                            Array.Copy(EncryptedParameterValueByte, Nonce.Length + 64, PureEncryptedParameterValueByte, 0, PureEncryptedParameterValueByte.Length);
                                            PlainTextByte = SodiumSecretAeadAES256GCM.Decrypt(PureEncryptedParameterValueByte, Nonce, SEKey, null, null, true);
                                        }
                                        else if (FourthmyRBArray[3].IsChecked == true)
                                        {
                                            Byte[] NonceLengthBytes = new Byte[4];
                                            Array.Copy(EncryptedParameterValueByte, 0, NonceLengthBytes, 0, NonceLengthBytes.Length);
                                            int NonceLength = BitConverter.ToInt32(NonceLengthBytes);
                                            Nonce = new Byte[NonceLength];
                                            Array.Copy(EncryptedParameterValueByte, 4, Nonce, 0, Nonce.Length);
                                            PureEncryptedParameterValueByte = new Byte[EncryptedParameterValueByte.Length - NonceLengthBytes.Length - NonceLength - 64];
                                            Array.Copy(EncryptedParameterValueByte, 4 +Nonce.Length + 64, PureEncryptedParameterValueByte, 0, PureEncryptedParameterValueByte.Length);
                                            Byte[] TempSEKey = SodiumGenericHash.ComputeHash(16, SEKey);
                                            PlainTextByte = CNSM4.CTR_Mode_Decrypt(PureEncryptedParameterValueByte, Nonce, TempSEKey, MACKey, true);
                                            SodiumSecureMemory.SecureClearBytes(SEKey);
                                        }
                                        DecryptedResults += Encoding.UTF8.GetString(PlainTextByte) + ",";
                                    }
                                    SodiumSecureMemory.SecureClearBytes(SEKey);
                                    SodiumSecureMemory.SecureClearBytes(MACKey);
                                    loop += 1;
                                }
                                if (DecryptedResults.CompareTo("") != 0)
                                {
                                    File.WriteAllText(SystemResponseAppRootFolder + "DecryptedRetrievedData.txt", DecryptedResults);
                                }
                            }
                            File.WriteAllText(SystemResponseAppRootFolder + "OriginalReceivedJSONString.txt", Result);
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", MyDBRecordsModel.Status);
                        }
                        else
                        {
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", "There's something wrong on the server side..");
                        }
                    }
                }
            }
        }
        else if (AppUIChooser == 6) 
        {
            if (CredentialsSetter.DoesCredentialsExist() == true)
            {
                CredentialsSetter.SetCredentials();
                if (SixthmyTBArray[0].Text != null && SixthmyTBArray[0].Text.CompareTo("") != 0)
                {
                    String SQLQuery = "";
                    String[] SQLParameterNames = new String[] { };
                    String[] SQLParameterValues = new String[] { };
                    SQLQuery = SixthmyTBArray[0].Text;
                    if (SixthmyTBArray[1].Text != null && SixthmyTBArray[1].Text.CompareTo("") != 0
                        && SixthmyTBArray[2].Text != null && SixthmyTBArray[2].Text.CompareTo("") != 0) 
                    {
                        SQLParameterNames = SixthmyTBArray[1].Text.Split(",");
                        SQLParameterValues = SixthmyTBArray[2].Text.Split(",");
                    }
                    String[] Base64SQLParameterNames = new String[SQLParameterNames.Length];
                    String[] Base64SQLParameterValues = new String[SQLParameterValues.Length];
                    int ploop = 0;
                    while (ploop < SQLParameterNames.Length)
                    {
                        Base64SQLParameterNames[ploop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterNames[ploop]));
                        Base64SQLParameterValues[ploop] = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLParameterValues[ploop]));
                        ploop += 1;
                    }
                    SpecialSelectDBModel MySelectDBModel = new SpecialSelectDBModel();
                    MySelectDBModel.MyDBCredentialModel = new SealedDBCredentialModel();
                    if (SQLParameterNames.Length == 0) 
                    {
                        MySelectDBModel.Base64ParameterName = SQLParameterNames;
                        MySelectDBModel.Base64ParameterValue = SQLParameterValues;
                    }
                    else 
                    {
                        MySelectDBModel.Base64ParameterName = Base64SQLParameterNames;
                        MySelectDBModel.Base64ParameterValue = Base64SQLParameterValues;
                    }
                    MySelectDBModel.Base64QueryString = Convert.ToBase64String(Encoding.UTF8.GetBytes(SQLQuery));
                    MySelectDBModel.UniquePaymentID = CredentialsSetter.PaymentID;
                    MySelectDBModel.MyDBCredentialModel.SealedSessionID = CredentialsSetter.SealedETLSID;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserName = CredentialsSetter.SealedDBUserName;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserNameHMAC = CredentialsSetter.SealedDBUserNameHMAC;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserPassword = CredentialsSetter.SealedDBUserPassword;
                    MySelectDBModel.MyDBCredentialModel.SealedDBUserPasswordHMAC = CredentialsSetter.SealedDBUserPasswordHMAC;
                    MySelectDBModel.MyDBCredentialModel.SealedDBName = CredentialsSetter.SealedDBName;
                    MySelectDBModel.MyDBCredentialModel.SealedDBNameHMAC = CredentialsSetter.SealedDBNameHMAC;
                    String JSONBodyString = "";
                    StringContent PostRequestData = new StringContent("");
                    JSONBodyString = JsonConvert.SerializeObject(MySelectDBModel);
                    File.WriteAllText(SystemResponseAppRootFolder + "SampleJSONStringForDeveloper.txt", JSONBodyString);
                    PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.PostAsync("SpecialDeleteDBRecord", PostRequestData);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", Result.Substring(1,Result.Length-2));
                        }
                        else
                        {
                            File.WriteAllText(SystemResponseAppRootFolder + "SampleCRUDServerResult.txt", "There's something wrong on the server side..");
                        }
                    }
                }
            }
        }
    }
}
