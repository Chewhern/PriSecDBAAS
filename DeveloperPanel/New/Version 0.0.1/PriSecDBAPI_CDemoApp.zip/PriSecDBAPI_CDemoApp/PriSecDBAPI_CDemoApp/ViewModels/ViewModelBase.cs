﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PriSecDBAPI_CDemoApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
