﻿namespace PriSecDBAPI_CDemoApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}
