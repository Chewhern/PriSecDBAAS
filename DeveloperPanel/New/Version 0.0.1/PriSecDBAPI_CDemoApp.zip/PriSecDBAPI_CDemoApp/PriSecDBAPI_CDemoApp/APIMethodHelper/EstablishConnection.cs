﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using PriSecDBAPI_CDemoApp.Helper;
using System.Runtime.InteropServices;

namespace PriSecDBAPI_CDemoApp.APIMethodHelper
{
    public static class EstablishConnection
    {

        public static void SetSystemServerIPAddress() 
        {
            String ServerIP = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                ServerIP = File.ReadAllText(AppContext.BaseDirectory + "\\ServerIP\\IP.txt");
            }
            else 
            {
                ServerIP = File.ReadAllText(AppContext.BaseDirectory + "/ServerIP/IP.txt");
            }
            APIIPAddressHelper.IPAddress = ServerIP;
            APIIPAddressHelper.HasSet = true;        
        }

    }
}
