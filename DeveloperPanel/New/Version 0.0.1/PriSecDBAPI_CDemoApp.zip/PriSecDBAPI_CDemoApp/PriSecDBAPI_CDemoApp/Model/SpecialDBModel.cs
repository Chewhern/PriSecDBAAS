﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PriSecDBAPI_CDemoApp.Model
{
    public class SpecialDBModel
    {
        public SealedDBCredentialModel MyDBCredentialModel { get; set; }

        public String UniquePaymentID { get; set; }

        public String Base64QueryString { get; set; }

        public String[] Base64ParameterName { get; set; }

        public String[] Base64ParameterValue { get; set; }

        public String[] IDValue { get; set; }

        public String[] NewIDValue { get; set; }

        //1=XChaCha20
        //2=XSalsa20
        //3=SM4-HMAC-CTR
        //4=SM4-CTR
        public int SECipherAlgorithm { get; set; }

        //1=HMAC-SHA512
        //2=Keyed-Blake2B
        //3=Poly1305
        //4=KMAC (SHAKE Keyed MAC)
        //5=Keyed-Keccak
        //6=Keyed-SHAKE
        //7=HMAC-SM3
        public int MACAlgorithm { get; set; }
    }
}
