﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PriSecDBAPI_AdminApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
