﻿namespace PriSecDBAPI_AdminApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}
