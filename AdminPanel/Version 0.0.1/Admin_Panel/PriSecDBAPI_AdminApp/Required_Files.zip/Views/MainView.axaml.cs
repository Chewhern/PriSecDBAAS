﻿using Avalonia.Controls;
using System;
using System.IO;
using System.Runtime.InteropServices;
using PriSecDBAPI_AdminApp.Helper;
using PriSecDBAPI_AdminApp.APIMethodHelper;
using Avalonia.Media;
using ASodium;
using System.Net.Http.Headers;
using System.Net.Http;

namespace PriSecDBAPI_AdminApp.Views;

public partial class MainView : UserControl
{
    private static int AppUIChooser;
    private static TextBlock[] FirstmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] SecondmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] ThirdmyTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstmyTBArray = new TextBox[] { };
    private static TextBox[] SecondmyTBArray = new TextBox[] { };
    private static TextBox[] ThirdmyTBArray = new TextBox[] { };
    private static Button[] FirstmyButtonArray = new Button[] { };
    private static Button[] SecondmyButtonArray = new Button[] { };
    private static Button[] ThirdmyButtonArray = new Button[] { };
    private static String AdminED25519KPAppRootFolder = "";
    private static String AdminServerIPAppRootFolder = "";
    private static Boolean HasUIRendered = false;

    public MainView()
    {
        InitializeComponent();
        AppInitialization();

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
        {
            AdminED25519KPAppRootFolder = AppContext.BaseDirectory + "\\Admin_ED25519\\";
            AdminServerIPAppRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
        }
        else
        {
            AdminED25519KPAppRootFolder = AppContext.BaseDirectory + "/Admin_ED25519/";
            AdminServerIPAppRootFolder = AppContext.BaseDirectory + "/ServerIP/";
        }
        if (Directory.Exists(AdminED25519KPAppRootFolder) == false) 
        {
            Directory.CreateDirectory(AdminED25519KPAppRootFolder);
        }
        if (Directory.Exists(AdminServerIPAppRootFolder) == false) 
        {
            Directory.CreateDirectory(AdminServerIPAppRootFolder);
        }
        StartUpFunction();
    }

    private void StartUpFunction() 
    {
        if (Directory.Exists(AdminServerIPAppRootFolder) == true)
        {
            if (File.Exists(AdminServerIPAppRootFolder + "IP.txt") == true)
            {
                EstablishConnection.SetSystemServerIPAddress();
                ServerIPTB.Text = APIIPAddressHelper.IPAddress;
            }
        }
    }

    private void AppInitialization()
    {
        AppUIChooser = 0;
        ToggleBTN1.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN2.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN3.IsCheckedChanged += AppToggleBTNSFunction;
    }

    private void AppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (ToggleBTN1.IsChecked == true)
        {
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            AppUIChooser = 1;
        }
        else if (ToggleBTN2.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            AppUIChooser = 2;
        }
        else if (ToggleBTN3.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            AppUIChooser = 3;
        }
        else
        {
            ResetAppUI();
        }
        AppDrawUI();
    }

    private void AppDrawUI()
    {
        if (AppUIChooser == 1)
        {
            if (HasUIRendered == false)
            {
                FirstmyTextBlockArray = new TextBlock[2];
                FirstmyTextBlockArray[0] = new TextBlock();
                FirstmyTextBlockArray[1] = new TextBlock();
                FirstmyTextBlockArray[0].Text = "The Server IP Address of PriSecDBAPI Provider";
                FirstmyTextBlockArray[1].Text = "Server IP Address Status (Read Only)";
                FirstmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstmyTBArray = new TextBox[2];
                FirstmyTBArray[0] = new TextBox();
                FirstmyTBArray[1] = new TextBox();
                FirstmyTBArray[1].IsReadOnly = true;
                FirstmyTBArray[0].AcceptsReturn = true;
                FirstmyTBArray[1].AcceptsReturn = true;
                FirstmyTBArray[0].Height = 100;
                FirstmyTBArray[1].Height = 100;
                FirstmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FirstmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FirstmyButtonArray = new Button[1];
                FirstmyButtonArray[0] = new Button();
                FirstmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FirstmyButtonArray[0].Content = "Set Provider Server IP";
                FirstmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(FirstmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FirstmyTBArray[0]);
                MiddleStackPanel.Children.Add(FirstmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FirstmyTBArray[1]);
                MiddleStackPanel.Children.Add(FirstmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 2)
        {
            if (HasUIRendered == false)
            {
                SecondmyTextBlockArray = new TextBlock[2];
                SecondmyTextBlockArray[0] = new TextBlock();
                SecondmyTextBlockArray[1] = new TextBlock();
                SecondmyTextBlockArray[0].Text = "Admin ED25519 Key Pair Public Key";
                SecondmyTextBlockArray[1].Text = "ED25519 Key Pair Generation Status";
                SecondmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTBArray = new TextBox[2];
                SecondmyTBArray[0] = new TextBox();
                SecondmyTBArray[1] = new TextBox();
                SecondmyTBArray[0].IsReadOnly = true;
                SecondmyTBArray[1].IsReadOnly = true;
                SecondmyTBArray[0].AcceptsReturn = true;
                SecondmyTBArray[1].AcceptsReturn = true;
                SecondmyTBArray[0].Height = 100;
                SecondmyTBArray[1].Height = 100;
                SecondmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                SecondmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                SecondmyButtonArray = new Button[1];
                SecondmyButtonArray[0] = new Button();
                SecondmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                SecondmyButtonArray[0].Content = "Generate/Change ED25519 Key Pair";
                SecondmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[1]);
                MiddleStackPanel.Children.Add(SecondmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 3)
        {
            if (HasUIRendered == false)
            {
                ThirdmyTextBlockArray = new TextBlock[3];
                ThirdmyTextBlockArray[0] = new TextBlock();
                ThirdmyTextBlockArray[1] = new TextBlock();
                ThirdmyTextBlockArray[2] = new TextBlock();
                ThirdmyTextBlockArray[0].Text = "What's the payment ID?";
                ThirdmyTextBlockArray[1].Text = "Requested Challenge From Server";
                ThirdmyTextBlockArray[2].Text = "Signed Challenge (need to give to client)";
                ThirdmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTBArray = new TextBox[3];
                ThirdmyTBArray[0] = new TextBox();
                ThirdmyTBArray[1] = new TextBox();
                ThirdmyTBArray[2] = new TextBox();
                ThirdmyTBArray[1].IsReadOnly = true;
                ThirdmyTBArray[2].IsReadOnly = true;
                ThirdmyTBArray[0].AcceptsReturn = true;
                ThirdmyTBArray[1].AcceptsReturn = true;
                ThirdmyTBArray[2].AcceptsReturn = true;
                ThirdmyTBArray[0].Height = 100;
                ThirdmyTBArray[1].Height = 100;
                ThirdmyTBArray[2].Height = 100;
                ThirdmyTBArray[0].Width = 300;
                ThirdmyTBArray[1].Width = 300;
                ThirdmyTBArray[2].Width = 300;
                ThirdmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdmyButtonArray = new Button[1];
                ThirdmyButtonArray[0] = new Button();
                ThirdmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                ThirdmyButtonArray[0].Content = "Request/Sign Challenge";
                ThirdmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[0]);
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[1]);
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[2]);
                MiddleStackPanel.Children.Add(ThirdmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else
        {
            ResetAppUI();
        }
    }

    private void ResetAppUI()
    {
        ToggleBTN1.IsChecked = false;
        ToggleBTN2.IsChecked = false;
        ToggleBTN3.IsChecked = false;
        AppUIChooser = 0;
        MiddleStackPanel.Children.Clear();
        HasUIRendered = false;
    }

    private void AppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (AppUIChooser == 1)
        {
            if (FirstmyTBArray[0].Text != null && FirstmyTBArray[0].Text.CompareTo("") != 0) 
            {
                File.WriteAllText(AdminServerIPAppRootFolder + "IP.txt", FirstmyTBArray[0].Text);
                FirstmyTBArray[1].Text = "Created Server IP file";
                ServerIPTB.Text = FirstmyTBArray[0].Text;
                APIIPAddressHelper.IPAddress = FirstmyTBArray[0].Text;
                APIIPAddressHelper.HasSet = true;
            }
        }
        else if (AppUIChooser == 2)
        {
            RevampedKeyPair ED25519RevampedKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            SecondmyTBArray[0].Text = Convert.ToBase64String(ED25519RevampedKeyPair.PublicKey);
            File.WriteAllBytes(AdminED25519KPAppRootFolder + "PrivateKey.txt", ED25519RevampedKeyPair.PrivateKey);
            File.WriteAllBytes(AdminED25519KPAppRootFolder + "PublicKey.txt", ED25519RevampedKeyPair.PublicKey);
            SecondmyTBArray[1].Text = "Created/Resetted Public Key";
            ED25519RevampedKeyPair.Clear();
        }
        else if (AppUIChooser == 3)
        {
            if (ThirdmyTBArray[0].Text != null && ThirdmyTBArray[0].Text.CompareTo("") != 0) 
            {
                if (ThirdmyTBArray[1].Text != null && ThirdmyTBArray[1].Text.CompareTo("") != 0)
                {
                    Byte[] Challenge = Convert.FromBase64String(ThirdmyTBArray[1].Text);
                    Byte[] PrivateKey = File.ReadAllBytes(AdminED25519KPAppRootFolder + "PrivateKey.txt");
                    Byte[] SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, PrivateKey, true);
                    ThirdmyTBArray[2].Text = Convert.ToBase64String(SignedChallenge);
                }
                else 
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.GetAsync("CreateReceivePayment/InitiateCheckPayment?Payment_ID=" + ThirdmyTBArray[0].Text);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            ThirdmyTBArray[1].Text = Result.Substring(1, Result.Length - 2);
                        }
                        else
                        {
                            ThirdmyTBArray[1].Text = "There's something wrong on the server side..";
                        }
                    }
                }
            }
        }
    }
}
