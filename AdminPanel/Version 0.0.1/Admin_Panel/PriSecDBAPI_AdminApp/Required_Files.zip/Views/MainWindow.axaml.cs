﻿using Avalonia.Controls;

namespace PriSecDBAPI_AdminApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
