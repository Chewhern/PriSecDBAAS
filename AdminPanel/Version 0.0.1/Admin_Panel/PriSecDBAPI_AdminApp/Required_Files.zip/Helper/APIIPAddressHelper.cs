﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriSecDBAPI_AdminApp.Helper
{
    public static class APIIPAddressHelper
    {
        //Nullable IPAddress
        public static String? IPAddress { get; set; }

        public static Boolean HasSet { get; set; }
    }
}
