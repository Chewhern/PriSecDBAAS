﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using PriSecDBAPI_CAdminApp.Model;
using Newtonsoft.Json;
using ASodium;
using System.IO;
using System.Runtime.InteropServices;

namespace PriSecDBAPI_CAdminApp.Helper
{
    public static class CreateETLS
    {
        public static String Status = "";
        private static Byte[] X25519SEPKByte = new Byte[] { };
        private static Byte[] X25519MACPKByte = new Byte[] { };
        private static Byte[] Challenge = new Byte[] { };
        private static String ETLSID = "";

        public static void CreateOrChangeETLS() 
        {
            String AdminETLSAppRootFolder = "";
            Status = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "\\ETLS\\";
            }
            else
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "/ETLS/";
            }
            if (File.Exists(AdminETLSAppRootFolder + "ETLSID.txt") == false)
            {
                InitiateETLS();
                CreateSession();
                CheckSharedSecret();
            }
            else 
            {
                GetChallenge();
                SignChallenge();
                InitiateETLS();
                CreateSession();
                CheckSharedSecret();
            }
        }

        private static void InitiateETLS() 
        {
            CryptographicSecureIDGenerator myIDGenerator = new CryptographicSecureIDGenerator();
            ETLSID = myIDGenerator.GenerateUniqueString();
            if (ETLSID.Length > 64) 
            {
                ETLSID=ETLSID.Substring(0,64);
            }
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ECDH_ECDSA_TempSession/byID?ClientPathID=" + ETLSID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    ECDH_ECDSA_Models MyECDH_ECDSA_Models = new ECDH_ECDSA_Models();
                    MyECDH_ECDSA_Models = JsonConvert.DeserializeObject<ECDH_ECDSA_Models>(Result);
                    if (MyECDH_ECDSA_Models.ID_Checker_Message.Contains("Error") == false)
                    {
                        X25519SEPKByte = SodiumPublicKeyAuth.Verify(Convert.FromBase64String(MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String), Convert.FromBase64String(MyECDH_ECDSA_Models.ED25519_PK_Base64String));
                        X25519MACPKByte = SodiumPublicKeyAuth.Verify(Convert.FromBase64String(MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String), Convert.FromBase64String(MyECDH_ECDSA_Models.ED25519_PK_Base64String));
                    }
                    Status = MyECDH_ECDSA_Models.ID_Checker_Message;
                }
                else
                {
                    Status="There's something wrong on the server side..";
                }
            }
        }

        private static void CreateSession() 
        {
            String AdminETLSAppRootFolder = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "\\ETLS\\";
            }
            else
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "/ETLS/";
            }
            if (File.Exists(AdminETLSAppRootFolder + "ETLSID.txt") == false)
            {
                File.WriteAllText(AdminETLSAppRootFolder + "ETLSID.txt", ETLSID);
                RevampedKeyPair SessionSEKP = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                RevampedKeyPair SessionMACKP = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                RevampedKeyPair SessionED25519KP = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                Byte[] SignedSEX25519PK = SodiumPublicKeyAuth.Sign(SessionSEKP.PublicKey, SessionED25519KP.PrivateKey);
                Byte[] SignedMACX25519PK = SodiumPublicKeyAuth.Sign(SessionMACKP.PublicKey, SessionED25519KP.PrivateKey);
                Byte[] SESharedSecret = SodiumScalarMult.Mult(SessionSEKP.PrivateKey, X25519SEPKByte);
                Byte[] MACSharedSecret = SodiumScalarMult.Mult(SessionMACKP.PrivateKey, X25519MACPKByte);
                File.WriteAllBytes(AdminETLSAppRootFolder + "SESharedSecret.txt", SESharedSecret);
                File.WriteAllBytes(AdminETLSAppRootFolder + "MACSharedSecret.txt", MACSharedSecret);
                File.WriteAllBytes(AdminETLSAppRootFolder + "ED25519PK.txt", SessionED25519KP.PublicKey);
                File.WriteAllBytes(AdminETLSAppRootFolder + "ED25519SK.txt", SessionED25519KP.PrivateKey);
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.GetAsync("ECDH_ECDSA_TempSession/ByHandshake?ClientPathID=" + ETLSID+ "&SX25519SEPK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SignedSEX25519PK)) + "&SX25519MACPK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SignedMACX25519PK)) + "&ED25519PK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SessionED25519KP.PublicKey)));
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;
                        Status += Environment.NewLine + Result.Substring(1, Result.Length - 2);
                    }
                    else
                    {
                        Status += Environment.NewLine + "There's something wrong on the server side..";
                    }
                }
                SessionSEKP.Clear();
                SessionMACKP.Clear();
                SessionED25519KP.Clear();
                SodiumSecureMemory.SecureClearBytes(SESharedSecret);
                SodiumSecureMemory.SecureClearBytes(MACSharedSecret);
            }
        }

        private static void CheckSharedSecret()
        {
            String AdminETLSAppRootFolder = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "\\ETLS\\";
            }
            else
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "/ETLS/";
            }
            if (File.Exists(AdminETLSAppRootFolder + "ETLSID.txt") == true)
            {
                Byte[] SESharedSecret = File.ReadAllBytes(AdminETLSAppRootFolder + "SESharedSecret.txt");
                Byte[] MACSharedSecret = File.ReadAllBytes(AdminETLSAppRootFolder + "MACSharedSecret.txt");
                Byte[] RandomData = SodiumRNG.GetRandomBytes(32);
                Byte[] Nonce = SodiumSecretBox.GenerateNonce();
                Byte[] SECipheredData = SodiumSecretBox.Create(RandomData, Nonce, SESharedSecret,true);
                Byte[] MACCipheredData = SodiumSecretBox.Create(RandomData, Nonce, MACSharedSecret, true);
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.GetAsync("ECDH_ECDSA_TempSession/BySharedSecret?ClientPathID=" + ETLSID + "&SECipheredData=" + System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SECipheredData)) + "&MACCipheredData=" + System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(MACCipheredData)) + "&Nonce=" + System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(Nonce)));
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;
                        Status += Environment.NewLine + Result.Substring(1, Result.Length - 2);
                    }
                    else
                    {
                        Status += Environment.NewLine + "There's something wrong on the server side..";
                    }
                }
            }
        }

        private static void GetChallenge() 
        {
            String AdminETLSAppRootFolder = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "\\ETLS\\";
            }
            else
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "/ETLS/";
            }
            ETLSID = File.ReadAllText(AdminETLSAppRootFolder + "ETLSID.txt");
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ECDH_ECDSA_TempSession/InitiateDeletionOfETLS?ClientPathID=" + ETLSID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    if (Result.Contains("Error") == false)
                    {
                        Challenge = Convert.FromBase64String(Result.Substring(1, Result.Length - 2));
                        Status += Environment.NewLine + "Successfully requested challenge";
                    }
                    else 
                    {
                        Status += Environment.NewLine + Result.Substring(1, Result.Length - 2);
                    }
                }
                else
                {
                    Status += Environment.NewLine + "There's something wrong on the server side..";
                }
            }
        }

        private static void SignChallenge() 
        {
            String AdminETLSAppRootFolder = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "\\ETLS\\";
            }
            else
            {
                AdminETLSAppRootFolder = AppContext.BaseDirectory + "/ETLS/";
            }
            ETLSID = File.ReadAllText(AdminETLSAppRootFolder + "ETLSID.txt");
            Byte[] ED25519SK = File.ReadAllBytes(AdminETLSAppRootFolder + "ED25519SK.txt");
            Byte[] SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, ED25519SK, true);
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ECDH_ECDSA_TempSession/DeleteByClientCryptographicID?ClientPathID=" + ETLSID + "&ValidationData="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SignedChallenge)));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    if (Result.Contains("Error") == false)
                    {
                        File.Delete(AdminETLSAppRootFolder + "ETLSID.txt");
                        File.Delete(AdminETLSAppRootFolder + "SESharedSecret.txt");
                        File.Delete(AdminETLSAppRootFolder + "MACSharedSecret.txt");
                        File.Delete(AdminETLSAppRootFolder + "ED25519SK.txt");
                        File.Delete(AdminETLSAppRootFolder + "ED25519PK.txt");
                        Status += Environment.NewLine + "Successfully deleted ETLS";
                    }
                    else
                    {
                        Status += Environment.NewLine + Result.Substring(1, Result.Length - 2);
                    }
                }
                else
                {
                    Status += Environment.NewLine + "There's something wrong on the server side..";
                }
            }
        }
    }
}
