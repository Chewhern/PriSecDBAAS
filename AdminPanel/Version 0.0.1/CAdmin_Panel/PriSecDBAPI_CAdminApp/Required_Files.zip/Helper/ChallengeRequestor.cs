﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using PriSecDBAPI_CAdminApp.Model;
using System.IO;
using Newtonsoft.Json;
using ASodium;

namespace PriSecDBAPI_CAdminApp.Helper
{
    public static class ChallengeRequestor
    {
        public static Byte[] Challenge = new Byte[] { };
        public static String Status = "";

        public static void RequestChallenge() 
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("Login");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    LoginModels MyLoginModels = new LoginModels();
                    MyLoginModels = JsonConvert.DeserializeObject<LoginModels>(Result);
                    if (MyLoginModels.RequestStatus.Contains("Error") == false)
                    {
                        Challenge = SodiumPublicKeyAuth.Verify(Convert.FromBase64String(MyLoginModels.SignedRandomChallengeBase64String), Convert.FromBase64String(MyLoginModels.ServerECDSAPKBase64String));
                    }
                    Status = MyLoginModels.RequestStatus;
                }
                else
                {
                    Status = "There's something wrong on the server side..";
                }
            }
        }
    }
}
