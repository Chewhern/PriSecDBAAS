﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ASodium;
using Newtonsoft.Json;
using PriSecDBAPI_CAdminApp.Model;
using System.Runtime.InteropServices;
using System.IO;

namespace PriSecDBAPI_CAdminApp.Helper
{
    public static class CreateOrDeleteSealedETLS
    {
        private static String ETLSID = "";
        public static String Status = "";

        public static void InitiateETLSAndCreateSealedDBCredentials()
        {
            String AdminSealedDBCredentialsAppRootFolder = "";
            String AdminDBCredentialsAppRootFolder = "";
            Status = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\SealedDBCredentials\\";
                AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\DBCredentials\\";
            }
            else
            {
                AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/SealedDBCredentials/";
                AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/DBCredentials/";
            }
            CryptographicSecureIDGenerator myIDGenerator = new CryptographicSecureIDGenerator();
            ETLSID = myIDGenerator.GenerateUniqueString();
            if (ETLSID.Length > 64)
            {
                ETLSID = ETLSID.Substring(0, 64);
            }
            RevampedKeyPair EphemeralX25519SEKP = SodiumPublicKeyBox.GenerateRevampedKeyPair();
            RevampedKeyPair EphemeralX25519MACKP = SodiumPublicKeyBox.GenerateRevampedKeyPair();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("EstablishSealedBoxDBCredentials?ClientPathID=" + ETLSID + "&X25519SEPK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(EphemeralX25519SEKP.PublicKey))+"&X25519MACPK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(EphemeralX25519MACKP.PublicKey)));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    ECDH_ECDSA_Models MyECDH_ECDSA_Models = new ECDH_ECDSA_Models();
                    MyECDH_ECDSA_Models = JsonConvert.DeserializeObject<ECDH_ECDSA_Models>(Result);
                    if (MyECDH_ECDSA_Models.ID_Checker_Message.Contains("Error") == false)
                    {
                        Byte[] X25519SEPKByte = SodiumPublicKeyAuth.Verify(Convert.FromBase64String(MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String), Convert.FromBase64String(MyECDH_ECDSA_Models.ED25519_PK_Base64String));
                        Byte[] X25519MACPKByte = SodiumPublicKeyAuth.Verify(Convert.FromBase64String(MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String), Convert.FromBase64String(MyECDH_ECDSA_Models.ED25519_PK_Base64String));
                        Byte[] SEKey = SodiumScalarMult.Mult(EphemeralX25519SEKP.PrivateKey, X25519SEPKByte, true);
                        Byte[] MACKey = SodiumScalarMult.Mult(EphemeralX25519MACKP.PrivateKey, X25519MACPKByte, true);
                        Byte[] DBUserNameByte = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "DBUserName.txt");
                        Byte[] DBUserPasswordByte = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "DBUserPassword.txt");
                        Byte[] DBNameByte = File.ReadAllBytes(AdminDBCredentialsAppRootFolder + "DBName.txt");
                        Byte[] Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), EphemeralX25519MACKP.PublicKey.Concat(EphemeralX25519SEKP.PublicKey).ToArray());
                        Byte[] SealedDBUserNameByte = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DBUserNameByte, Nonce, SEKey);
                        Byte[] SealedDBUserPasswordByte = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DBUserPasswordByte, Nonce, SEKey);
                        Byte[] SealedDBNameByte = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DBNameByte, Nonce, SEKey, true);
                        Byte[] SealedDBUserNameHMACByte = SodiumHMACSHA512.ComputeMAC(SealedDBUserNameByte, MACKey);
                        Byte[] SealedDBUserPasswordHMACByte = SodiumHMACSHA512.ComputeMAC(SealedDBUserPasswordByte, MACKey);
                        Byte[] SealedDBNameHMACByte = SodiumHMACSHA512.ComputeMAC(SealedDBNameByte, MACKey, true);
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt", ETLSID);
                        SodiumSecureMemory.SecureClearBytes(DBUserNameByte);
                        SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                        SodiumSecureMemory.SecureClearBytes(DBNameByte);
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt", Convert.ToBase64String(SealedDBUserNameByte));
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPassword.txt", Convert.ToBase64String(SealedDBUserPasswordByte));
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder+ "SealedDBName.txt",Convert.ToBase64String(SealedDBNameByte));
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserNameHMAC.txt", Convert.ToBase64String(SealedDBUserNameHMACByte));
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPasswordHMAC.txt", Convert.ToBase64String(SealedDBUserPasswordHMACByte));
                        File.WriteAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBNameHMAC.txt", Convert.ToBase64String(SealedDBNameHMACByte));
                        Status = "Initiated ETLS and created sealed credentials";
                    }
                    if (Status.CompareTo("") != 0) 
                    {
                        Status += Environment.NewLine + MyECDH_ECDSA_Models.ID_Checker_Message;
                    }
                    else 
                    {
                        Status = MyECDH_ECDSA_Models.ID_Checker_Message;
                    }
                }
                else
                {
                    Status = "There's something wrong on the server side..";
                }
            }
            EphemeralX25519MACKP.Clear();
            EphemeralX25519SEKP.Clear();
        }

        public static void DeleteETLSAndSealedCredentials() 
        {
            String AdminED25519KPAppRootFolder = "";
            String AdminSealedDBCredentialsAppRootFolder = "";
            String AdminDBCredentialsAppRootFolder = "";
            Status = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\SealedDBCredentials\\";
                AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\DBCredentials\\";
                AdminED25519KPAppRootFolder = AppContext.BaseDirectory + "\\Admin_ED25519\\";
            }
            else
            {
                AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/SealedDBCredentials/";
                AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/DBCredentials/";
                AdminED25519KPAppRootFolder = AppContext.BaseDirectory + "/Admin_ED25519/";
            }
            ETLSID = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt");
            String PaymentID = File.ReadAllText(AdminDBCredentialsAppRootFolder + "PaymentID.txt");
            ChallengeRequestor.RequestChallenge();
            Byte[] ED25519SK = File.ReadAllBytes(AdminED25519KPAppRootFolder + "ED25519SK.txt");
            Byte[] SignedChallenge = SodiumPublicKeyAuth.Sign(ChallengeRequestor.Challenge, ED25519SK, true);
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("EstablishSealedBoxDBCredentials/DeleteSealedSession?ClientPathID=" + ETLSID + "&UniquePaymentID=" + PaymentID + "&SignedRandomChallenge=" + System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SignedChallenge)));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    String NewResult = Result.Substring(1, Result.Length - 2);
                    if (NewResult.Contains("Error") == false) 
                    {
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt");
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt");
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPassword.txt");
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedDBName.txt");
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserNameHMAC.txt");
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserPasswordHMAC.txt");
                        File.Delete(AdminSealedDBCredentialsAppRootFolder + "SealedDBNameHMAC.txt");
                        Status = "Removed Sealed ETLS and Credentials";
                    }
                    if (Status.CompareTo("") != 0) 
                    {
                        Status += Environment.NewLine + NewResult;
                    }
                    else 
                    {
                        Status = NewResult;
                    }
                }
                else
                {
                    Status = "There's something wrong on the server side..";
                }
            }
        }
    }
}
