﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PriSecDBAPI_CAdminApp.Model
{
    public class ECDH_ECDSA_Models
    {
        public String ED25519_PK_Base64String { get; set; }
        public String X25519_SE_SPK_Base64String { get; set; }

        public String X25519_MAC_SPK_Base64String { get; set; }
        public String ID_Checker_Message { get; set; }
    }
}
