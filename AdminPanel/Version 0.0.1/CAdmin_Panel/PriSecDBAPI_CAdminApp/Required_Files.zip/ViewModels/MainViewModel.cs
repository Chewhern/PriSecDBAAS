﻿namespace PriSecDBAPI_CAdminApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    
}
