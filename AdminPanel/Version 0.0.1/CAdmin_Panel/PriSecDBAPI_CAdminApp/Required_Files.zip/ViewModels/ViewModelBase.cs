﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PriSecDBAPI_CAdminApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
