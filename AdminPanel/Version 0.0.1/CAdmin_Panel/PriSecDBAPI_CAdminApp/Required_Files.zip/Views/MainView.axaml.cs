﻿using Avalonia.Controls;
using System;
using System.IO;
using System.Runtime.InteropServices;
using PriSecDBAPI_CAdminApp.Helper;
using PriSecDBAPI_CAdminApp.APIMethodHelper;
using ASodium;
using Avalonia.Media;
using System.Net.Http.Headers;
using System.Net.Http;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Cmp;
using PriSecDBAPI_CAdminApp.Model;
using System.Text;

namespace PriSecDBAPI_CAdminApp.Views;

public partial class MainView : UserControl
{
    private static int AppUIChooser;
    private static TextBlock[] FirstmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] SecondmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] ThirdmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] FourthmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] FifthmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] SixthmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] SeventhmyTextBlockArray = new TextBlock[] { };
    private static TextBlock[] EighthmyTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstmyTBArray = new TextBox[] { };
    private static TextBox[] SecondmyTBArray = new TextBox[] { };
    private static TextBox[] ThirdmyTBArray = new TextBox[] { };
    private static TextBox[] FourthmyTBArray = new TextBox[] { };
    private static TextBox[] FifthmyTBArray = new TextBox[] { };
    private static TextBox[] SixthmyTBArray = new TextBox[] { };
    private static TextBox[] SeventhmyTBArray = new TextBox[] { };
    private static TextBox[] EighthmyTBArray = new TextBox[] { };
    private static Button[] FirstmyButtonArray = new Button[] { };
    private static Button[] SecondmyButtonArray = new Button[] { };
    private static Button[] ThirdmyButtonArray = new Button[] { };
    private static Button[] FourthmyButtonArray = new Button[] { };
    private static Button[] FifthmyButtonArray = new Button[] { };
    private static Button[] SixthmyButtonArray = new Button[] { };
    private static Button[] SeventhmyButtonArray = new Button[] { };
    private static Button[] EighthmyButtonArray = new Button[] { };
    private static String AdminServerIPAppRootFolder = "";
    private static String AdminETLSAppRootFolder = "";
    private static String AdminDBCredentialsAppRootFolder = "";
    private static String AdminSealedDBCredentialsAppRootFolder = "";
    private static String AdminED25519KPAppRootFolder = "";
    private static Boolean HasUIRendered = false;
    public MainView()
    {
        InitializeComponent();
        AppInitialization();

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
        {
            AdminED25519KPAppRootFolder = AppContext.BaseDirectory + "\\Admin_ED25519\\";
            AdminServerIPAppRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
            AdminETLSAppRootFolder = AppContext.BaseDirectory + "\\ETLS\\";
            AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\DBCredentials\\";
            AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "\\SealedDBCredentials\\";
        }
        else
        {
            AdminED25519KPAppRootFolder = AppContext.BaseDirectory + "/Admin_ED25519/";
            AdminServerIPAppRootFolder = AppContext.BaseDirectory + "/ServerIP/";
            AdminETLSAppRootFolder = AppContext.BaseDirectory + "/ETLS/";
            AdminDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/DBCredentials/";
            AdminSealedDBCredentialsAppRootFolder = AppContext.BaseDirectory + "/SealedDBCredentials/";
        }
        if (Directory.Exists(AdminED25519KPAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminED25519KPAppRootFolder);
        }
        if (Directory.Exists(AdminServerIPAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminServerIPAppRootFolder);
        }
        if (Directory.Exists(AdminETLSAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminETLSAppRootFolder);
        }
        if (Directory.Exists(AdminDBCredentialsAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminDBCredentialsAppRootFolder);
        }
        if (Directory.Exists(AdminSealedDBCredentialsAppRootFolder) == false)
        {
            Directory.CreateDirectory(AdminSealedDBCredentialsAppRootFolder);
        }
        StartUpFunction();
    }

    private void StartUpFunction()
    {
        if (Directory.Exists(AdminServerIPAppRootFolder) == true)
        {
            if (File.Exists(AdminServerIPAppRootFolder + "IP.txt") == true)
            {
                EstablishConnection.SetSystemServerIPAddress();
                ServerIPTB.Text = APIIPAddressHelper.IPAddress;
            }
        }
    }

    private void AppInitialization()
    {
        AppUIChooser = 0;
        ToggleBTN1.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN2.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN3.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN4.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN5.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN6.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN7.IsCheckedChanged += AppToggleBTNSFunction;
        ToggleBTN8.IsCheckedChanged += AppToggleBTNSFunction;
    }

    private void AppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (ToggleBTN1.IsChecked == true)
        {
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 1;
        }
        else if (ToggleBTN2.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 2;
        }
        else if (ToggleBTN3.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 3;
        }
        else if (ToggleBTN4.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 4;
        }
        else if (ToggleBTN5.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 5;
        }
        else if (ToggleBTN6.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 6;
        }
        else if (ToggleBTN7.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN8.IsChecked = false;
            AppUIChooser = 7;
        }
        else if (ToggleBTN8.IsChecked == true)
        {
            ToggleBTN1.IsChecked = false;
            ToggleBTN2.IsChecked = false;
            ToggleBTN3.IsChecked = false;
            ToggleBTN4.IsChecked = false;
            ToggleBTN5.IsChecked = false;
            ToggleBTN6.IsChecked = false;
            ToggleBTN7.IsChecked = false;
            AppUIChooser = 8;
        }
        else
        {
            ResetAppUI();
        }
        AppDrawUI();
    }

    private void AppDrawUI()
    {
        if (AppUIChooser == 1)
        {
            if (HasUIRendered == false)
            {
                FirstmyTextBlockArray = new TextBlock[2];
                FirstmyTextBlockArray[0] = new TextBlock();
                FirstmyTextBlockArray[1] = new TextBlock();
                FirstmyTextBlockArray[0].Text = "The Server IP Address of PriSecDBAPI Provider";
                FirstmyTextBlockArray[1].Text = "Server IP Address Status (Read Only)";
                FirstmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstmyTBArray = new TextBox[2];
                FirstmyTBArray[0] = new TextBox();
                FirstmyTBArray[1] = new TextBox();
                FirstmyTBArray[1].IsReadOnly = true;
                FirstmyTBArray[0].AcceptsReturn = true;
                FirstmyTBArray[1].AcceptsReturn = true;
                FirstmyTBArray[0].Height = 100;
                FirstmyTBArray[1].Height = 100;
                FirstmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FirstmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FirstmyButtonArray = new Button[1];
                FirstmyButtonArray[0] = new Button();
                FirstmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FirstmyButtonArray[0].Content = "Set Provider Server IP";
                FirstmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(FirstmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FirstmyTBArray[0]);
                MiddleStackPanel.Children.Add(FirstmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FirstmyTBArray[1]);
                MiddleStackPanel.Children.Add(FirstmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 2)
        {
            if (HasUIRendered == false)
            {
                SecondmyTextBlockArray = new TextBlock[2];
                SecondmyTextBlockArray[0] = new TextBlock();
                SecondmyTextBlockArray[1] = new TextBlock();
                SecondmyTextBlockArray[0].Text = "New ETLS ID";
                SecondmyTextBlockArray[1].Text = "ETLS Status";
                SecondmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondmyTBArray = new TextBox[2];
                SecondmyTBArray[0] = new TextBox();
                SecondmyTBArray[1] = new TextBox();
                SecondmyTBArray[0].IsReadOnly = true;
                SecondmyTBArray[1].IsReadOnly = true;
                SecondmyTBArray[0].AcceptsReturn = true;
                SecondmyTBArray[1].AcceptsReturn = true;
                SecondmyTBArray[0].Height = 100;
                SecondmyTBArray[1].Height = 125;
                SecondmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                SecondmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                SecondmyButtonArray = new Button[1];
                SecondmyButtonArray[0] = new Button();
                SecondmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                SecondmyButtonArray[0].Content = "Establish/Change ETLS Session";
                SecondmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[0]);
                MiddleStackPanel.Children.Add(SecondmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(SecondmyTBArray[1]);
                MiddleStackPanel.Children.Add(SecondmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 3)
        {
            if (HasUIRendered == false)
            {
                ThirdmyTextBlockArray = new TextBlock[2];
                ThirdmyTextBlockArray[0] = new TextBlock();
                ThirdmyTextBlockArray[1] = new TextBlock();
                ThirdmyTextBlockArray[0].Text = "How many (N*5)GB of database do you want?"+Environment.NewLine
                    +"(Please input only whole number without decimal)";
                ThirdmyTextBlockArray[1].Text = "Payment ID (Give to Provider) / Status";
                ThirdmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdmyTBArray = new TextBox[2];
                ThirdmyTBArray[0] = new TextBox();
                ThirdmyTBArray[1] = new TextBox();
                ThirdmyTBArray[1].IsReadOnly = true;
                ThirdmyTBArray[0].AcceptsReturn = true;
                ThirdmyTBArray[1].AcceptsReturn = true;
                ThirdmyTBArray[0].Height = 50;
                ThirdmyTBArray[1].Height = 100;
                ThirdmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdmyButtonArray = new Button[1];
                ThirdmyButtonArray[0] = new Button();
                ThirdmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                ThirdmyButtonArray[0].Content = "Initiate Payment Request";
                ThirdmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[0]);
                MiddleStackPanel.Children.Add(ThirdmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(ThirdmyTBArray[1]);
                MiddleStackPanel.Children.Add(ThirdmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 4)
        {
            if (HasUIRendered == false)
            {
                FourthmyTextBlockArray = new TextBlock[3];
                FourthmyTextBlockArray[0] = new TextBlock();
                FourthmyTextBlockArray[1] = new TextBlock();
                FourthmyTextBlockArray[2] = new TextBlock();
                FourthmyTextBlockArray[0].Text = "What's the payment ID?";
                FourthmyTextBlockArray[1].Text = "What's the provider signed challenge?";
                FourthmyTextBlockArray[2].Text = "Payment Status";
                FourthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthmyTBArray = new TextBox[3];
                FourthmyTBArray[0] = new TextBox();
                FourthmyTBArray[1] = new TextBox();
                FourthmyTBArray[2] = new TextBox();
                FourthmyTBArray[2].IsReadOnly = true;
                FourthmyTBArray[0].AcceptsReturn = true;
                FourthmyTBArray[1].AcceptsReturn = true;
                FourthmyTBArray[2].AcceptsReturn = true;
                FourthmyTBArray[0].Height = 100;
                FourthmyTBArray[1].Height = 100;
                FourthmyTBArray[2].Height = 100;
                FourthmyTBArray[0].Width = 300;
                FourthmyTBArray[1].Width = 300;
                FourthmyTBArray[2].Width = 300;
                FourthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FourthmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FourthmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                FourthmyButtonArray = new Button[1];
                FourthmyButtonArray[0] = new Button();
                FourthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FourthmyButtonArray[0].Content = "Confirm Payment And Create Credentials";
                FourthmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[0]);
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[1]);
                MiddleStackPanel.Children.Add(FourthmyTextBlockArray[2]);
                MiddleStackPanel.Children.Add(FourthmyTBArray[2]);
                MiddleStackPanel.Children.Add(FourthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 5)
        {
            if (HasUIRendered == false)
            {
                FifthmyTextBlockArray = new TextBlock[2];
                FifthmyTextBlockArray[0] = new TextBlock();
                FifthmyTextBlockArray[1] = new TextBlock();
                FifthmyTextBlockArray[0].Text = "New Sealed ETLS ID";
                FifthmyTextBlockArray[1].Text = "Sealed ETLS Status";
                FifthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthmyTBArray = new TextBox[2];
                FifthmyTBArray[0] = new TextBox();
                FifthmyTBArray[1] = new TextBox();
                FifthmyTBArray[0].IsReadOnly = true;
                FifthmyTBArray[1].IsReadOnly = true;
                FifthmyTBArray[0].AcceptsReturn = true;
                FifthmyTBArray[1].AcceptsReturn = true;
                FifthmyTBArray[0].Height = 100;
                FifthmyTBArray[1].Height = 125;
                FifthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FifthmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FifthmyButtonArray = new Button[1];
                FifthmyButtonArray[0] = new Button();
                FifthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FifthmyButtonArray[0].Content = "Create Concealed DB Credentials";
                FifthmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(FifthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(FifthmyTBArray[0]);
                MiddleStackPanel.Children.Add(FifthmyTextBlockArray[1]);
                MiddleStackPanel.Children.Add(FifthmyTBArray[1]);
                MiddleStackPanel.Children.Add(FifthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 6)
        {
            if (HasUIRendered == false)
            {
                SixthmyTextBlockArray = new TextBlock[1];
                SixthmyTextBlockArray[0] = new TextBlock();
                SixthmyTextBlockArray[0].Text = "Status";
                SixthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthmyTBArray = new TextBox[1];
                SixthmyTBArray[0] = new TextBox();
                SixthmyTBArray[0].IsReadOnly = true;
                SixthmyTBArray[0].AcceptsReturn = true;
                SixthmyTBArray[0].Height = 100;
                SixthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                SixthmyButtonArray = new Button[1];
                SixthmyButtonArray[0] = new Button();
                SixthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                SixthmyButtonArray[0].Content = "Delete Sealed ETLS and Credentials";
                SixthmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(SixthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(SixthmyTBArray[0]);
                MiddleStackPanel.Children.Add(SixthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 7)
        {
            if (HasUIRendered == false)
            {
                SeventhmyTextBlockArray = new TextBlock[1];
                SeventhmyTextBlockArray[0] = new TextBlock();
                SeventhmyTextBlockArray[0].Text = "Lock DB Account Status";
                SeventhmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SeventhmyTBArray = new TextBox[1];
                SeventhmyTBArray[0] = new TextBox();
                SeventhmyTBArray[0].IsReadOnly = true;
                SeventhmyTBArray[0].AcceptsReturn = true;
                SeventhmyTBArray[0].Height = 100;
                SeventhmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                SeventhmyButtonArray = new Button[1];
                SeventhmyButtonArray[0] = new Button();
                SeventhmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                SeventhmyButtonArray[0].Content = "Lock DB User";
                SeventhmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(SeventhmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(SeventhmyTBArray[0]);
                MiddleStackPanel.Children.Add(SeventhmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else if (AppUIChooser == 8)
        {
            if (HasUIRendered == false)
            {
                EighthmyTextBlockArray = new TextBlock[1];
                EighthmyTextBlockArray[0] = new TextBlock();
                EighthmyTextBlockArray[0].Text = "Unlock DB Account Status";
                EighthmyTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                EighthmyTBArray = new TextBox[1];
                EighthmyTBArray[0] = new TextBox();
                EighthmyTBArray[0].IsReadOnly = true;
                EighthmyTBArray[0].AcceptsReturn = true;
                EighthmyTBArray[0].Height = 100;
                EighthmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                EighthmyButtonArray = new Button[1];
                EighthmyButtonArray[0] = new Button();
                EighthmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                EighthmyButtonArray[0].Content = "Unlock DB User";
                EighthmyButtonArray[0].Click += AppBTN_Click;
                MiddleStackPanel.Children.Add(EighthmyTextBlockArray[0]);
                MiddleStackPanel.Children.Add(EighthmyTBArray[0]);
                MiddleStackPanel.Children.Add(EighthmyButtonArray[0]);
                HasUIRendered = true;
            }
        }
        else
        {
            ResetAppUI();
        }
    }

    private void ResetAppUI()
    {
        ToggleBTN1.IsChecked = false;
        ToggleBTN2.IsChecked = false;
        ToggleBTN3.IsChecked = false;
        ToggleBTN4.IsChecked = false;
        ToggleBTN5.IsChecked = false;
        ToggleBTN6.IsChecked = false;
        ToggleBTN7.IsChecked = false;
        ToggleBTN8.IsChecked = false;
        AppUIChooser = 0;
        MiddleStackPanel.Children.Clear();
        HasUIRendered = false;
    }

    private void AppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (AppUIChooser == 1)
        {
            if (FirstmyTBArray[0].Text != null && FirstmyTBArray[0].Text.CompareTo("") != 0)
            {
                File.WriteAllText(AdminServerIPAppRootFolder + "IP.txt", FirstmyTBArray[0].Text);
                FirstmyTBArray[1].Text = "Created Server IP file";
                ServerIPTB.Text = FirstmyTBArray[0].Text;
                APIIPAddressHelper.IPAddress = FirstmyTBArray[0].Text;
                APIIPAddressHelper.HasSet = true;
            }
        }
        else if (AppUIChooser == 2)
        {
            CreateETLS.CreateOrChangeETLS();
            String ETLSID = File.ReadAllText(AdminETLSAppRootFolder + "ETLSID.txt");
            SecondmyTBArray[0].Text = ETLSID;
            SecondmyTBArray[1].Text = CreateETLS.Status;
        }
        else if (AppUIChooser == 3)
        {
            if (ThirdmyTBArray[0].Text!=null && ThirdmyTBArray[0].Text.CompareTo("") != 0) 
            {
                String QuantityString = ThirdmyTBArray[0].Text;
                Boolean IsInt = true;
                try
                {
                    Int32 Quantity = Int32.Parse(QuantityString);
                }
                catch 
                {
                    IsInt = false;
                }
                if (IsInt == true) 
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.GetAsync("CreateReceivePayment?Quantity=" + QuantityString);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            if (Result.Contains("Error") == false)
                            {
                                ThirdmyTBArray[1].Text = Result.Substring(1, Result.Length - 2);
                            }
                            else
                            {
                                ThirdmyTBArray[1].Text = Result.Substring(1, Result.Length - 2);
                            }
                        }
                        else
                        {
                            ThirdmyTBArray[1].Text = "There's something wrong on the server side..";
                        }
                    }
                }
            }
        }
        else if (AppUIChooser == 4)
        {
            if (FourthmyTBArray[0].Text != null && FourthmyTBArray[0].Text.CompareTo("") != 0) 
            {
                if (FourthmyTBArray[1].Text != null && FourthmyTBArray[1].Text.CompareTo("") != 0) 
                {
                    String PaymentID = FourthmyTBArray[0].Text;
                    String SignedChallengeB64 = FourthmyTBArray[1].Text;
                    String ETLSID = File.ReadAllText(AdminETLSAppRootFolder + "ETLSID.txt");
                    RevampedKeyPair LTX25519SEKP = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                    RevampedKeyPair LTX25519MACKP = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                    RevampedKeyPair LTED25519KP = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    Byte[] SignedX25519SEPK = SodiumPublicKeyAuth.Sign(LTX25519SEKP.PublicKey, LTED25519KP.PrivateKey);
                    Byte[] SignedX25519MACPK = SodiumPublicKeyAuth.Sign(LTX25519MACKP.PublicKey, LTED25519KP.PrivateKey);
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.GetAsync("CreateReceivePayment/CheckPayment?ClientPathID="+ETLSID+"&Payment_ID="+PaymentID+"&SignedChallenge="+ System.Web.HttpUtility.UrlEncode(SignedChallengeB64) + "&ED25519PK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(LTED25519KP.PublicKey))+"&SignedX25519SEPK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SignedX25519SEPK))+"&SignedX25519MACPK="+ System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(SignedX25519MACPK)));
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;
                            PaymentDBCredentialsModel MyDBCredentialsModel = new PaymentDBCredentialsModel();
                            MyDBCredentialsModel = JsonConvert.DeserializeObject<PaymentDBCredentialsModel>(Result);
                            if (MyDBCredentialsModel.Status.Contains("Error") == false) 
                            {
                                if (MyDBCredentialsModel.Status.Contains("Successed") == false) 
                                {
                                    String NonceB64 = MyDBCredentialsModel.Nonce;
                                    String EDBUserNameHMACB64 = MyDBCredentialsModel.EDBUserNameHMAC;
                                    String EDBUserNameB64 = MyDBCredentialsModel.EncryptedDBUserName;
                                    String EDBUserPasswordHMACB64 = MyDBCredentialsModel.EDBUserPasswordHMAC;
                                    String EDBUserPasswordB64 = MyDBCredentialsModel.EncryptedDBUserPassword;
                                    String EDBNameHMACB64 = MyDBCredentialsModel.EDBNameHMAC;
                                    String EDBNameB64 = MyDBCredentialsModel.EncryptedDBName;
                                    Byte[] SESharedSecret = File.ReadAllBytes(AdminETLSAppRootFolder + "SESharedSecret.txt");
                                    Byte[] MACSharedSecret = File.ReadAllBytes(AdminETLSAppRootFolder + "MACSharedSecret.txt");
                                    Byte[] Nonce = Convert.FromBase64String(NonceB64);
                                    Boolean AbleToVerifyEDBUserNameHMAC = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(EDBUserNameHMACB64), Convert.FromBase64String(EDBUserNameB64), MACSharedSecret);
                                    Boolean AbleToVerifyEDBUserPasswordHMAC = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(EDBUserPasswordHMACB64), Convert.FromBase64String(EDBUserPasswordB64), MACSharedSecret);
                                    Boolean AbleToVerifyEDBNameHMAC = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(EDBNameHMACB64), Convert.FromBase64String(EDBNameB64), MACSharedSecret, true);
                                    if(AbleToVerifyEDBUserNameHMAC == true && AbleToVerifyEDBUserPasswordHMAC == true && AbleToVerifyEDBNameHMAC==true) 
                                    {
                                        FourthmyTBArray[2].Text = Result.Substring(1, Result.Length - 2);
                                        Byte[] DBUserNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(EDBUserNameB64), Nonce, SESharedSecret);
                                        Byte[] DBUserPasswordByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(EDBUserPasswordB64), Nonce, SESharedSecret);
                                        Byte[] DBNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(EDBNameB64),Nonce, SESharedSecret,true);
                                        File.WriteAllText(AdminDBCredentialsAppRootFolder + "PaymentID.txt", PaymentID);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "DBUserName.txt", DBUserNameByte);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "DBUserPassword.txt", DBUserPasswordByte);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "DBName.txt", DBNameByte);
                                        File.WriteAllBytes(AdminED25519KPAppRootFolder + "ED25519SK.txt", LTED25519KP.PrivateKey);
                                        File.WriteAllBytes(AdminED25519KPAppRootFolder + "ED25519PK.txt", LTED25519KP.PublicKey);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "X25519SESK.txt", LTX25519SEKP.PrivateKey);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "X25519SEPK.txt", LTX25519SEKP.PublicKey);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "X25519MACSK.txt", LTX25519MACKP.PrivateKey);
                                        File.WriteAllBytes(AdminDBCredentialsAppRootFolder + "X25519MACPK.txt", LTX25519MACKP.PublicKey);
                                        FourthmyTBArray[2].Text = "Successfully decrypt the db credentials and store them in files";
                                    }
                                    else 
                                    {
                                        FourthmyTBArray[2].Text = "Unable to decrypt the encrypted DB credentials";
                                    }
                                }
                            }
                            if (FourthmyTBArray[2].Text!=null)
                            {
                                FourthmyTBArray[2].Text += Environment.NewLine +MyDBCredentialsModel.Status;
                            }
                            else 
                            {
                                FourthmyTBArray[2].Text = MyDBCredentialsModel.Status;
                            }
                        }
                        else
                        {
                            FourthmyTBArray[2].Text = "There's something wrong on the server side..";
                        }
                    }
                    LTX25519MACKP.Clear();
                    LTX25519SEKP.Clear();
                    LTED25519KP.Clear();
                }
            }
        }
        else if (AppUIChooser == 5)
        {
            if (File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt") ==false) 
            {
                CreateOrDeleteSealedETLS.InitiateETLSAndCreateSealedDBCredentials();
                FifthmyTBArray[0].Text = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt");
                FifthmyTBArray[1].Text = CreateOrDeleteSealedETLS.Status;
            }
            else 
            {
                FifthmyTBArray[1].Text = "Unable to create new Sealed ETLS, kindly delete the old credentials";
            }
        }
        else if (AppUIChooser == 6)
        {
            if (File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt") == true)
            {
                CreateOrDeleteSealedETLS.DeleteETLSAndSealedCredentials();
                SixthmyTBArray[0].Text = CreateOrDeleteSealedETLS.Status;
            }
            else
            {
                SixthmyTBArray[0].Text = "Unable to delete Sealed ETLS because there're no established ETLS";
            }
        }
        else if (AppUIChooser == 7)
        {
            if (File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt") == true) 
            {
                String SealedDBUserName = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt");
                String SealedDBUserNameHMAC = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserNameHMAC.txt");
                String SealedETLSID = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt");
                String PaymentID = File.ReadAllText(AdminDBCredentialsAppRootFolder + "PaymentID.txt");
                ChallengeRequestor.RequestChallenge();
                Byte[] ED25519SK = File.ReadAllBytes(AdminED25519KPAppRootFolder + "ED25519SK.txt");
                Byte[] SignedChallenge = SodiumPublicKeyAuth.Sign(ChallengeRequestor.Challenge, ED25519SK, true);
                LockDBAccountModel MyLockDBAccountModel = new LockDBAccountModel();
                MyLockDBAccountModel.EncryptedDBUserName = SealedDBUserName;
                MyLockDBAccountModel.EDBUserNameHMAC = SealedDBUserNameHMAC;
                MyLockDBAccountModel.SealedSessionID = SealedETLSID;
                MyLockDBAccountModel.UniquePaymentID = PaymentID;
                MyLockDBAccountModel.SignedRandomChallenge = Convert.ToBase64String(SignedChallenge);
                String JSONBodyString = "";
                StringContent PostRequestData = new StringContent("");
                JSONBodyString = JsonConvert.SerializeObject(MyLockDBAccountModel);
                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.PostAsync("LockDBAccount",PostRequestData);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;
                        String NewResult = Result.Substring(1, Result.Length - 2);
                        SeventhmyTBArray[0].Text = NewResult;
                    }
                    else
                    {
                        SeventhmyTBArray[0].Text = "There's something wrong on the server side..";
                    }
                }
            }
            else 
            {
                SeventhmyTBArray[0].Text = "Unable to lock account as there's no sealed session";
            }
        }
        else if (AppUIChooser == 8)
        {
            if (File.Exists(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt") == true)
            {
                String SealedDBUserName = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserName.txt");
                String SealedDBUserNameHMAC = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedDBUserNameHMAC.txt");
                String SealedETLSID = File.ReadAllText(AdminSealedDBCredentialsAppRootFolder + "SealedETLSID.txt");
                String PaymentID = File.ReadAllText(AdminDBCredentialsAppRootFolder + "PaymentID.txt");
                ChallengeRequestor.RequestChallenge();
                Byte[] ED25519SK = File.ReadAllBytes(AdminED25519KPAppRootFolder + "ED25519SK.txt");
                Byte[] SignedChallenge = SodiumPublicKeyAuth.Sign(ChallengeRequestor.Challenge, ED25519SK, true);
                LockDBAccountModel MyLockDBAccountModel = new LockDBAccountModel();
                MyLockDBAccountModel.EncryptedDBUserName = SealedDBUserName;
                MyLockDBAccountModel.EDBUserNameHMAC = SealedDBUserNameHMAC;
                MyLockDBAccountModel.SealedSessionID = SealedETLSID;
                MyLockDBAccountModel.UniquePaymentID = PaymentID;
                MyLockDBAccountModel.SignedRandomChallenge = Convert.ToBase64String(SignedChallenge);
                String JSONBodyString = "";
                StringContent PostRequestData = new StringContent("");
                JSONBodyString = JsonConvert.SerializeObject(MyLockDBAccountModel);
                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.PostAsync("UnlockDBAccount", PostRequestData);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;
                        String NewResult = Result.Substring(1, Result.Length - 2);
                        EighthmyTBArray[0].Text = NewResult;
                    }
                    else
                    {
                        EighthmyTBArray[0].Text = "There's something wrong on the server side..";
                    }
                }
            }
            else
            {
                EighthmyTBArray[0].Text = "Unable to unlock account as there's no sealed session";
            }
        }
    }


}
