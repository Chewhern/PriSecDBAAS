﻿using Avalonia.Controls;

namespace PriSecDBAPI_CAdminApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
