﻿using System.Diagnostics;

namespace PriSecDBAPI.Helper
{
    public static class LockUnlockDBUser
    {
        public static void LockUnlockDBUserMethod(String DBUserName, Boolean IsLock=false) 
        {
            String LockUnlockDBUserCommand = "";
            if (IsLock == false)
            {
                LockUnlockDBUserCommand= "ALTER USER " + "'" + DBUserName + "'" + "@'localhost' ACCOUNT UNLOCK";
            }
            else 
            {
                LockUnlockDBUserCommand = "ALTER USER " + "'" + DBUserName + "'" + "@'localhost' ACCOUNT LOCK";
            }
            String Command = "";
            Command = " -e \""+LockUnlockDBUserCommand+ ";\"";
            String result = "";
            using (Process proc = new Process())
            {
                proc.StartInfo.FileName = "/usr/bin/mysql";
                proc.StartInfo.Arguments = Command;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.StartInfo.RedirectStandardError = true;
                proc.Start();

                result += proc.StandardOutput.ReadToEnd();
                result += proc.StandardError.ReadToEnd();
                proc.WaitForExit();
            }
            Console.WriteLine(result);
        }
    }
}
