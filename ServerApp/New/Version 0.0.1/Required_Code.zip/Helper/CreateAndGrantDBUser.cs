﻿using System.Diagnostics;

namespace PriSecDBAPI.Helper
{
    public static class CreateAndGrantDBUser
    {
        public static void CreateDBUserAndDBAndGrantDBUser(String DBUserName, String DBUserPassword, String DBName) 
        {
            String CreateUserCommand = "CREATE USER '" + DBUserName + "'" + "@" + "'localhost'" + " IDENTIFIED BY " + "'" + DBUserPassword + "'";
            String CreateDatabaseCommand = "CREATE DATABASE " + DBName;
            String GrantDatabaseUserCommand = "GRANT ALL ON " + DBName + ".*" + " TO '" + DBUserName + "'@'localhost'";
            String Command = "";
            Command = " -e \"" + CreateUserCommand + ";" + CreateDatabaseCommand + ";" + GrantDatabaseUserCommand + ";\"";
            String result = "";
            using (Process proc = new Process())
            {
                proc.StartInfo.FileName = "/usr/bin/mysql";
                proc.StartInfo.Arguments = Command;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.StartInfo.RedirectStandardError = true;
                proc.Start();

                result += proc.StandardOutput.ReadToEnd();
                result += proc.StandardError.ReadToEnd();
                proc.WaitForExit();
            }
            Console.WriteLine(result);
        }
    }
}
