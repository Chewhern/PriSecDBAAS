﻿namespace PriSecDBAPI.Model
{
    public class PaymentDBCredentialsModel
    {
        public String Nonce { get; set; }

        public String EDBUserNameHMAC { get; set; }

        public String EncryptedDBUserName { get; set; }

        public String EDBUserPasswordHMAC { get; set; }

        public String EncryptedDBUserPassword { get; set; }

        public String EDBNameHMAC { get; set; }

        public String EncryptedDBName { get; set; }

        public String Status { get; set; }
    }
}
