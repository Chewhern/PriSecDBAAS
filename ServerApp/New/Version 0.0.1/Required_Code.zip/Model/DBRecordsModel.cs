﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PriSecDBAPI.Model
{
    public class DBRecordsModel
    {
        public String Status { get; set; }

        public String[] ParameterValues { get; set; }
    }
}
