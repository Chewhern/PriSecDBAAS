﻿using Microsoft.AspNetCore.Mvc;
using ASodium;
using MySql.Data.MySqlClient;
using System.Text;
using PriSecDBAPI.Model;
using PriSecDBAPI.Helper;


namespace PriSecDBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LockDBAccount : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpPost]
        public String LockDBAccountFunction(LockDBAccountModel MyLockModel)
        {
            String Status = "";
            String Path = "/Projects/PriSecDBAPI/SealedSession/";
            Byte[] CipheredDBUserNameBytes = new Byte[] { };
            Byte[] CipheredDBUserNameHMACBytes = new Byte[] { };
            Byte[] DBUserNameByte = new Byte[] { };
            String DBUserName = "";
            String DatabaseDBUserName = "";
            Byte[] ServerSealedX25519SEPrivateKeyByte = new Byte[] { };
            Byte[] ClientX25519SEPublicKeyByte = new Byte[] { };
            Byte[] ServerSealedX25519MACPrivateKeyByte = new Byte[] { };
            Byte[] ClientX25519MACPublicKeyByte = new Byte[] { };
            int PaymentIDCount = 0;
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            DateTime MyUTC8DateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseExpirationTime = new DateTime();
            DateTime RandomChallengeValidDateTime = new DateTime();
            TimeSpan TimeDifference = new TimeSpan();
            Byte[] ED25519PKByte = new Byte[] { };
            Byte[] SignedRandomChallengeByte = new Byte[] { };
            Byte[] RandomChallengeByte = new Byte[] { };
            Byte[] SEKey = new Byte[] { };
            Byte[] MACKey = new Byte[] { };
            int Count = 0;
            if (MyLockModel != null)
            {
                if (MyLockModel.SealedSessionID != null)
                {
                    Path += MyLockModel.SealedSessionID;
                    if (Directory.Exists(Path) == true)
                    {
                        try
                        {
                            ServerSealedX25519SEPrivateKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "X25519SESK.txt");
                        }
                        catch
                        {
                            Status = "Error: Can't find server X25519 SE private key";
                            return Status;
                        }
                        try
                        {
                            ServerSealedX25519MACPrivateKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "X25519MACSK.txt");
                        }
                        catch
                        {
                            Status = "Error: Can't find server X25519 MAC private key";
                            return Status;
                        }
                        ClientX25519MACPublicKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "CX25519MACPK.txt");
                        ClientX25519SEPublicKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "CX25519SEPK.txt");
                        SEKey = SodiumScalarMult.Mult(ServerSealedX25519SEPrivateKeyByte, ClientX25519SEPublicKeyByte, true);
                        MACKey = SodiumScalarMult.Mult(ServerSealedX25519MACPrivateKeyByte, ClientX25519MACPublicKeyByte, true);

                        try
                        {
                            Boolean AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MyLockModel.EDBUserNameHMAC), Convert.FromBase64String(MyLockModel.EncryptedDBUserName), MACKey, true);
                            if (AbleToVerifyHMAC == false)
                            {
                                throw new Exception("Error:Unable to verify HMAC");
                            }
                            Byte[] Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), ClientX25519MACPublicKeyByte.Concat(ClientX25519SEPublicKeyByte).ToArray());
                            DBUserNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MyLockModel.EncryptedDBUserName), Nonce, SEKey, true);
                        }
                        catch
                        {
                            Status = "Error: Unable to decrypt sealed DB credentials";
                            return Status;
                        }
                        DBUserName = Encoding.UTF8.GetString(DBUserNameByte);
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MyLockModel.UniquePaymentID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        PaymentIDCount = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (PaymentIDCount == 1)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `Expiry_Date` FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MyLockModel.UniquePaymentID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseExpirationTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (DateTime.Compare(MyUTC8DateTime, DatabaseExpirationTime) <= 0)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `ED25519PK` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                                MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MyLockModel.UniquePaymentID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                ED25519PKByte = Convert.FromBase64String(MySQLGeneralQuery.ExecuteScalar().ToString());
                                try
                                {
                                    SignedRandomChallengeByte = Convert.FromBase64String(MyLockModel.SignedRandomChallenge);
                                }
                                catch
                                {
                                    Status = "Error: Signed random challenge can't be convert from Base64 to byte array";
                                    return Status;
                                }
                                try
                                {
                                    RandomChallengeByte = SodiumPublicKeyAuth.Verify(SignedRandomChallengeByte, ED25519PKByte);
                                }
                                catch
                                {
                                    Status = "Error: Random challenge can't be verified through ED25519PK that's in database";
                                    return Status;
                                }
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Random_Challenge` WHERE `Challenge`=@Challenge";
                                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallengeByte);
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                if (Count == 1)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `Random_Challenge` WHERE `Challenge`=@Challenge";
                                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallengeByte);
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    RandomChallengeValidDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    TimeDifference = MyUTC8DateTime.Subtract(RandomChallengeValidDateTime);
                                    if (TimeDifference.TotalMinutes < 8)
                                    {
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `DBUserName` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MyLockModel.UniquePaymentID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        DatabaseDBUserName = MySQLGeneralQuery.ExecuteScalar().ToString();
                                        if (DatabaseDBUserName.CompareTo(DBUserName) == 0)
                                        {
                                            LockUnlockDBUser.LockUnlockDBUserMethod(DBUserName, true);
                                            SodiumSecureMemory.SecureClearBytes(CipheredDBUserNameBytes);
                                            SodiumSecureMemory.SecureClearBytes(DBUserNameByte);
                                            SodiumSecureMemory.SecureClearString(DBUserName);
                                            SodiumSecureMemory.SecureClearString(MyLockModel.SealedSessionID);
                                            Status = "Success: The specified DB user account have been locked";
                                            return Status;
                                        }
                                        else
                                        {
                                            Status = "Error: This database user does not exist";
                                            return Status;
                                        }
                                    }
                                    else
                                    {
                                        SodiumSecureMemory.SecureClearBytes(CipheredDBUserNameBytes);
                                        SodiumSecureMemory.SecureClearBytes(DBUserNameByte);
                                        SodiumSecureMemory.SecureClearString(DBUserName);
                                        SodiumSecureMemory.SecureClearString(MyLockModel.SealedSessionID);
                                        Status = "Error: The random challenge is no longer valid";
                                        return Status;
                                    }
                                }
                                else
                                {
                                    SodiumSecureMemory.SecureClearBytes(CipheredDBUserNameBytes);
                                    SodiumSecureMemory.SecureClearBytes(DBUserNameByte);
                                    SodiumSecureMemory.SecureClearString(DBUserName);
                                    SodiumSecureMemory.SecureClearString(MyLockModel.SealedSessionID);
                                    Status = "Error: Random challenge does not exist in database";
                                    return Status;
                                }
                            }
                            else
                            {
                                SodiumSecureMemory.SecureClearBytes(CipheredDBUserNameBytes);
                                SodiumSecureMemory.SecureClearBytes(DBUserNameByte);
                                SodiumSecureMemory.SecureClearString(DBUserName);
                                SodiumSecureMemory.SecureClearString(MyLockModel.SealedSessionID);
                                Status = "Error: You haven't renew the database hosting service";
                                return Status;
                            }
                        }
                        else
                        {
                            SodiumSecureMemory.SecureClearBytes(CipheredDBUserNameBytes);
                            SodiumSecureMemory.SecureClearBytes(DBUserNameByte);
                            SodiumSecureMemory.SecureClearString(DBUserName);
                            SodiumSecureMemory.SecureClearString(MyLockModel.SealedSessionID);
                            Status = "Error: The sent payment ID does not exists";
                            return Status;
                        }

                    }
                    else
                    {
                        Status = "Error: The sealed session ID does not exist";
                        return Status;
                    }
                }
                else
                {
                    Status = "Error: The sealed session ID can't be null";
                    return Status;
                }
            }
            else
            {
                Status = "Error: LockDBAccountModel can't be null";
                return Status;
            }
        }
    }
}
