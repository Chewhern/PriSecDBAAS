﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ASodium;
using System.Text;
using System.IO;
using System.Web;
using PriSecDBAPI.Model;

namespace PriSecDBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ECDH_ECDSA_TempSession : ControllerBase
    {

        [HttpGet("byID")]
        public ECDH_ECDSA_Models TempSession(String ClientPathID) 
        {
            ECDH_ECDSA_Models MyECDH_ECDSA_Models = new ECDH_ECDSA_Models();
            StringBuilder MyStringBuilder = new StringBuilder();
            Byte[] ServerECDSAPK = new Byte[] { };
            Byte[] ServerECDHSPK = new Byte[] { };
            RevampedKeyPair ServerSEKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
            RevampedKeyPair ServerMACKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
            RevampedKeyPair ServerED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            String Path = "/Projects/PriSecDBAPI/TempSession/";
            if (ClientPathID != null && ClientPathID.CompareTo("") != 0)
            {
                Path += ClientPathID;
                if (Directory.Exists(Path)==true)
                {
                    MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String = "None";
                    MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String = "None";
                    MyECDH_ECDSA_Models.ED25519_PK_Base64String = "None";
                    MyECDH_ECDSA_Models.ID_Checker_Message = "Error: This temporary session ID already exist";
                }
                else 
                {
                    Directory.CreateDirectory(Path);
                    ServerECDSAPK = ServerED25519KeyPair.PublicKey;
                    ServerECDHSPK = SodiumPublicKeyAuth.Sign(ServerSEKeyPair.PublicKey, ServerED25519KeyPair.PrivateKey);                    
                    MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String = Convert.ToBase64String(ServerECDHSPK);
                    ServerECDHSPK = SodiumPublicKeyAuth.Sign(ServerMACKeyPair.PublicKey, ServerED25519KeyPair.PrivateKey);
                    MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String = Convert.ToBase64String(ServerECDHSPK);
                    MyECDH_ECDSA_Models.ED25519_PK_Base64String = Convert.ToBase64String(ServerECDSAPK);
                    System.IO.File.WriteAllBytes(Path +  "/" + "X25519SESK.txt", ServerSEKeyPair.PrivateKey);
                    System.IO.File.WriteAllBytes(Path + "/" + "X25519MACSK.txt", ServerMACKeyPair.PrivateKey);
                    MyECDH_ECDSA_Models.ID_Checker_Message = "Success: The temporary session ID had been created";
                }
            }
            else 
            {
                MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String = "None";
                MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String = "None";
                MyECDH_ECDSA_Models.ED25519_PK_Base64String = "None";
                MyECDH_ECDSA_Models.ID_Checker_Message = "Error: Please provide an ID";
            }
            ServerSEKeyPair.Clear();
            ServerMACKeyPair.Clear();
            ServerED25519KeyPair.Clear();
            return MyECDH_ECDSA_Models;
        }

        [HttpGet("InitiateDeletionOfETLS")]
        public String InitiateDeletionOfETLS(String ClientPathID)
        {
            String Status = "";
            String Result = "";
            String Path = "/Projects/PriSecDBAPI/TempSession/";
            Path += ClientPathID;
            Byte[] RVDataByte = SodiumRNG.GetRandomBytes(128);
            Boolean CheckIfRVDataFileExists = true;
            DateTime ExpirationUTC8Time = new DateTime();
            if (Directory.Exists(Path))
            {
                if (System.IO.File.Exists(Path + "/Confirmation.txt") == true)
                {
                    CheckIfRVDataFileExists = true;
                }
                else
                {
                    CheckIfRVDataFileExists = false;
                }
                if (CheckIfRVDataFileExists == false)
                {
                    Status = "Error: You have not yet check if your shared secret is the same as server's";
                    Result = Status;
                }
                if (CheckIfRVDataFileExists == true)
                {
                    System.IO.File.WriteAllText(Path + "/IDStatus.txt", "Initiating Deletion Of ETLS");
                    ExpirationUTC8Time = DateTime.UtcNow.AddHours(8);
                    System.IO.File.SetLastWriteTime(Path + "/IDStatus.txt", ExpirationUTC8Time);
                    System.IO.File.WriteAllBytes(Path + "/RVData.txt", RVDataByte);
                    Status = Convert.ToBase64String(RVDataByte);
                    Result = Status;
                }
            }
            else
            {
                Status = "Error: Client Path does not exists or deleted...";
                Result = Status;
            }
            return Result;
        }

        [HttpGet("DeleteByClientCryptographicID")]
        public String DeleteClientCryptographicSessionPathID(String ClientPathID, String ValidationData)
        {
            String Status = "";
            String Path = "/Projects/PriSecDBAPI/TempSession/";
            Byte[] ClientED25519PK = new Byte[] { };
            Path += ClientPathID;
            Boolean DecodingBoolean = true;
            Boolean VerifyBoolean = true;
            Boolean ConvertFromBase64Boolean = true;
            Boolean IsValidationDataExist = true;
            String DecodedValidationDataString = "";
            Byte[] ValidationDataByte = new Byte[] { };
            Byte[] ValidatedDataByte = new Byte[] { };
            Byte[] RVDataByte = new Byte[] { };
            DateTime SystemDateTime = new DateTime();
            DateTime CurrentDateTime = new DateTime();
            TimeSpan Duration = new TimeSpan();
            if (Directory.Exists(Path))
            {
                ClientED25519PK = System.IO.File.ReadAllBytes(Path + "/" + "ED25519PK.txt");
                try
                {
                    if (ValidationData.Contains("+"))
                    {
                        DecodedValidationDataString = ValidationData;
                    }
                    else
                    {
                        DecodedValidationDataString = HttpUtility.UrlDecode(ValidationData);
                    }
                }
                catch
                {
                    DecodingBoolean = false;
                }
                if (DecodingBoolean == true)
                {
                    try
                    {
                        ValidationDataByte = Convert.FromBase64String(DecodedValidationDataString);
                    }
                    catch
                    {
                        ConvertFromBase64Boolean = false;
                    }
                    if (ConvertFromBase64Boolean == true)
                    {
                        try
                        {
                            SystemDateTime = System.IO.File.GetLastWriteTime(Path + "/IDStatus.txt");
                        }
                        catch
                        {
                            IsValidationDataExist = false;
                        }
                        if (IsValidationDataExist == true)
                        {
                            RVDataByte = System.IO.File.ReadAllBytes(Path + "/RVData.txt");
                            try
                            {
                                ValidatedDataByte = SodiumPublicKeyAuth.Verify(ValidationDataByte, ClientED25519PK);
                            }
                            catch
                            {
                                VerifyBoolean = false;
                            }
                            if (VerifyBoolean == true)
                            {
                                if (ValidatedDataByte.SequenceEqual(RVDataByte) == true)
                                {
                                    CurrentDateTime = DateTime.UtcNow.AddHours(8);
                                    Duration = CurrentDateTime.Subtract(SystemDateTime);
                                    if (Duration.TotalMinutes < 8)
                                    {
                                        try
                                        {
                                            Directory.Delete(Path, true);
                                            Status = "Successfully deleted....";
                                        }
                                        catch (Exception ex)
                                        {
                                            Status = "Error: Something went wrong... Here's the error: " + ex.ToString();
                                        }
                                    }
                                    else
                                    {
                                        Status = "Error: You need to reinitiate the deletion request of ETLS";
                                    }
                                }
                                else
                                {
                                    Status = "Error: The random validation data stored on server is unmatch with the validation data you submit";
                                }
                            }
                            else
                            {
                                Status = "Error: Are you an imposter? ECDSA(ED25519) public key doesn't match";
                            }
                        }
                        else
                        {
                            Status = "Error: You have not yet initiate an ETLS delete request";
                        }
                    }
                    else
                    {
                        Status = "Error: You didn't pass in correct Base 64 encoded parameter value..";
                    }
                }
                else
                {
                    Status = "Error: You didn't pass in correct URL encoded parameter value..";
                }
            }
            else
            {
                Status = "Error: Client Path does not exists or deleted...";
            }
            return Status;
        }

        [HttpGet("ByHandshake")]
        public String ECDHE_ECDSA_Session(String ClientPathID, String SX25519SEPK,String SX25519MACPK,String ED25519PK) 
        {
            String SessionStatus = "";
            Byte[] X25519SESK = new Byte[] { };
            Byte[] X25519MACSK = new Byte[] { };
            Byte[] ClientSignedX25519SEPK = new Byte[] { };
            Byte[] ClientX25519SEPK = new Byte[] { };
            Byte[] ClientED25519PK = new Byte[] { };
            Byte[] ClientSignedX25519MACPK = new Byte[] { };
            Byte[] ClientX25519MACPK = new Byte[] { };
            Byte[] SESharedSecret = new Byte[] { };
            Byte[] MACSharedSecret = new Byte[] { };
            String Path = "/Projects/PriSecDBAPI/TempSession/";
            Path += ClientPathID;
            String DecodedSEX25519PK = "";
            String DecodedMACX25519PK = "";
            String DecodedED25519PK = "";
            Boolean URLDecodeChecker1 = true;
            Boolean URLDecodeChecker2 = true;
            Boolean URLDecodeChecker3 = true;
            Boolean Base64StringChecker1 = true;
            Boolean Base64StringChecker2 = true;
            Boolean Base64StringChecker3 = true;
            Boolean VerifyBoolean = true;
            if (ClientPathID != null && ClientPathID.CompareTo("") != 0)
            {
                if (Directory.Exists(Path))
                {
                    try 
                    {
                        if (SX25519SEPK.Contains("+")) 
                        {
                            DecodedSEX25519PK = SX25519SEPK;
                        }
                        else 
                        {
                            DecodedSEX25519PK = HttpUtility.UrlDecode(SX25519SEPK);
                        }
                    }
                    catch 
                    {
                        URLDecodeChecker1 = false;
                    }
                    try 
                    {
                        if (ED25519PK.Contains("+")) 
                        {
                            DecodedED25519PK = ED25519PK;
                        }
                        else 
                        {
                            DecodedED25519PK = HttpUtility.UrlDecode(ED25519PK);
                        }
                    }
                    catch 
                    {
                        URLDecodeChecker2 = false;
                    }
                    try
                    {
                        if (SX25519MACPK.Contains("+"))
                        {
                            DecodedMACX25519PK = SX25519MACPK;
                        }
                        else
                        {
                            DecodedMACX25519PK = HttpUtility.UrlDecode(SX25519MACPK);
                        }
                    }
                    catch
                    {
                        URLDecodeChecker3 = false;
                    }
                    if (URLDecodeChecker1==true && URLDecodeChecker2 == true && URLDecodeChecker3==true) 
                    {
                        try 
                        {
                            ClientSignedX25519SEPK = Convert.FromBase64String(DecodedSEX25519PK);
                        }
                        catch 
                        {
                            Base64StringChecker1 = false;
                        }
                        try 
                        {
                            ClientED25519PK = Convert.FromBase64String(DecodedED25519PK);
                        }
                        catch 
                        {
                            Base64StringChecker2 = false;
                        }
                        try
                        {
                            ClientED25519PK = Convert.FromBase64String(DecodedED25519PK);
                        }
                        catch
                        {
                            Base64StringChecker2 = false;
                        }
                        try
                        {
                            ClientSignedX25519MACPK = Convert.FromBase64String(DecodedMACX25519PK);
                        }
                        catch
                        {
                            Base64StringChecker3 = false;
                        }
                        if (Base64StringChecker1==true && Base64StringChecker2 == true && Base64StringChecker3==true) 
                        {
                            try 
                            {
                                ClientX25519SEPK = SodiumPublicKeyAuth.Verify(ClientSignedX25519SEPK,ClientED25519PK);
                                ClientX25519MACPK = SodiumPublicKeyAuth.Verify(ClientSignedX25519MACPK, ClientED25519PK);
                            }
                            catch 
                            {
                                VerifyBoolean = false;
                            }
                            if (VerifyBoolean == true) 
                            {
                                X25519SESK = System.IO.File.ReadAllBytes(Path + "/" + "X25519SESK.txt");
                                SESharedSecret = SodiumScalarMult.Mult(X25519SESK, ClientX25519SEPK,true); 
                                System.IO.File.WriteAllBytes(Path + "/" + "SESharedSecret.txt", SESharedSecret);
                                X25519MACSK = System.IO.File.ReadAllBytes(Path + "/" + "X25519MACSK.txt");
                                MACSharedSecret = SodiumScalarMult.Mult(X25519MACSK, ClientX25519MACPK, true);
                                System.IO.File.WriteAllBytes(Path + "/" + "MACSharedSecret.txt", MACSharedSecret);
                                System.IO.File.WriteAllBytes(Path + "/" + "ED25519PK.txt", ClientED25519PK);
                                System.IO.File.Delete(Path + "/" + "X25519SESK.txt");
                                System.IO.File.Delete(Path + "/" + "X25519MACSK.txt");
                                SessionStatus = "Successed... You have established 2 ephemeral shared secrets with the server for domain separation purpose.";
                            }
                            else 
                            {
                                SessionStatus = "Error: Are you an imposter trying to mimic the session?(ED25519 keypair not match)";
                            }
                        }
                        else 
                        {
                            SessionStatus = "Error: You didn't pass in correct Base64 format paramter values";
                        }
                    }
                    else 
                    {
                        SessionStatus = "Error: You didn't pass in correct URL encoded parameter value...";
                    }
                }
                else 
                {
                    SessionStatus = "Error: You don't pass in correct ClientSessionID";
                }
            }
            else 
            {
                SessionStatus = "Error: You don't specify the client path ID";
            }
            SodiumSecureMemory.SecureClearBytes(SESharedSecret);
            SodiumSecureMemory.SecureClearBytes(MACSharedSecret);
            return SessionStatus;
        }

        [HttpGet("BySharedSecret")]
        public String CheckSharedSecret(String ClientPathID, String SECipheredData,String MACCipheredData, String Nonce)
        {
            String CheckSharedSecretStatus = "";
            Byte[] SESharedSecret = new Byte[] { };
            Byte[] MACSharedSecret = new Byte[] { };
            Byte[] CipheredSEDataByte = new Byte[] { };
            Byte[] CipheredMACDataByte = new Byte[] { };
            Byte[] NonceByte = new Byte[] { };
            Byte[] TestDecryptedByte = new Byte[] { };
            String Path = "/Projects/PriSecDBAPI/TempSession/";
            Path += ClientPathID;
            String DecodedSECipheredData = "";
            String DecodedMACCipheredData = "";
            String DecodedNonce = "";
            Boolean URLDecodeChecker1 = true;
            Boolean URLDecodeChecker2 = true;
            Boolean URLDecodeChecker3 = true;
            Boolean Base64StringChecker1 = true;
            Boolean Base64StringChecker2 = true;
            Boolean Base64StringChecker3 = true;
            if (ClientPathID != null && ClientPathID.CompareTo("") != 0)
            {
                if (Directory.Exists(Path))
                {
                    SESharedSecret = System.IO.File.ReadAllBytes(Path + "/" + "SESharedSecret.txt");
                    MACSharedSecret = System.IO.File.ReadAllBytes(Path + "/" + "MACSharedSecret.txt");
                    try
                    {
                        if (SECipheredData.Contains("+"))
                        {
                            DecodedSECipheredData = SECipheredData;
                        }
                        else
                        {
                            DecodedSECipheredData = HttpUtility.UrlDecode(SECipheredData);
                        }
                    }
                    catch
                    {
                        URLDecodeChecker1 = false;
                    }
                    try
                    {
                        if (Nonce.Contains("+"))
                        {
                            DecodedNonce = Nonce;
                        }
                        else
                        {
                            DecodedNonce = HttpUtility.UrlDecode(Nonce);
                        }
                    }
                    catch
                    {
                        URLDecodeChecker2 = false;
                    }
                    try
                    {
                        if (MACCipheredData.Contains("+"))
                        {
                            DecodedMACCipheredData = MACCipheredData;
                        }
                        else
                        {
                            DecodedMACCipheredData = HttpUtility.UrlDecode(MACCipheredData);
                        }
                    }
                    catch
                    {
                        URLDecodeChecker3 = false;
                    }
                    if (URLDecodeChecker1 == true && URLDecodeChecker2 == true && URLDecodeChecker3 == true)
                    {
                        try
                        {
                            CipheredSEDataByte = Convert.FromBase64String(DecodedSECipheredData);
                        }
                        catch
                        {
                            Base64StringChecker1 = false;
                        }
                        try
                        {
                            NonceByte = Convert.FromBase64String(DecodedNonce);
                        }
                        catch
                        {
                            Base64StringChecker2 = false;
                        }
                        try
                        {
                            CipheredMACDataByte = Convert.FromBase64String(DecodedMACCipheredData);
                        }
                        catch
                        {
                            Base64StringChecker3 = false;
                        }
                        if (Base64StringChecker1 == true && Base64StringChecker2 == true && Base64StringChecker3 == true)
                        {
                            try
                            {
                                TestDecryptedByte = SodiumSecretBox.Open(CipheredSEDataByte, NonceByte, SESharedSecret);
                                TestDecryptedByte = SodiumSecretBox.Open(CipheredMACDataByte, NonceByte, MACSharedSecret);
                                CheckSharedSecretStatus = "Successed... The shared secret matched";
                                System.IO.File.Create(Path + "/Confirmation.txt");
                            }
                            catch
                            {
                                CheckSharedSecretStatus = "Error: The shared secret does not match";
                            }
                        }
                        else
                        {
                            CheckSharedSecretStatus = "Error: You didn't pass in correct Base64 format paramter values";
                        }
                    }
                    else
                    {
                        CheckSharedSecretStatus = "Error: You didn't pass in correct URL encoded parameter value...";
                    }
                }
                else
                {
                    CheckSharedSecretStatus = "Error: You don't pass in correct ClientSessionID";
                }
            }
            else
            {
                CheckSharedSecretStatus = "Error: You don't specify the client path ID";
            }
            SodiumSecureMemory.SecureClearBytes(SESharedSecret);
            return CheckSharedSecretStatus;
        }
    }
}
