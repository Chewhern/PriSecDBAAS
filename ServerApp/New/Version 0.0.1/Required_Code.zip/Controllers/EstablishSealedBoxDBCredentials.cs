﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASodium;
using System.Text;
using System.IO;
using MySql.Data.MySqlClient;
using PriSecDBAPI.Model;
using PriSecDBAPI.Helper;
using System.Web;

namespace PriSecDBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstablishSealedBoxDBCredentials : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public ECDH_ECDSA_Models TempSession(String ClientPathID,String X25519SEPK,String X25519MACPK)
        {
            ECDH_ECDSA_Models MyECDH_ECDSA_Models = new ECDH_ECDSA_Models();
            StringBuilder MyStringBuilder = new StringBuilder();
            Byte[] ServerECDSAPK = new Byte[] { };
            Byte[] ServerECDHSPK = new Byte[] { };
            RevampedKeyPair ServerSEKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
            RevampedKeyPair ServerMACKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
            RevampedKeyPair ServerED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            String Path = "/Projects/PriSecDBAPI/SealedSession/";
            if (ClientPathID != null && ClientPathID.CompareTo("") != 0 &&
                X25519SEPK!=null && X25519SEPK.CompareTo("")!=0 &&
                X25519MACPK!=null && X25519MACPK.CompareTo("")!=0)
            {
                Path += ClientPathID;
                if (Directory.Exists(Path) == true)
                {
                    MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String = "None";
                    MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String = "None";
                    MyECDH_ECDSA_Models.ED25519_PK_Base64String = "None";
                    MyECDH_ECDSA_Models.ID_Checker_Message = "Error: This sealed session ID already exist";
                }
                else
                {
                    Directory.CreateDirectory(Path);
                    ServerECDSAPK = ServerED25519KeyPair.PublicKey;
                    ServerECDHSPK = SodiumPublicKeyAuth.Sign(ServerSEKeyPair.PublicKey, ServerED25519KeyPair.PrivateKey);
                    MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String = Convert.ToBase64String(ServerECDHSPK);
                    ServerECDHSPK = SodiumPublicKeyAuth.Sign(ServerMACKeyPair.PublicKey, ServerED25519KeyPair.PrivateKey);
                    MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String = Convert.ToBase64String(ServerECDHSPK);
                    MyECDH_ECDSA_Models.ED25519_PK_Base64String = Convert.ToBase64String(ServerECDSAPK);
                    System.IO.File.WriteAllBytes(Path + "/" + "X25519SESK.txt", ServerSEKeyPair.PrivateKey);
                    System.IO.File.WriteAllBytes(Path + "/" + "X25519MACSK.txt", ServerMACKeyPair.PrivateKey);
                    System.IO.File.WriteAllBytes(Path + "/" + "CX25519SEPK.txt", Convert.FromBase64String(X25519SEPK));
                    System.IO.File.WriteAllBytes(Path + "/" + "CX25519MACPK.txt", Convert.FromBase64String(X25519MACPK));
                    MyECDH_ECDSA_Models.ID_Checker_Message = "Success: The sealed session ID had been created";
                }
            }
            else
            {
                MyECDH_ECDSA_Models.X25519_SE_SPK_Base64String = "None";
                MyECDH_ECDSA_Models.X25519_MAC_SPK_Base64String = "None";
                MyECDH_ECDSA_Models.ED25519_PK_Base64String = "None";
                MyECDH_ECDSA_Models.ID_Checker_Message = "Error: Please provide a sealed session ID,client X25519 PKs";
            }
            ServerSEKeyPair.Clear();
            ServerMACKeyPair.Clear();
            ServerED25519KeyPair.Clear();
            return MyECDH_ECDSA_Models;
        }

        [HttpGet("DeleteSealedSession")]
        public String DeleteSealedSession(String ClientPathID, String UniquePaymentID, String SignedRandomChallenge)
        {
            CryptographicSecureIDGenerator IDGenerator = new CryptographicSecureIDGenerator();
            DecodeDataClass decodeDataClass = new DecodeDataClass();
            ConvertFromBase64StringClass convertFromBase64StringClass = new ConvertFromBase64StringClass();
            Byte[] SignedRandomChallengeByte = new Byte[] { };
            Byte[] RandomChallengeByte = new Byte[] { };
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String Path = "/Projects/PriSecDBAPI/SealedSession/";
            Path += ClientPathID;
            DateTime MyUTC8Time = DateTime.UtcNow.AddHours(8);
            String DatabaseExpirationTimeString = "";
            DateTime DatabaseExpirationTime = new DateTime();
            Byte[] ED25519PKByte = new Byte[] { };
            int Count = 0;
            int PaymentIDCount = 0;
            DateTime RandomChallengeValidDuration = new DateTime();
            TimeSpan TimeDifference = new TimeSpan();
            if (ClientPathID != null && ClientPathID.CompareTo("") != 0)
            {
                if (Directory.Exists(Path))
                {
                    SignedRandomChallengeByte = Convert.FromBase64String(SignedRandomChallenge);
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = UniquePaymentID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    PaymentIDCount = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (PaymentIDCount == 1) 
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Expiry_Date` FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = UniquePaymentID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseExpirationTimeString = MySQLGeneralQuery.ExecuteScalar().ToString();
                        DatabaseExpirationTime = DateTime.Parse(DatabaseExpirationTimeString);
                        if (DateTime.Compare(MyUTC8Time, DatabaseExpirationTime) <= 0)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `ED25519PK` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = UniquePaymentID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            ED25519PKByte = Convert.FromBase64String(MySQLGeneralQuery.ExecuteScalar().ToString());
                            try
                            {
                                RandomChallengeByte = SodiumPublicKeyAuth.Verify(SignedRandomChallengeByte, ED25519PKByte);
                            }
                            catch
                            {
                                return "Error: Unable to verify user signed random challenge through database ED25519 PK";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Random_Challenge` WHERE `Challenge`=@Challenge";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallengeByte);
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `Random_Challenge` WHERE `Challenge`=@Challenge";
                                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallengeByte);
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                RandomChallengeValidDuration = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                TimeDifference = MyUTC8Time.Subtract(RandomChallengeValidDuration);
                                if (TimeDifference.Minutes < 8)
                                {
                                    Directory.Delete(Path,true);
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `Random_Challenge` WHERE `Challenge`=@Challenge";
                                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallengeByte);
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    MySQLGeneralQuery = new MySqlCommand();
                                    return "Successed: You have succesfully delete the sealed session";
                                }
                                else
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `Random_Challenge` WHERE `Challenge`=@Challenge";
                                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallengeByte);
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    return "Error: This challenge is no more valid as 8 minutes have passed";
                                }
                            }
                            else
                            {
                                return "Error: This server generated challenge no longer exists or valid";
                            }
                        }
                        else
                        {
                            return "Error: You can't delete the keys used to establish sealed box db credentials as you haven't renew payment";
                        }
                    }
                    else 
                    {
                        return "Error: The payment ID does not exist";
                    }                       
                }
                else
                {
                    return "Error: The corresponding ETLS ID does not exists in the server..";
                }
            }
            else
            {
                return "Error: The ETLS ID mustn't be null";
            }
        }
    }
}
