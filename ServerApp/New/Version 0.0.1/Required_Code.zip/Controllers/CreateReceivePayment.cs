﻿using Microsoft.AspNetCore.Mvc;
using ASodium;
using System.Text;
using MySql.Data.MySqlClient;
using PriSecDBAPI.Helper;
using System.Web;
using PriSecDBAPI.Model;

namespace PriSecDBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CreateReceivePayment : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();
        private CryptographicSecureIDGenerator IDGenerator = new CryptographicSecureIDGenerator();

        //
        [HttpGet]
        public String InitiatePayment(String Quantity) 
        {
            String Status = "";
            if (Quantity != null && Quantity.CompareTo("") != 0)
            {
                int QuantityInt = int.Parse(Quantity);
                Double UnitPrice = 12.5;
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                String ExceptionString = "";
                String UniquePaymentID = IDGenerator.GenerateUniqueString();
                //Expiry_Date
                //Payment_ID
                //Payment_Made
                //=====
                //Payment_ID
                //Quantity
                //TotalSize
                //TotalPrice
                if (QuantityInt < 1)
                {
                    Status = "Error: Quantity must be bigger or equals to 1";
                }
                else
                {
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "INSERT INTO `Payment`(`Payment_ID`,`Payment_Made`) VALUES (@Payment_ID,@Payment_Made)";
                    MySQLGeneralQuery.Parameters.Add("@Payment_Made", MySqlDbType.Text).Value = "False";
                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = UniquePaymentID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    MySQLGeneralQuery = new MySqlCommand();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "INSERT INTO `Payment_Details`(`Payment_ID`,`Quantity`,`TotalSize`,`TotalPrice`) VALUES (@Payment_ID,@Quantity,@TotalSize,@TotalPrice)";
                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = UniquePaymentID;
                    MySQLGeneralQuery.Parameters.Add("@Quantity", MySqlDbType.Text).Value = Quantity;
                    MySQLGeneralQuery.Parameters.Add("@TotalSize", MySqlDbType.Text).Value = QuantityInt * 5 * 5368709120;
                    MySQLGeneralQuery.Parameters.Add("@TotalPrice", MySqlDbType.Text).Value = QuantityInt * UnitPrice;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    Status = UniquePaymentID;
                }
            }
            else 
            {
                Status = "Error: You didn't specify quantity";
            }
            return Status;
        }

        //Semi-automatic
        //due to global geopolitcal reasons
        [HttpGet("InitiateCheckPayment")]
        public String InitiateCheckPayment(String Payment_ID) 
        {
            String Status = "";
            if (Payment_ID != null && Payment_ID.CompareTo("") != 0)
            {
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                String ExceptionString = "";
                int Count = 0;
                Byte[] RandomChallenge = SodiumRNG.GetRandomBytes(128);
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                if (Count == 0)
                {
                    Status = "Error: This payment ID doesn't exist";
                }
                else
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "INSERT INTO `Payment_Check_Initiation`(`Payment_ID`,`Challenge`,`Valid_Duration`) VALUES (@Payment_ID,@Challenge,@Valid_Duration)";
                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomChallenge);
                    MySQLGeneralQuery.Parameters.Add("@Valid_Duration", MySqlDbType.DateTime).Value = DateTime.UtcNow.AddHours(8);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    Status = Convert.ToBase64String(RandomChallenge);
                }
            }
            else
            {
                Status = "Error: You didn't specify a payment ID";
            }
            return Status;
        }

        [HttpGet("CheckPayment")]
        public PaymentDBCredentialsModel CheckPayment(String ClientPathID,String Payment_ID, String SignedChallenge,String ED25519PK,String SignedX25519SEPK,String SignedX25519MACPK)
        {
            PaymentDBCredentialsModel MyDBCredentialsModel = new PaymentDBCredentialsModel();
            String Status = "";
            if (ClientPathID != null && ClientPathID.CompareTo("") != 0)
            {
                if (Directory.Exists("/Projects/PriSecDBAPI/TempSession/" + ClientPathID) == true)
                {
                    if (System.IO.File.Exists("/Projects/PriSecDBAPI/TempSession/" + ClientPathID + "/MACSharedSecret.txt") == true &&
                        System.IO.File.Exists("/Projects/PriSecDBAPI/TempSession/" + ClientPathID + "/SESharedSecret.txt") == true)
                    {
                        if (Payment_ID != null && Payment_ID.CompareTo("") != 0)
                        {
                            if (SignedChallenge != null && SignedChallenge.CompareTo("") != 0)
                            {
                                if (ED25519PK != null && ED25519PK.CompareTo("") != 0 &&
                                    SignedX25519SEPK != null && SignedX25519SEPK.CompareTo("") != 0 &&
                                    SignedX25519MACPK != null && SignedX25519MACPK.CompareTo("") != 0)
                                {
                                    MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                                    String ExceptionString = "";
                                    int Count = 0;
                                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                    if (Count == 0)
                                    {
                                        Status = "Error: This payment ID doesn't exist";
                                    }
                                    else
                                    {
                                        Byte[] SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                                        Byte[] ChallengeBytes = new Byte[] { };
                                        Byte[] ED25519PKBytes = Convert.FromBase64String(ED25519PK);
                                        Byte[] SignedX25519MACPKBytes = Convert.FromBase64String(SignedX25519MACPK);
                                        Byte[] SignedX25519SEPKBytes = Convert.FromBase64String(SignedX25519SEPK);
                                        Byte[] ServerED25519PKBytes = new Byte[] { };
                                        MySQLGeneralQuery = new MySqlCommand();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MySQLGeneralQuery.CommandText = "SELECT `ED25519PK` FROM `Server_ED25519PK` LIMIT 1";
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        ServerED25519PKBytes = Convert.FromBase64String(MySQLGeneralQuery.ExecuteScalar().ToString());
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ServerED25519PKBytes);
                                        MySQLGeneralQuery = new MySqlCommand();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Payment_Check_Initiation` WHERE `Challenge`=@Challenge";
                                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        if (Count == 1)
                                        {
                                            DateTime CurrentUTC8DateTime = DateTime.UtcNow.AddHours(8);
                                            DateTime DatabaseUTC8DateTime;
                                            MySQLGeneralQuery = new MySqlCommand();
                                            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                            MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `Payment_Check_Initiation` WHERE `Challenge`=@Challenge";
                                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            DatabaseUTC8DateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                            myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                            TimeSpan Interval = CurrentUTC8DateTime.Subtract(DatabaseUTC8DateTime);
                                            if (Interval.TotalMinutes < 8)
                                            {
                                                MySQLGeneralQuery = new MySqlCommand();
                                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                MySQLGeneralQuery.CommandText = "DELETE FROM `Payment_Check_Initiation` WHERE `Challenge`=@Challenge";
                                                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                MySQLGeneralQuery.Prepare();
                                                MySQLGeneralQuery.ExecuteNonQuery();
                                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                try
                                                {
                                                    Byte[] X25519MACPKBytes = SodiumPublicKeyAuth.Verify(SignedX25519MACPKBytes, ED25519PKBytes);
                                                    Byte[] X25519SEPKBytes = SodiumPublicKeyAuth.Verify(SignedX25519SEPKBytes, ED25519PKBytes);
                                                    MySQLGeneralQuery = new MySqlCommand();
                                                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                    MySQLGeneralQuery.CommandText = "SELECT `Payment_Made` FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                                                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                    MySQLGeneralQuery.Prepare();
                                                    String Payment_Made = MySQLGeneralQuery.ExecuteScalar().ToString();
                                                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                    if (Payment_Made.CompareTo("True") == 0)
                                                    {
                                                        MySQLGeneralQuery = new MySqlCommand();
                                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                        MySQLGeneralQuery.CommandText = "SELECT `Expiry_Date` FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                        MySQLGeneralQuery.Prepare();
                                                        DateTime MyUTC8DateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                        MySQLGeneralQuery = new MySqlCommand();
                                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                        MySQLGeneralQuery.CommandText = "UPDATE `Payment` SET `Expiry_Date`=@Expiry_Date WHERE `Payment_ID`=@Payment_ID";
                                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                                                        if (DateTime.UtcNow.AddHours(8).Subtract(MyUTC8DateTime).TotalDays <= 30)
                                                        {
                                                            MySQLGeneralQuery.Parameters.Add("@Expiry_Date", MySqlDbType.DateTime).Value = MyUTC8DateTime.AddDays(30);
                                                        }
                                                        else
                                                        {
                                                            MySQLGeneralQuery.Parameters.Add("@Expiry_Date", MySqlDbType.DateTime).Value = DateTime.UtcNow.AddHours(8).AddDays(30);
                                                        }
                                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                        MySQLGeneralQuery.Prepare();
                                                        MySQLGeneralQuery.ExecuteNonQuery();
                                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                        Status = "Successed: Payment has been renewed";
                                                    }
                                                    else
                                                    {
                                                        String DBUserName = IDGenerator.GenerateUniqueString();
                                                        String DBUserPassword = IDGenerator.GenerateUniqueString();
                                                        String DBName = IDGenerator.GenerateUniqueString();
                                                        MySQLGeneralQuery = new MySqlCommand();
                                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                        MySQLGeneralQuery.CommandText = "INSERT INTO `Made_Payment`(`Payment_ID`,`DBUserName`,`ED25519PK`,`X25519SEPK`,`X25519MACPK`) VALUES (@Payment_ID,@DBUserName,@ED25519PK,@X25519SEPK,@X25519MACPK)";
                                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                                                        MySQLGeneralQuery.Parameters.Add("@DBUserName", MySqlDbType.Text).Value = DBUserName;
                                                        MySQLGeneralQuery.Parameters.Add("@ED25519PK", MySqlDbType.Text).Value = Convert.ToBase64String(ED25519PKBytes);
                                                        MySQLGeneralQuery.Parameters.Add("@X25519SEPK", MySqlDbType.Text).Value = Convert.ToBase64String(X25519SEPKBytes);
                                                        MySQLGeneralQuery.Parameters.Add("@X25519MACPK", MySqlDbType.Text).Value = Convert.ToBase64String(X25519MACPKBytes);
                                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                        MySQLGeneralQuery.Prepare();
                                                        MySQLGeneralQuery.ExecuteNonQuery();
                                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                        MySQLGeneralQuery = new MySqlCommand();
                                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                        MySQLGeneralQuery.CommandText = "UPDATE `Payment` SET `Payment_Made`=@Payment_Made,`Expiry_Date`=@Expiry_Date WHERE `Payment_ID`=@Payment_ID";
                                                        MySQLGeneralQuery.Parameters.Add("@Payment_Made", MySqlDbType.Text).Value = "True";
                                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = Payment_ID;
                                                        MySQLGeneralQuery.Parameters.Add("@Expiry_Date", MySqlDbType.DateTime).Value = DateTime.UtcNow.AddHours(8).AddDays(30);
                                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                        MySQLGeneralQuery.Prepare();
                                                        MySQLGeneralQuery.ExecuteNonQuery();
                                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                        CreateAndGrantDBUser.CreateDBUserAndDBAndGrantDBUser(DBUserName, DBUserPassword, DBName);
                                                        Byte[] MACKey = System.IO.File.ReadAllBytes("/Projects/PriSecDBAPI/TempSession/" + ClientPathID + "/MACSharedSecret.txt");
                                                        Byte[] SEKey = System.IO.File.ReadAllBytes("/Projects/PriSecDBAPI/TempSession/" + ClientPathID + "/SESharedSecret.txt");
                                                        Byte[] DBUserNameBytes = Encoding.UTF8.GetBytes(DBUserName);
                                                        Byte[] DBUserPasswordBytes = Encoding.UTF8.GetBytes(DBUserPassword);
                                                        Byte[] DBNameBytes = Encoding.UTF8.GetBytes(DBName);
                                                        Byte[] Nonce = SodiumStreamCipherXChaCha20.GenerateXChaCha20Nonce();
                                                        Byte[] EncryptedDBUserNameBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DBUserNameBytes, Nonce, SEKey);
                                                        Byte[] EncryptedDBUserPasswordBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DBUserPasswordBytes, Nonce, SEKey);
                                                        Byte[] EncryptedDBNameBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DBNameBytes, Nonce, SEKey, true);
                                                        Byte[] EDBUserNameBytesHMAC = SodiumHMACSHA512.ComputeMAC(EncryptedDBUserNameBytes, MACKey);
                                                        Byte[] EDBUserPasswordBytesHMAC = SodiumHMACSHA512.ComputeMAC(EncryptedDBUserPasswordBytes, MACKey);
                                                        Byte[] EDBNameBytesHMAC = SodiumHMACSHA512.ComputeMAC(EncryptedDBNameBytes, MACKey, true);
                                                        SodiumSecureMemory.SecureClearString(DBUserName);
                                                        SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                        SodiumSecureMemory.SecureClearString(DBName);
                                                        SodiumSecureMemory.SecureClearBytes(DBNameBytes);
                                                        SodiumSecureMemory.SecureClearBytes(DBUserNameBytes);
                                                        SodiumSecureMemory.SecureClearBytes(DBUserPasswordBytes);
                                                        MyDBCredentialsModel.Nonce = Convert.ToBase64String(Nonce);
                                                        MyDBCredentialsModel.EDBUserNameHMAC = Convert.ToBase64String(EDBUserNameBytesHMAC);
                                                        MyDBCredentialsModel.EncryptedDBUserName = Convert.ToBase64String(EncryptedDBUserNameBytes);
                                                        MyDBCredentialsModel.EDBUserPasswordHMAC = Convert.ToBase64String(EDBUserPasswordBytesHMAC);
                                                        MyDBCredentialsModel.EncryptedDBUserPassword = Convert.ToBase64String(EncryptedDBUserPasswordBytes);
                                                        MyDBCredentialsModel.EDBNameHMAC = Convert.ToBase64String(EDBNameBytesHMAC);
                                                        MyDBCredentialsModel.EncryptedDBName = Convert.ToBase64String(EncryptedDBNameBytes);
                                                        Status = "Success: DB Credentials have been given..";
                                                        //Must use ETLS because of memory disclosure issue if leaving the unencrypted DBUserName and DBUserPassword in the server
                                                        //memory.
                                                    }
                                                }
                                                catch (Exception e)
                                                {
                                                    Console.WriteLine(e.ToString());
                                                    Status = "Error: ED25519 PK submitted by user can't be used in verifying the submitted signed X25519 PKs";
                                                }
                                            }
                                            else
                                            {
                                                MySQLGeneralQuery = new MySqlCommand();
                                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                                MySQLGeneralQuery.CommandText = "DELETE FROM `Payment_Check_Initiation` WHERE `Challenge`=@Challenge";
                                                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                MySQLGeneralQuery.Prepare();
                                                MySQLGeneralQuery.ExecuteNonQuery();
                                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                Status = "Error: This challenge has passed 7 minutes duration";
                                            }
                                        }
                                        else
                                        {
                                            Status = "Error: This signed challenge doesn't exist";
                                        }
                                    }
                                }
                                else
                                {
                                    Status = "Error: You didn't specify lists of ED25519 PKs and X25519 PKs";
                                }
                            }
                            else
                            {
                                Status = "Error: You didn't specify a signed challenge";
                            }
                        }
                        else
                        {
                            Status = "Error: You didn't specify a payment ID";
                        }
                    }
                    else 
                    {
                        Status = "Error: You didn't create an ETLS session with the server yet...";
                    }
                }
                else 
                {
                    Status = "Error: Specified ETLS Client Path does not exist";
                }
            }
            else 
            {
                Status = "Error: You must specify the ETLS Path";
            }
            MyDBCredentialsModel.Status = Status;
            return MyDBCredentialsModel;
        }

        
    }
}
