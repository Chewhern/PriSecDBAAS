﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASodium;
using System.IO;
using System.Text;
using MySql.Data.MySqlClient;
using PriSecDBAPI.Model;
using PriSecDBAPI.Helper;

namespace PriSecDBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SpecialSelectDBRecord : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpPost]
        public DBRecordsModel RetrieveDBRecords(SpecialSelectDBModel MySelectModel)
        {
            DBRecordsModel MyRecordsModel = new DBRecordsModel();
            String Status = "";
            String[] RetrievedRecords = new String[] { };
            ClientMySQLDBConnection ClientMySQLDB = new ClientMySQLDBConnection();
            String Path = "/Projects/PriSecDBAPI/SealedSession/";
            Byte[] DBNameByte = new Byte[] { };
            String DBName = "";
            Byte[] DBUserNameByte = new Byte[] { };
            String DBUserName = "";
            String DatabaseDBUserName = "";
            Byte[] DBUserPasswordByte = new Byte[] { };
            String DBUserPassword = "";
            Byte[] ServerSealedX25519SEPrivateKeyByte = new Byte[] { };
            Byte[] ServerSealedX25519MACPrivateKeyByte = new Byte[] { };
            Byte[] ClientX25519SEPublicKeyByte = new Byte[] { };
            Byte[] ClientX25519MACPublicKeyByte = new Byte[] { };
            int DBCount = 0;
            int LoopCount = 0;
            int ArrayCount = 0;
            int PaymentIDCount = 0;
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlCommand ClientMySQLGeneralQuery = new MySqlCommand();
            String ClientExceptionString = "";
            Boolean ClientCheckConnection = true;
            MySqlDataReader ClientDataReader;
            DateTime MyUTC8DateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseExpirationTime = new DateTime();
            Byte[] QueryStringByte = new Byte[] { };
            String QueryString = "";
            Byte[] ParameterNameByte = new Byte[] { };
            String ParameterName = "";
            Byte[] ParameterValueByte = new Byte[] { };
            String ParameterValue = "";
            Byte[] SEKey = new Byte[] { };
            Byte[] MACKey = new Byte[] { };
            if (MySelectModel != null)
            {
                if (MySelectModel.MyDBCredentialModel.SealedSessionID != null)
                {
                    Path += MySelectModel.MyDBCredentialModel.SealedSessionID;
                    if (Directory.Exists(Path) == true)
                    {
                        try
                        {
                            ServerSealedX25519SEPrivateKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "X25519SESK.txt");
                        }
                        catch
                        {
                            Status = "Error: Can't find server X25519 SE private key";
                            MyRecordsModel.Status = Status;
                            MyRecordsModel.ParameterValues = null;
                            return MyRecordsModel;
                        }
                        try
                        {
                            ServerSealedX25519MACPrivateKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "X25519MACSK.txt");
                        }
                        catch
                        {
                            Status = "Error: Can't find server X25519 MAC private key";
                            MyRecordsModel.Status = Status;
                            MyRecordsModel.ParameterValues = null;
                            return MyRecordsModel;
                        }
                        ClientX25519MACPublicKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "CX25519MACPK.txt");
                        ClientX25519SEPublicKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "CX25519SEPK.txt");
                        SEKey = SodiumScalarMult.Mult(ServerSealedX25519SEPrivateKeyByte, ClientX25519SEPublicKeyByte, true);
                        MACKey = SodiumScalarMult.Mult(ServerSealedX25519MACPrivateKeyByte, ClientX25519MACPublicKeyByte, true);
                        try
                        {
                            Boolean AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBNameHMAC), Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBName), MACKey);
                            Boolean AbleToVerifyHMAC2 = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBUserNameHMAC), Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBUserName), MACKey);
                            Boolean AbleToVerifyHMAC3 = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBUserPasswordHMAC), Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBUserPassword), MACKey,true);
                            if (AbleToVerifyHMAC == false || AbleToVerifyHMAC2 == false || AbleToVerifyHMAC3 == false)
                            {
                                throw new Exception("Error:Unable to verify HMAC");
                            }
                            Byte[] Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), ClientX25519MACPublicKeyByte.Concat(ClientX25519SEPublicKeyByte).ToArray());
                            DBNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBName), Nonce, SEKey);
                            DBUserNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBUserName), Nonce, SEKey);
                            DBUserPasswordByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MySelectModel.MyDBCredentialModel.SealedDBUserPassword), Nonce, SEKey, true);
                        }
                        catch
                        {
                            Status = "Error: Unable to decrypt sealed DB credentials";
                            MyRecordsModel.Status = Status;
                            MyRecordsModel.ParameterValues = null;
                            return MyRecordsModel;
                        }
                        DBName = Encoding.UTF8.GetString(DBNameByte);
                        DBUserName = Encoding.UTF8.GetString(DBUserNameByte);
                        DBUserPassword = Encoding.UTF8.GetString(DBUserPasswordByte);
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySelectModel.UniquePaymentID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        PaymentIDCount = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (PaymentIDCount == 1)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `DBUserName` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySelectModel.UniquePaymentID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseDBUserName = MySQLGeneralQuery.ExecuteScalar().ToString();
                            if (DatabaseDBUserName.CompareTo(DBUserName) == 0)
                            {
                                ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                ClientCheckConnection = ClientMySQLDB.CheckConnection;
                                if (ClientCheckConnection == true)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT `Expiry_Date` FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySelectModel.UniquePaymentID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    DatabaseExpirationTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (DateTime.Compare(MyUTC8DateTime, DatabaseExpirationTime) <= 0)
                                    {
                                        try
                                        {
                                            QueryStringByte = Convert.FromBase64String(MySelectModel.Base64QueryString);
                                        }
                                        catch
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: The query must be in base64 format";
                                            MyRecordsModel.Status = Status;
                                            MyRecordsModel.ParameterValues = null;
                                            return MyRecordsModel;
                                        }
                                        if (MySelectModel.Base64ParameterName.Length != MySelectModel.Base64ParameterValue.Length)
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: Parameter name array and parameter value array length must be the same";
                                            MyRecordsModel.Status = Status;
                                            MyRecordsModel.ParameterValues = null;
                                            return MyRecordsModel;
                                        }
                                        QueryString = Encoding.UTF8.GetString(QueryStringByte);
                                        if (QueryString.ToLower().Contains("select") == false || (QueryString.Contains("'") == true || QueryString.ToLower().Contains("update") == true || QueryString.ToLower().Contains("delete") == true || QueryString.ToLower().Contains("insert") == true || QueryString.ToLower().Contains(";") == true))
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: You didn't pass in correct select query";
                                            MyRecordsModel.Status = Status;
                                            MyRecordsModel.ParameterValues = null;
                                            return MyRecordsModel;
                                        }
                                        ClientMySQLGeneralQuery.CommandText = QueryString;
                                        while (LoopCount < MySelectModel.Base64ParameterName.Length)
                                        {
                                            try
                                            {
                                                ParameterNameByte = Convert.FromBase64String(MySelectModel.Base64ParameterName[LoopCount]);
                                            }
                                            catch
                                            {
                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                Status = "Error: The parameter name must be in base64 format";
                                                MyRecordsModel.Status = Status;
                                                MyRecordsModel.ParameterValues = null;
                                                return MyRecordsModel;
                                            }
                                            try
                                            {
                                                ParameterValueByte = Convert.FromBase64String(MySelectModel.Base64ParameterValue[LoopCount]);
                                            }
                                            catch
                                            {
                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                Status = "Error: The parameter value must be in base64 format";
                                                MyRecordsModel.Status = Status;
                                                MyRecordsModel.ParameterValues = null;
                                                return MyRecordsModel;
                                            }
                                            ParameterName = Encoding.UTF8.GetString(ParameterNameByte);
                                            ParameterValue = Encoding.UTF8.GetString(ParameterValueByte);
                                            ClientMySQLGeneralQuery.Parameters.Add("@" + ParameterName, MySqlDbType.Text).Value = ParameterValue;
                                            LoopCount += 1;
                                        }
                                        LoopCount = 0;
                                        ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                        ClientMySQLGeneralQuery.Prepare();
                                        ClientDataReader = ClientMySQLGeneralQuery.ExecuteReader();
                                        while (ClientDataReader.Read())
                                        {
                                            DBCount += 1;
                                        }
                                        ClientMySQLDB.ClientMySQLConnection.Close();
                                        ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                        ClientMySQLGeneralQuery = new MySqlCommand();
                                        ClientMySQLGeneralQuery.CommandText = QueryString;
                                        while (LoopCount < MySelectModel.Base64ParameterName.Length)
                                        {
                                            try
                                            {
                                                ParameterNameByte = Convert.FromBase64String(MySelectModel.Base64ParameterName[LoopCount]);
                                            }
                                            catch
                                            {
                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                Status = "Error: The parameter name must be in base64 format";
                                                MyRecordsModel.Status = Status;
                                                MyRecordsModel.ParameterValues = null;
                                                return MyRecordsModel;
                                            }
                                            try
                                            {
                                                ParameterValueByte = Convert.FromBase64String(MySelectModel.Base64ParameterValue[LoopCount]);
                                            }
                                            catch
                                            {
                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                Status = "Error: The parameter value must be in base64 format";
                                                MyRecordsModel.Status = Status;
                                                MyRecordsModel.ParameterValues = null;
                                                return MyRecordsModel;
                                            }
                                            ParameterName = Encoding.UTF8.GetString(ParameterNameByte);
                                            ParameterValue = Encoding.UTF8.GetString(ParameterValueByte);
                                            ClientMySQLGeneralQuery.Parameters.Add("@" + ParameterName, MySqlDbType.Text).Value = ParameterValue;
                                            LoopCount += 1;
                                        }
                                        LoopCount = 0;
                                        ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                        ClientMySQLGeneralQuery.Prepare();
                                        ClientDataReader = ClientMySQLGeneralQuery.ExecuteReader();
                                        if (DBCount != 0)
                                        {
                                            DBCount *= ClientDataReader.FieldCount;
                                            RetrievedRecords = new String[DBCount];
                                            while (ClientDataReader.Read())
                                            {
                                                while (LoopCount < ClientDataReader.FieldCount && ArrayCount < RetrievedRecords.Length)
                                                {
                                                    RetrievedRecords[ArrayCount] = ClientDataReader.GetValue(LoopCount).ToString();
                                                    LoopCount += 1;
                                                    ArrayCount += 1;
                                                }
                                                LoopCount = 0;
                                            }
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Successed: Records have been retrieved from specified database table";
                                            MyRecordsModel.Status = Status;
                                            MyRecordsModel.ParameterValues = RetrievedRecords;
                                            return MyRecordsModel;
                                        }
                                        else
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: The specified database in your table has no records at all";
                                            MyRecordsModel.Status = Status;
                                            MyRecordsModel.ParameterValues = null;
                                            return MyRecordsModel;
                                        }
                                    }
                                    else
                                    {
                                        ClientMySQLDB.ClientMySQLConnection.Close();
                                        SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                        SodiumSecureMemory.SecureClearString(DBUserPassword);
                                        SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                        Status = "Error: You haven't renew the database";
                                        MyRecordsModel.Status = Status;
                                        MyRecordsModel.ParameterValues = null;
                                        return MyRecordsModel;
                                    }
                                }
                                else
                                {
                                    ClientMySQLDB.ClientMySQLConnection.Close();
                                    Status = "Error: You have input wrong db credentials";
                                    MyRecordsModel.Status = Status;
                                    MyRecordsModel.ParameterValues = null;
                                    return MyRecordsModel;
                                }
                            }
                            else 
                            {
                                Status = "Error: This database user name does not exist";
                                MyRecordsModel.Status = Status;
                                MyRecordsModel.ParameterValues = null;
                                return MyRecordsModel;
                            }
                        }
                        else
                        {
                            Status = "Error: The sent payment ID does not exists";
                            MyRecordsModel.Status = Status;
                            MyRecordsModel.ParameterValues = null;
                            return MyRecordsModel;
                        }
                    }
                    else
                    {
                        Status = "Error: The sealed session ID does not exist";
                        MyRecordsModel.Status = Status;
                        MyRecordsModel.ParameterValues = null;
                        return MyRecordsModel;
                    }
                }
                else
                {
                    Status = "Error: The sealed session ID can't be null";
                    MyRecordsModel.Status = Status;
                    MyRecordsModel.ParameterValues = null;
                    return MyRecordsModel;
                }
            }
            else
            {
                Status = "Error: NormalDBModel can't be null";
                MyRecordsModel.Status = Status;
                MyRecordsModel.ParameterValues = null;
                return MyRecordsModel;
            }
        }
    }
}
