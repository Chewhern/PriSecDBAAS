﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASodium;
using System.IO;
using System.Text;
using MySql.Data.MySqlClient;
using PriSecDBAPI.Model;
using PriSecDBAPI.Helper;
using BCASodium;
using Org.BouncyCastle.Crypto.Digests;

namespace PriSecDBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SpecialSealedDHDBInsert : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();
        private CryptographicSecureIDGenerator MyIDGenerator = new CryptographicSecureIDGenerator();

        [HttpPost]
        public String InsertConfidentialDataIntoDB(SpecialDBModel MySpecialDBModel)
        {
            ClientMySQLDBConnection ClientMySQLDB = new ClientMySQLDBConnection();
            String Status = "";
            String Path = "/Projects/PriSecDBAPI/SealedSession/";
            Byte[] DBNameByte = new Byte[] { };
            String DBName = "";
            Byte[] DBUserNameByte = new Byte[] { };
            String DBUserName = "";
            String DatabaseDBUserName = "";
            Byte[] DBUserPasswordByte = new Byte[] { };
            String DBUserPassword = "";
            Byte[] ServerSealedX25519SEPrivateKeyByte = new Byte[] { };
            Byte[] ServerSealedX25519MACPrivateKeyByte = new Byte[] { };
            Byte[] ClientX25519SEPublicKeyByte = new Byte[] { };
            Byte[] ClientX25519MACPublicKeyByte = new Byte[] { };
            int PaymentIDCount = 0;
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader DataReader;
            MySqlCommand ClientMySQLGeneralQuery = new MySqlCommand();
            String ClientExceptionString = "";
            Boolean ClientCheckConnection = true;
            MySqlDataReader ClientDataReader;
            DateTime MyUTC8DateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseExpirationTime = new DateTime();
            Byte[] QueryStringByte = new Byte[] { };
            String QueryString = "";
            Byte[] ParameterNameByte = new Byte[] { };
            String ParameterName = "";
            Byte[] ParameterValueByte = new Byte[] { };
            Byte[] EncryptedParameterValueByte = new Byte[] { };
            Byte[] X25519SEPKByte = new Byte[] { };
            Byte[] X25519MACPKByte = new Byte[] { };
            Byte[] Nonce = new Byte[] { };
            String ID = MyIDGenerator.GenerateUniqueString();
            if (ID.Length > 16)
            {
                ID = ID.Substring(0, 16);
            }
            int LoopCount = 0;
            String UsedAmountString = null;
            ulong DBUsedAmount = 0;
            ulong DBAllowedAmount = 0;
            String SuccessStatus = "";
            int TablesThatHasPKCount = 0;
            String[] TablesNameThatHasPK = new String[] { };
            String[] TablesPKColumnName = new String[] { };
            Boolean[] IsPKFieldData = new Boolean[] { };
            int SQLLoopCount = 0;
            int SQLCount = 0;
            Boolean CheckIDValueArray = true;
            Byte[] SEKey = new Byte[] { };
            Byte[] MACKey = new Byte[] { };
            Byte[] MAC = new Byte[] { };
            if (MySpecialDBModel != null)
            {
                if (MySpecialDBModel.MyDBCredentialModel.SealedSessionID != null)
                {
                    Path += MySpecialDBModel.MyDBCredentialModel.SealedSessionID;
                    IsPKFieldData = new Boolean[MySpecialDBModel.IDValue.Length];
                    if (Directory.Exists(Path) == true)
                    {
                        try
                        {
                            ServerSealedX25519SEPrivateKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "X25519SESK.txt");
                        }
                        catch
                        {
                            Status = "Error: Can't find server X25519 SE private key";
                            return Status;
                        }
                        try
                        {
                            ServerSealedX25519MACPrivateKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "X25519MACSK.txt");
                        }
                        catch
                        {
                            Status = "Error: Can't find server X25519 MAC private key";
                            return Status;
                        }
                        ClientX25519MACPublicKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "CX25519MACPK.txt");
                        ClientX25519SEPublicKeyByte = System.IO.File.ReadAllBytes(Path + "/" + "CX25519SEPK.txt");
                        SEKey = SodiumScalarMult.Mult(ServerSealedX25519SEPrivateKeyByte, ClientX25519SEPublicKeyByte, true);
                        MACKey = SodiumScalarMult.Mult(ServerSealedX25519MACPrivateKeyByte, ClientX25519MACPublicKeyByte, true);
                        try
                        {
                            Boolean AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBNameHMAC), Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBName), MACKey);
                            Boolean AbleToVerifyHMAC2 = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBUserNameHMAC), Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBUserName), MACKey);
                            Boolean AbleToVerifyHMAC3 = SodiumHMACSHA512.VerifyMAC(Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBUserPasswordHMAC), Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBUserPassword), MACKey, true);
                            if (AbleToVerifyHMAC == false || AbleToVerifyHMAC2 == false || AbleToVerifyHMAC3 == false)
                            {
                                throw new Exception("Error:Unable to verify HMAC");
                            }
                            Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), ClientX25519MACPublicKeyByte.Concat(ClientX25519SEPublicKeyByte).ToArray());
                            DBNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBName), Nonce, SEKey);
                            DBUserNameByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBUserName), Nonce, SEKey);
                            DBUserPasswordByte = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(Convert.FromBase64String(MySpecialDBModel.MyDBCredentialModel.SealedDBUserPassword), Nonce, SEKey, true);
                        }
                        catch
                        {
                            Status = "Error: Unable to decrypt sealed DB credentials";
                            return Status;
                        }
                        DBName = Encoding.UTF8.GetString(DBNameByte);
                        DBUserName = Encoding.UTF8.GetString(DBUserNameByte);
                        DBUserPassword = Encoding.UTF8.GetString(DBUserPasswordByte);
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        PaymentIDCount = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (PaymentIDCount == 1)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `DBUserName` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseDBUserName = MySQLGeneralQuery.ExecuteScalar().ToString();
                            if (DatabaseDBUserName.CompareTo(DBUserName) == 0)
                            {
                                ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                ClientCheckConnection = ClientMySQLDB.CheckConnection;
                                if (ClientCheckConnection == true)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT `Expiry_Date` FROM `Payment` WHERE `Payment_ID`=@Payment_ID";
                                    MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    DatabaseExpirationTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (DateTime.Compare(MyUTC8DateTime, DatabaseExpirationTime) <= 0)
                                    {
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `X25519SEPK` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        X25519SEPKByte = Convert.FromBase64String(MySQLGeneralQuery.ExecuteScalar().ToString());
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `X25519MACPK` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                                        MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        X25519MACPKByte = Convert.FromBase64String(MySQLGeneralQuery.ExecuteScalar().ToString());
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        try
                                        {
                                            QueryStringByte = Convert.FromBase64String(MySpecialDBModel.Base64QueryString);
                                        }
                                        catch
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: The query must be in base64 format";
                                            return Status;
                                        }
                                        QueryString = Encoding.UTF8.GetString(QueryStringByte);
                                        if (QueryString.ToLower().Contains("insert") == false || (QueryString.ToLower().Contains("update") == true || QueryString.ToLower().Contains("delete") == true || QueryString.ToLower().Contains("select") == true || QueryString.ToLower().Contains(";") == true || QueryString.ToLower().Contains("'") == true))
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: You didn't pass in correct insert query";
                                            return Status;
                                        }
                                        ClientMySQLGeneralQuery.CommandText = "select tab.table_schema as database_schema,sta.index_name as pk_name,sta.seq_in_index as column_id,sta.column_name,tab.table_name from information_schema.tables as tab inner join information_schema.statistics as sta on sta.table_schema = tab.table_schema and sta.table_name = tab.table_name and sta.index_name = 'primary' where tab.table_schema = '" + DBName + "' and tab.table_type = 'BASE TABLE' order by tab.table_name,column_id;";
                                        ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                        ClientMySQLGeneralQuery.Prepare();
                                        ClientDataReader = ClientMySQLGeneralQuery.ExecuteReader();
                                        while (ClientDataReader.Read())
                                        {
                                            TablesThatHasPKCount += 1;
                                        }
                                        ClientMySQLDB.ClientMySQLConnection.Close();
                                        ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                        TablesPKColumnName = new String[TablesThatHasPKCount];
                                        TablesNameThatHasPK = new string[TablesThatHasPKCount];
                                        ClientMySQLGeneralQuery = new MySqlCommand();
                                        ClientMySQLGeneralQuery.CommandText = "select tab.table_schema as database_schema,sta.index_name as pk_name,sta.seq_in_index as column_id,sta.column_name,tab.table_name from information_schema.tables as tab inner join information_schema.statistics as sta on sta.table_schema = tab.table_schema and sta.table_name = tab.table_name and sta.index_name = 'primary' where tab.table_schema = '" + DBName + "' and tab.table_type = 'BASE TABLE' order by tab.table_name,column_id;";
                                        ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                        ClientMySQLGeneralQuery.Prepare();
                                        ClientDataReader = ClientMySQLGeneralQuery.ExecuteReader();
                                        while (ClientDataReader.Read())
                                        {
                                            TablesPKColumnName[SQLLoopCount] = ClientDataReader.GetValue(3).ToString();
                                            TablesNameThatHasPK[SQLLoopCount] = ClientDataReader.GetValue(4).ToString();
                                            SQLLoopCount += 1;
                                        }
                                        ClientMySQLDB.ClientMySQLConnection.Close();
                                        ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                        ClientMySQLGeneralQuery = new MySqlCommand();
                                        if (MySpecialDBModel.IDValue.Length != 0)
                                        {
                                            if (TablesThatHasPKCount != 0)
                                            {
                                                SQLLoopCount = 0;
                                                while (LoopCount < MySpecialDBModel.IDValue.Length)
                                                {
                                                    while (SQLLoopCount < TablesNameThatHasPK.Length)
                                                    {
                                                        ClientMySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `" + TablesNameThatHasPK[SQLLoopCount] + "` WHERE `" + TablesPKColumnName[SQLLoopCount] + "`=@" + TablesPKColumnName[SQLLoopCount];
                                                        ClientMySQLGeneralQuery.Parameters.Add("@" + TablesPKColumnName[SQLLoopCount], MySqlDbType.Text).Value = MySpecialDBModel.IDValue[LoopCount];
                                                        ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                                        ClientMySQLGeneralQuery.Prepare();
                                                        SQLCount = int.Parse(ClientMySQLGeneralQuery.ExecuteScalar().ToString());
                                                        ClientMySQLGeneralQuery = new MySqlCommand();
                                                        if (SQLCount == 1)
                                                        {
                                                            IsPKFieldData[LoopCount] = true;
                                                        }
                                                        SQLLoopCount += 1;
                                                    }
                                                    SQLLoopCount = 0;
                                                    LoopCount += 1;
                                                }
                                                LoopCount = 0;
                                                while (LoopCount < IsPKFieldData.Length)
                                                {
                                                    if (IsPKFieldData[LoopCount] == false)
                                                    {
                                                        CheckIDValueArray = false;
                                                        break;
                                                    }
                                                    LoopCount += 1;
                                                }
                                                LoopCount = 0;
                                                if (CheckIDValueArray == true)
                                                {
                                                    ClientMySQLGeneralQuery.CommandText = QueryString;
                                                    if (MySpecialDBModel.Base64ParameterName.Length != 0 && MySpecialDBModel.Base64ParameterValue.Length != 0)
                                                    {
                                                        if (MySpecialDBModel.Base64ParameterName.Length == MySpecialDBModel.Base64ParameterValue.Length)
                                                        {
                                                            while (LoopCount < MySpecialDBModel.Base64ParameterName.Length)
                                                            {
                                                                ParameterNameByte = Convert.FromBase64String(MySpecialDBModel.Base64ParameterName[LoopCount]);
                                                                ParameterName = Encoding.UTF8.GetString(ParameterNameByte);
                                                                ParameterValueByte = Convert.FromBase64String(MySpecialDBModel.Base64ParameterValue[LoopCount]);
                                                                RevampedKeyPair SEEphemeralKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                                                                RevampedKeyPair MACEphemeralKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                                                                SEKey = SodiumScalarMult.Mult(SEEphemeralKeyPair.PrivateKey, X25519SEPKByte, true);
                                                                MACKey = SodiumScalarMult.Mult(MACEphemeralKeyPair.PrivateKey, X25519MACPKByte, true);
                                                                if (MySpecialDBModel.SECipherAlgorithm == 1)
                                                                {
                                                                    Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(),
                                                                        X25519SEPKByte.Concat(SEEphemeralKeyPair.PublicKey).Concat(X25519MACPKByte).
                                                                        Concat(MACEphemeralKeyPair.PublicKey).ToArray());
                                                                    EncryptedParameterValueByte = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(ParameterValueByte, Nonce, SEKey);
                                                                    EncryptedParameterValueByte = SEEphemeralKeyPair.PublicKey.Concat(MACEphemeralKeyPair.PublicKey).
                                                                        Concat(EncryptedParameterValueByte).ToArray();
                                                                }
                                                                else if (MySpecialDBModel.SECipherAlgorithm == 2)
                                                                {
                                                                    Nonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXSalsa20.GetXSalsa20NonceBytesLength(),
                                                                        X25519SEPKByte.Concat(SEEphemeralKeyPair.PublicKey).Concat(X25519MACPKByte).
                                                                        Concat(MACEphemeralKeyPair.PublicKey).ToArray());
                                                                    EncryptedParameterValueByte = SodiumStreamCipherXSalsa20.XSalsa20Encrypt(ParameterValueByte, Nonce, SEKey);
                                                                    EncryptedParameterValueByte = SEEphemeralKeyPair.PublicKey.Concat(MACEphemeralKeyPair.PublicKey).
                                                                        Concat(EncryptedParameterValueByte).ToArray();
                                                                }
                                                                else if (MySpecialDBModel.SECipherAlgorithm == 3)
                                                                {
                                                                    Nonce = SodiumSecretAeadAES256GCM.GeneratePublicNonce();
                                                                    EncryptedParameterValueByte = SodiumSecretAeadAES256GCM.Encrypt(ParameterValueByte, Nonce, SEKey);
                                                                    EncryptedParameterValueByte = SEEphemeralKeyPair.PublicKey.Concat(MACEphemeralKeyPair.PublicKey).
                                                                        Concat(EncryptedParameterValueByte).ToArray();
                                                                    EncryptedParameterValueByte = Nonce.Concat(EncryptedParameterValueByte).ToArray();
                                                                }
                                                                else
                                                                {
                                                                    int temporaryCount = ParameterValueByte.Length / 16;
                                                                    if (ParameterValueByte.Length % 16 != 0)
                                                                    {
                                                                        temporaryCount += 1;
                                                                    }
                                                                    Nonce = CNSM4.GenerateNonce(temporaryCount * 16);
                                                                    Byte[] TempSEKey = SodiumGenericHash.ComputeHash(16, SEKey);
                                                                    EncryptedParameterValueByte = CNSM4.CTR_Mode_Encrypt(ParameterValueByte, Nonce, TempSEKey, MACKey);
                                                                    EncryptedParameterValueByte = SEEphemeralKeyPair.PublicKey.Concat(MACEphemeralKeyPair.PublicKey).
                                                                        Concat(EncryptedParameterValueByte).ToArray();
                                                                    EncryptedParameterValueByte = BitConverter.GetBytes(temporaryCount * 16).Concat(Nonce).Concat(EncryptedParameterValueByte).ToArray();
                                                                    SodiumSecureMemory.SecureClearBytes(TempSEKey);
                                                                }
                                                                SodiumSecureMemory.SecureClearBytes(SEKey);
                                                                if (MySpecialDBModel.MACAlgorithm == 1)
                                                                {
                                                                    MAC = SodiumHMACSHA512.ComputeMAC(EncryptedParameterValueByte, MACKey, true);
                                                                }
                                                                else if (MySpecialDBModel.MACAlgorithm == 2)
                                                                {
                                                                    MAC = SodiumGenericHash.ComputeHash(64, EncryptedParameterValueByte, MACKey, true);
                                                                }
                                                                else if (MySpecialDBModel.MACAlgorithm == 3)
                                                                {
                                                                    MAC = SodiumOneTimeAuth.ComputePoly1305MAC(EncryptedParameterValueByte, MACKey, true);
                                                                }
                                                                else if (MySpecialDBModel.MACAlgorithm == 4)
                                                                {
                                                                    MAC = KMACHelper.ComputeKMAC(MACKey, EncryptedParameterValueByte, true);
                                                                }
                                                                else if (MySpecialDBModel.MACAlgorithm == 5)
                                                                {
                                                                    MAC = KeccakDigestAlgorithm.ComputeHash(MACKey.Concat(EncryptedParameterValueByte).ToArray(), KeccakDigestAlgorithm.Digest_Length.Digest_512bits);
                                                                    SodiumSecureMemory.SecureClearBytes(MACKey);
                                                                }
                                                                else if (MySpecialDBModel.MACAlgorithm == 6)
                                                                {
                                                                    MAC = SHAKEDigest.ComputeHash(MACKey.Concat(EncryptedParameterValueByte).ToArray(), SHAKEDigest.Digest_Length.Digest_256bits);
                                                                    SodiumSecureMemory.SecureClearBytes(MACKey);
                                                                }
                                                                else
                                                                {
                                                                    MAC = HMACHelper.ComputeHMAC(new SM3Digest(), EncryptedParameterValueByte, MACKey, true);
                                                                }
                                                                EncryptedParameterValueByte = MAC.Concat(EncryptedParameterValueByte).ToArray();
                                                                SEEphemeralKeyPair.Clear();
                                                                MACEphemeralKeyPair.Clear();
                                                                ClientMySQLGeneralQuery.Parameters.Add("@" + ParameterName, MySqlDbType.Text).Value = Convert.ToBase64String(EncryptedParameterValueByte);
                                                                LoopCount += 1;
                                                            }
                                                            LoopCount = 0;
                                                            while (LoopCount < MySpecialDBModel.IDValue.Length)
                                                            {
                                                                ClientMySQLGeneralQuery.Parameters.Add("@FK_ID" + LoopCount.ToString(), MySqlDbType.Text).Value = MySpecialDBModel.IDValue[LoopCount];
                                                                LoopCount += 1;
                                                            }
                                                            MySQLGeneralQuery = new MySqlCommand();
                                                            MySQLGeneralQuery.CommandText = "SELECT `TotalSize` FROM `Payment_Details` WHERE `Payment_ID`=@Payment_ID";
                                                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                            MySQLGeneralQuery.Prepare();
                                                            DBAllowedAmount = ulong.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                                            MySQLGeneralQuery = new MySqlCommand();
                                                            MySQLGeneralQuery.CommandText = "SELECT `Bytes_Used` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                                                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                            MySQLGeneralQuery.Prepare();
                                                            UsedAmountString = MySQLGeneralQuery.ExecuteScalar().ToString();
                                                            if (UsedAmountString.CompareTo("") != 0)
                                                            {
                                                                DBUsedAmount = ulong.Parse(UsedAmountString);
                                                            }
                                                            if (DBUsedAmount > DBAllowedAmount)
                                                            {
                                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                                Status = "Error: You have exceeded the allowed size, try to remove some data from your database";
                                                                return Status;
                                                            }
                                                            ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                                            ClientMySQLGeneralQuery.Prepare();
                                                            ClientMySQLGeneralQuery.ExecuteNonQuery();
                                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                                            ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                                            ClientMySQLGeneralQuery = new MySqlCommand();
                                                            ClientMySQLGeneralQuery.CommandText = "SELECT table_schema 'Databases',ROUND(SUM(data_length + index_length), 1) AS 'Size In Bytes' FROM information_schema.tables GROUP BY table_schema";
                                                            ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                                            ClientMySQLGeneralQuery.Prepare();
                                                            ClientDataReader = ClientMySQLGeneralQuery.ExecuteReader();
                                                            while (ClientDataReader.Read())
                                                            {
                                                                if (SQLLoopCount == 2)
                                                                {
                                                                    UsedAmountString = ClientDataReader.GetValue(1).ToString();
                                                                }
                                                                SQLLoopCount += 1;
                                                            }
                                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                                            MySQLGeneralQuery = new MySqlCommand();
                                                            MySQLGeneralQuery.CommandText = "UPDATE `Made_Payment` SET `Bytes_Used`=@Bytes_Used WHERE `Payment_ID`=@Payment_ID";
                                                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                                            MySQLGeneralQuery.Parameters.Add("@Bytes_Used", MySqlDbType.Text).Value = UsedAmountString;
                                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                            MySQLGeneralQuery.Prepare();
                                                            MySQLGeneralQuery.ExecuteNonQuery();
                                                            myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                            SuccessStatus = "Record has been inserted with numerous ID Values array that has been supplied by user";
                                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                            return SuccessStatus;
                                                        }
                                                        else
                                                        {
                                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                            Status = "Error: Parameter name array length and parameter value array length is not the same";
                                                            return Status;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        ClientMySQLGeneralQuery.CommandText = QueryString;
                                                        if (MySpecialDBModel.IDValue.Length != 0)
                                                        {
                                                            LoopCount = 0;
                                                            while (LoopCount < MySpecialDBModel.IDValue.Length)
                                                            {
                                                                ClientMySQLGeneralQuery.Parameters.Add("@FK_ID" + LoopCount.ToString(), MySqlDbType.Text).Value = MySpecialDBModel.IDValue[LoopCount];
                                                                LoopCount += 1;
                                                            }
                                                            MySQLGeneralQuery = new MySqlCommand();
                                                            MySQLGeneralQuery.CommandText = "SELECT `TotalSize` FROM `Payment_Details` WHERE `Payment_ID`=@Payment_ID";
                                                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                            MySQLGeneralQuery.Prepare();
                                                            DBAllowedAmount = ulong.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                                            MySQLGeneralQuery = new MySqlCommand();
                                                            MySQLGeneralQuery.CommandText = "SELECT `Bytes_Used` FROM `Made_Payment` WHERE `Payment_ID`=@Payment_ID";
                                                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                            MySQLGeneralQuery.Prepare();
                                                            UsedAmountString = MySQLGeneralQuery.ExecuteScalar().ToString();
                                                            if (UsedAmountString.CompareTo("") != 0)
                                                            {
                                                                DBUsedAmount = ulong.Parse(UsedAmountString);
                                                            }
                                                            if (DBUsedAmount > DBAllowedAmount)
                                                            {
                                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                                Status = "Error: You have exceeded the allowed size, try to remove some data from your database";
                                                                return Status;
                                                            }
                                                            UsedAmountString = "";
                                                            ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                                            ClientMySQLGeneralQuery.Prepare();
                                                            ClientMySQLGeneralQuery.ExecuteNonQuery();
                                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                                            ClientMySQLDB.LoadConnection(DBName, DBUserName, DBUserPassword, ref ClientExceptionString);
                                                            ClientMySQLGeneralQuery = new MySqlCommand();
                                                            ClientMySQLGeneralQuery.CommandText = "SELECT table_schema 'Databases',ROUND(SUM(data_length + index_length), 1) AS 'Size In Bytes' FROM information_schema.tables GROUP BY table_schema";
                                                            ClientMySQLGeneralQuery.Connection = ClientMySQLDB.ClientMySQLConnection;
                                                            ClientMySQLGeneralQuery.Prepare();
                                                            ClientDataReader = ClientMySQLGeneralQuery.ExecuteReader();
                                                            while (ClientDataReader.Read())
                                                            {
                                                                if (SQLLoopCount == 2)
                                                                {
                                                                    UsedAmountString = ClientDataReader.GetValue(1).ToString();
                                                                }
                                                                SQLLoopCount += 1;
                                                            }
                                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                                            MySQLGeneralQuery = new MySqlCommand();
                                                            MySQLGeneralQuery.CommandText = "UPDATE `Made_Payment` SET `Bytes_Used`=@Bytes_Used WHERE `Payment_ID`=@Payment_ID";
                                                            MySQLGeneralQuery.Parameters.Add("@Payment_ID", MySqlDbType.Text).Value = MySpecialDBModel.UniquePaymentID;
                                                            MySQLGeneralQuery.Parameters.Add("@Bytes_Used", MySqlDbType.Text).Value = UsedAmountString;
                                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                                            MySQLGeneralQuery.Prepare();
                                                            MySQLGeneralQuery.ExecuteNonQuery();
                                                            myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                                            SuccessStatus = "Record has been inserted with only foreign keys supplied by the user";
                                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                            return SuccessStatus;
                                                        }
                                                        else
                                                        {
                                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                            Status = "Error: IDValue array length must not be 0";
                                                            return Status;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    ClientMySQLDB.ClientMySQLConnection.Close();
                                                    SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                    SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                    SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                    Status = "Error: You are not allowed to put your own foreign keys values, it must be one of the ID that comes from using API";
                                                    return Status;
                                                }
                                            }
                                            else
                                            {
                                                ClientMySQLDB.ClientMySQLConnection.Close();
                                                SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                                SodiumSecureMemory.SecureClearString(DBUserPassword);
                                                SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                                Status = "Error: You haven't create any tables that has primary key yet";
                                                return Status;
                                            }
                                        }
                                        else
                                        {
                                            ClientMySQLDB.ClientMySQLConnection.Close();
                                            SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                            SodiumSecureMemory.SecureClearString(DBUserPassword);
                                            SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                            Status = "Error: IDValue array must not be 0";
                                            return Status;
                                        }
                                    }
                                    else
                                    {
                                        ClientMySQLDB.ClientMySQLConnection.Close();
                                        SodiumSecureMemory.SecureClearBytes(DBUserPasswordByte);
                                        SodiumSecureMemory.SecureClearString(DBUserPassword);
                                        SodiumSecureMemory.SecureClearString(ClientMySQLDB.ConnectionString);
                                        Status = "Error: You haven't renew the database";
                                        return Status;
                                    }
                                }
                                else
                                {
                                    ClientMySQLDB.ClientMySQLConnection.Close();
                                    Status = "Error: You have input wrong db credentials";
                                    return Status;
                                }
                            }
                            else 
                            {
                                Status = "Error: This database user name does not exist";
                                return Status;
                            }
                        }
                        else
                        {
                            Status = "Error: The sent payment ID does not exists";
                            return Status;
                        }
                    }
                    else
                    {
                        Status = "Error: The sealed session ID does not exist";
                        return Status;
                    }
                }
                else
                {
                    Status = "Error: The sealed session ID can't be null";
                    return Status;
                }
            }
            else
            {
                Status = "Error: SpecialDBModel can't be null";
                return Status;
            }
        }
    }
}
